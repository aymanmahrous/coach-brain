export interface DriveOwner {
  displayName: string;
  emailAddress: string;
  photoLink?: string;
  me?: boolean;
}

export interface StorageQuota {
  limit?: string; // in bytes
  usage?: string; // in bytes
  usageInDrive?: string;
  usageInDriveTrash?: string;
}

export interface DriveAboutUser {
  displayName: string;
  emailAddress: string;
  photoLink?: string;
  permissionId?: string;
}

export interface DriveAbout {
  user: DriveAboutUser;
  storageQuota?: StorageQuota;
  maxUploadSize?: string;
}

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string; // bytes
  createdTime?: string;
  modifiedTime?: string;
  webViewLink?: string;
  webContentLink?: string;
  thumbnailLink?: string;
  iconLink?: string;
  shared?: boolean;
  starred?: boolean;
  trashed?: boolean;
  parents?: string[];
  owners?: DriveOwner[];
  description?: string;
}

export type AICategoryKey = 
  | 'invoices' 
  | 'reports' 
  | 'projects' 
  | 'contracts' 
  | 'education' 
  | 'media' 
  | 'general';

export interface AICategoryClassification {
  fileId: string;
  category: AICategoryKey;
  categoryLabel: string;
  confidence: number;
  tags: string[];
  reason?: string;
  analyzedAt: string;
}

export interface FileReminder {
  id: string;
  fileId: string;
  fileName: string;
  fileMimeType: string;
  remindAt: string; // ISO format: YYYY-MM-DDTHH:mm
  note?: string;
  priority?: 'high' | 'medium' | 'low';
  completed?: boolean;
  dismissed?: boolean;
  createdAt: string;
}

export type SearchDateFilter = 'all' | 'today' | 'week' | 'month' | 'year';
export type SearchTypeFilter = 'all' | 'folders' | 'docs' | 'sheets' | 'slides' | 'pdf' | 'images';

export interface AdvancedSearchFilters {
  query: string;
  type: SearchTypeFilter;
  dateModified: SearchDateFilter;
  onlyStarred: boolean;
  onlyReminders: boolean;
  aiCategory: AICategoryKey | 'all';
}

export const DEFAULT_SEARCH_FILTERS: AdvancedSearchFilters = {
  query: '',
  type: 'all',
  dateModified: 'all',
  onlyStarred: false,
  onlyReminders: false,
  aiCategory: 'all',
};

export type DriveCategoryFilter = 
  | 'all'
  | 'folders'
  | 'docs'
  | 'sheets'
  | 'slides'
  | 'pdf'
  | 'images'
  | 'starred'
  | 'reminders'
  | 'trash'
  | `ai_${AICategoryKey}`;

export type ViewMode = 'grid' | 'list';

export type SortField = 'name' | 'modifiedTime' | 'size' | 'type';
export type SortDirection = 'asc' | 'desc';

export interface SortOption {
  field: SortField;
  direction: SortDirection;
}

export interface BreadcrumbItem {
  id: string;
  name: string;
}

export interface AIAnalysisResult {
  fileId: string;
  fileName: string;
  summary: string;
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  fileContextName?: string;
}

export type DrivePermissionRole = 'reader' | 'commenter' | 'writer' | 'owner';

export interface DrivePermission {
  id: string;
  type: 'user' | 'group' | 'domain' | 'anyone';
  role: DrivePermissionRole;
  displayName?: string;
  emailAddress?: string;
  photoLink?: string;
  deleted?: boolean;
}

export interface ShareFileRequest {
  emailAddress: string;
  role: 'reader' | 'commenter' | 'writer';
  sendNotificationEmail?: boolean;
  message?: string;
}

export interface OCREntity {
  label: string;
  value: string;
  type?: 'date' | 'amount' | 'entity' | 'id' | 'other';
}

export interface OCRResult {
  fileId?: string;
  fileName: string;
  fileMimeType: string;
  extractedText: string;
  structuredMarkdown: string;
  detectedLanguage: string;
  confidence: string;
  pageCountOrSections?: string;
  briefSummary?: string;
  suggestedTitle: string;
  keyEntities: OCREntity[];
  searchKeywords: string[];
  processedAt: string;
}

export type ActivityActionType =
  | 'upload'
  | 'rename'
  | 'delete'
  | 'restore'
  | 'delete_permanent'
  | 'share'
  | 'star'
  | 'unstar'
  | 'create_folder'
  | 'create_doc'
  | 'ocr'
  | 'veo'
  | 'backup'
  | 'bulk_rename'
  | 'reminder';

export interface ActivityLogItem {
  id: string;
  actionType: ActivityActionType;
  title: string;
  targetName: string;
  targetId?: string;
  targetMimeType?: string;
  details?: string;
  metadata?: Record<string, any>;
  timestamp: string; // ISO string
}

export interface CustomerChatMessage {
  id: string;
  sender: 'user' | 'bot' | 'human_agent';
  text: string;
  timestamp: string;
  platform: 'whatsapp' | 'messenger';
  status?: 'sent' | 'delivered' | 'read' | 'pending';
}

export interface Conversation {
  id: string;
  customerName: string;
  customerPhoneOrId: string;
  platform: 'whatsapp' | 'messenger';
  branch: string;
  program: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  n8nBotActive: boolean;
  needsHumanTakeover: boolean;
  messages: CustomerChatMessage[];
  aiDraftReply?: string;
  n8nExecutionId?: string;
}


