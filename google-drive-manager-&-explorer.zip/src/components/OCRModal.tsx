import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  ScanText,
  Sparkles,
  FileText,
  Copy,
  Check,
  Download,
  Save,
  Search,
  CheckCircle2,
  AlertCircle,
  FileUp,
  RefreshCw,
  Eye,
  Layers,
  Calendar,
  DollarSign,
  Tag,
  Hash,
  ExternalLink,
  MessageSquarePlus,
  Zap,
  ArrowRight
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { DriveFile, OCRResult, OCREntity } from '../types';
import { OCRService } from '../services/ocrService';
import { DriveService, formatBytes, getFileTypeMeta } from '../services/driveService';
import { SoundEffects } from '../utils/audioChime';

interface OCRModalProps {
  isOpen: boolean;
  onClose: () => void;
  file: DriveFile | null;
  customBase64?: string;
  token: string | null;
  onSaveDocToDrive: (title: string, content: string) => Promise<void>;
  onOpenAIChatWithContext?: (ocrText: string, fileName: string) => void;
}

type TabType = 'markdown' | 'raw' | 'entities';

export const OCRModal: React.FC<OCRModalProps> = ({
  isOpen,
  onClose,
  file,
  customBase64,
  token,
  onSaveDocToDrive,
  onOpenAIChatWithContext,
}) => {
  // State
  const [activeTab, setActiveTab] = useState<TabType>('markdown');
  const [ocrResult, setOcrResult] = useState<OCRResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [isSavingToDrive, setIsSavingToDrive] = useState<boolean>(false);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);
  const [docTitle, setDocTitle] = useState<string>('');
  const [currentBase64, setCurrentBase64] = useState<string | undefined>(customBase64);
  const [activeFile, setActiveFile] = useState<DriveFile | null>(file);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Synchronize when modal opens or input file changes
  useEffect(() => {
    if (isOpen) {
      setActiveFile(file);
      setCurrentBase64(customBase64);
      setOcrResult(null);
      setError(null);
      setSaveSuccessMessage(null);
      setSearchQuery('');
      if (file || customBase64) {
        startOCR(file, customBase64);
      }
    }
  }, [isOpen, file, customBase64]);

  const startOCR = async (targetFile: DriveFile | null, base64Data?: string) => {
    setIsLoading(true);
    setError(null);
    setSaveSuccessMessage(null);

    try {
      const result = await OCRService.performOCR({
        file: targetFile,
        fileData: base64Data,
        token: token,
        fileName: targetFile?.name || 'مستند ممسوح ضوئياً.png',
        mimeType: targetFile?.mimeType || 'image/png',
      });

      setOcrResult(result);
      setDocTitle(result.suggestedTitle || `مستند مستخرج - ${targetFile?.name || 'OCR'}.md`);
      SoundEffects.playSuccess();
    } catch (err: any) {
      console.error('OCR Error:', err);
      setError(err.message || 'تعذر إجراء التعرف الضوئي على الحروف.');
      SoundEffects.playPop();
    } finally {
      setIsLoading(false);
    }
  };

  const handleManualUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files?.[0];
    if (!uploaded) return;

    try {
      setIsLoading(true);
      const b64 = await OCRService.fileToBase64(uploaded);
      setCurrentBase64(b64);
      const syntheticFile: DriveFile = {
        id: `local-${Date.now()}`,
        name: uploaded.name,
        mimeType: uploaded.type,
        size: String(uploaded.size),
        modifiedTime: new Date().toISOString(),
      };
      setActiveFile(syntheticFile);
      await startOCR(syntheticFile, b64);
    } catch (err: any) {
      setError(err.message || 'فشل في قراءة الملف المرفوع.');
      setIsLoading(false);
    }
  };

  const handleCopyText = () => {
    if (!ocrResult) return;
    const textToCopy = activeTab === 'markdown' ? ocrResult.structuredMarkdown : ocrResult.extractedText;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    SoundEffects.playSuccess();
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    if (!ocrResult) return;
    const content = activeTab === 'raw' ? ocrResult.extractedText : ocrResult.structuredMarkdown;
    const name = docTitle || `OCR-${activeFile?.name || 'document'}.md`;
    OCRService.downloadTextFile(content, name);
    SoundEffects.playSuccess();
  };

  const handleSaveToDrive = async () => {
    if (!ocrResult) return;
    setIsSavingToDrive(true);
    setSaveSuccessMessage(null);
    try {
      const content = ocrResult.structuredMarkdown || ocrResult.extractedText;
      const finalTitle = docTitle.trim() || `مستند نصي - ${activeFile?.name || 'OCR'}.md`;
      await onSaveDocToDrive(finalTitle, content);
      SoundEffects.playSuccess();
      setSaveSuccessMessage(`تم حفظ المستند بنجاح في Google Drive باسم "${finalTitle}"`);
    } catch (err: any) {
      setError(err.message || 'فشل في حفظ المستند في Google Drive.');
    } finally {
      setIsSavingToDrive(false);
    }
  };

  const handleAskAI = () => {
    if (!ocrResult) return;
    if (onOpenAIChatWithContext) {
      onClose();
      onOpenAIChatWithContext(
        `[محتوى مستخرج عبر تقنية OCR من ملف ${activeFile?.name || 'المستند'}]:\n${ocrResult.structuredMarkdown || ocrResult.extractedText}`,
        activeFile?.name || 'مستند OCR'
      );
    }
  };

  if (!isOpen) return null;

  const meta = activeFile ? getFileTypeMeta(activeFile.mimeType) : { label: 'صورة / PDF', color: 'text-purple-600 bg-purple-50 border-purple-200' };

  // Calculate statistics
  const totalCharacters = ocrResult?.extractedText?.length || 0;
  const totalWords = ocrResult?.extractedText ? ocrResult.extractedText.trim().split(/\s+/).filter(Boolean).length : 0;
  const totalLines = ocrResult?.extractedText ? ocrResult.extractedText.split('\n').length : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-200" dir="rtl">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Hidden File Input for scanning other files */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,application/pdf"
          className="hidden"
          onChange={handleManualUpload}
        />

        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-violet-600 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20">
              <ScanText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold text-slate-900">
                  التعرف الضوئي على النصوص (OCR) والتحويل لمستند
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 border border-indigo-200 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-indigo-600" />
                  Gemini 3.7 Vision
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate max-w-md">
                {activeFile?.name || 'استخراج النصوص من الصور ومستندات الـ PDF'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-indigo-600 bg-white hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors shadow-2xs cursor-pointer"
              title="مسح صورة أو ملف PDF آخر من جهازك"
            >
              <FileUp className="w-3.5 h-3.5" />
              <span>فحص ملف آخر</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/70 rounded-full transition-colors cursor-pointer"
              title="إغلاق النافذة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Status / Loading State with Radar Laser Beam */}
        {isLoading && (
          <div className="p-8 sm:p-12 flex flex-col items-center justify-center flex-1 min-h-[380px] bg-slate-50/50">
            <div className="relative w-28 h-28 mb-6 flex items-center justify-center">
              {/* Animated Glowing Ring */}
              <div className="absolute inset-0 rounded-3xl bg-indigo-500/10 border-2 border-indigo-400/40 animate-pulse" />
              <div className="absolute inset-2 rounded-2xl bg-indigo-600/20 animate-ping opacity-25" />
              
              {/* Document Icon with Scanning Laser Bar */}
              <div className="relative w-16 h-16 rounded-xl bg-white shadow-lg border border-indigo-200 flex items-center justify-center overflow-hidden">
                <ScanText className="w-8 h-8 text-indigo-600 animate-pulse" />
                <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_8px_#38bdf8] animate-bounce top-2" />
              </div>
            </div>

            <h3 className="text-base font-bold text-slate-900 mb-2">
              جاري فحص المستند واستخراج النصوص بدقة متناهية...
            </h3>
            <p className="text-xs text-slate-500 max-w-sm text-center leading-relaxed">
              يقوم محرك Gemini AI بتحليل الحروف المطبوعة والمكتوبة، وفك الجداول، وهيكلة المحتوى إلى مستند نصي منظم.
            </p>

            <div className="flex items-center gap-2 mt-6 text-xs text-indigo-700 font-semibold px-4 py-1.5 rounded-full bg-indigo-50 border border-indigo-200/80">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>قراءة البكسلات واللغات والهيكل التنظيمي</span>
            </div>
          </div>
        )}

        {/* Error State */}
        {error && !isLoading && (
          <div className="p-8 flex flex-col items-center justify-center text-center bg-rose-50/30 min-h-[300px]">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mb-3">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-rose-900 mb-1">حدث خطأ أثناء إجراء المسح الضوئي</h4>
            <p className="text-xs text-rose-700 max-w-md mb-4">{error}</p>
            <button
              onClick={() => startOCR(activeFile, currentBase64)}
              className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>إعادة المحاولة</span>
            </button>
          </div>
        )}

        {/* Success View */}
        {ocrResult && !isLoading && (
          <div className="flex-1 flex flex-col overflow-hidden">
            
            {/* Top Overview & Metadata Strip */}
            <div className="px-6 py-3 bg-indigo-50/40 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-slate-700 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>تم الاستخراج بنجاح</span>
                </span>

                <span className="px-2.5 py-0.5 rounded-full bg-white border border-slate-200 text-slate-700 font-semibold shadow-2xs">
                  اللغة: {ocrResult.detectedLanguage}
                </span>

                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-200">
                  الدقة: {ocrResult.confidence}
                </span>

                {ocrResult.pageCountOrSections && (
                  <span className="px-2.5 py-0.5 rounded-full bg-white border border-slate-200 text-slate-600 font-medium">
                    {ocrResult.pageCountOrSections}
                  </span>
                )}
              </div>

              {/* Statistics Counters */}
              <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono">
                <span>{totalWords} كلمة</span>
                <span>•</span>
                <span>{totalCharacters} حرف</span>
                <span>•</span>
                <span>{totalLines} سطر</span>
              </div>
            </div>

            {/* AI Summary Banner if present */}
            {ocrResult.briefSummary && (
              <div className="px-6 py-2.5 bg-gradient-to-r from-violet-50/70 to-indigo-50/50 border-b border-indigo-100/80 flex items-center gap-2.5">
                <Zap className="w-4 h-4 text-amber-500 shrink-0" />
                <p className="text-xs text-indigo-950 font-medium leading-relaxed truncate sm:whitespace-normal">
                  <span className="font-bold">ملخص الوثيقة: </span>
                  {ocrResult.briefSummary}
                </p>
              </div>
            )}

            {/* Navigation Tabs and In-Text Search */}
            <div className="px-6 py-2.5 border-b border-slate-200 bg-white flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                <button
                  onClick={() => {
                    setActiveTab('markdown');
                    SoundEffects.playPop();
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === 'markdown'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>المعاينة المنسقة (Markdown)</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('raw');
                    SoundEffects.playPop();
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === 'raw'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>النص الخام المستخرج</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('entities');
                    SoundEffects.playPop();
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === 'entities'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>البيانات المستخرجة ({ocrResult.keyEntities?.length || 0})</span>
                </button>
              </div>

              {/* In-Text Search */}
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="بحث في النص المستخرج..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-3 pr-8 py-1.5 text-xs bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-slate-800"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* Tab Body Content */}
            <div className="flex-1 overflow-y-auto p-6 bg-slate-50/40">
              
              {/* TAB 1: Structured Markdown Preview */}
              {activeTab === 'markdown' && (
                <div className="prose prose-slate max-w-none bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs text-slate-800 text-sm leading-relaxed">
                  <ReactMarkdown
                    components={{
                      h1: ({ children }) => <h1 className="text-xl font-extrabold text-slate-900 pb-2 border-b border-slate-200 mb-4">{children}</h1>,
                      h2: ({ children }) => <h2 className="text-lg font-bold text-slate-900 mt-5 mb-3">{children}</h2>,
                      h3: ({ children }) => <h3 className="text-base font-bold text-slate-800 mt-4 mb-2">{children}</h3>,
                      p: ({ children }) => <p className="text-sm text-slate-700 leading-relaxed mb-3">{children}</p>,
                      ul: ({ children }) => <ul className="list-disc list-inside space-y-1.5 my-3 text-slate-700">{children}</ul>,
                      ol: ({ children }) => <ol className="list-decimal list-inside space-y-1.5 my-3 text-slate-700">{children}</ol>,
                      table: ({ children }) => (
                        <div className="overflow-x-auto my-4 rounded-xl border border-slate-200">
                          <table className="min-w-full divide-y divide-slate-200 text-xs text-right">
                            {children}
                          </table>
                        </div>
                      ),
                      th: ({ children }) => <th className="bg-slate-100 px-4 py-2.5 font-bold text-slate-900">{children}</th>,
                      td: ({ children }) => <td className="px-4 py-2.5 border-t border-slate-100 text-slate-700">{children}</td>,
                      blockquote: ({ children }) => (
                        <blockquote className="border-r-4 border-indigo-500 pr-4 py-1.5 my-3 text-slate-600 bg-indigo-50/40 rounded-l-xl">
                          {children}
                        </blockquote>
                      ),
                    }}
                  >
                    {ocrResult.structuredMarkdown}
                  </ReactMarkdown>
                </div>
              )}

              {/* TAB 2: Raw Extracted Plain Text */}
              {activeTab === 'raw' && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col gap-3">
                  <div className="flex items-center justify-between text-xs text-slate-500 pb-2 border-b border-slate-100">
                    <span>النص الكامل كما تم استخراجه من الوثيقة:</span>
                    <button
                      onClick={handleCopyText}
                      className="flex items-center gap-1 text-indigo-600 hover:text-indigo-800 font-bold"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'تم النسخ!' : 'نسخ النص'}</span>
                    </button>
                  </div>
                  <pre className="text-xs font-mono text-slate-800 whitespace-pre-wrap leading-relaxed max-h-[360px] overflow-y-auto selection:bg-indigo-200">
                    {ocrResult.extractedText}
                  </pre>
                </div>
              )}

              {/* TAB 3: Extracted Entities & Keywords */}
              {activeTab === 'entities' && (
                <div className="flex flex-col gap-5">
                  {/* Entities Grid */}
                  <div>
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5 text-indigo-600" />
                      <span>الكيانات المستخرجة والبيانات الحيوية (Key Entities)</span>
                    </h4>
                    
                    {ocrResult.keyEntities && ocrResult.keyEntities.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                        {ocrResult.keyEntities.map((entity, idx) => (
                          <div key={idx} className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
                            <span className="text-[11px] text-slate-400 font-semibold mb-1 block">
                              {entity.label}
                            </span>
                            <span className="text-xs font-bold text-slate-900 break-words">
                              {entity.value}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-500 bg-white p-4 rounded-xl border border-slate-200">
                        لم يتم رصد كيانات منفصلة. النص متاح بالكامل في تبويب المعاينة.
                      </p>
                    )}
                  </div>

                  {/* Search Keywords */}
                  <div>
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <Hash className="w-3.5 h-3.5 text-blue-600" />
                      <span>كلمات الفهرسة والبحث السريع (Search Keywords)</span>
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {ocrResult.searchKeywords?.map((kw, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 shadow-2xs flex items-center gap-1"
                        >
                          <Hash className="w-3 h-3 text-slate-400" />
                          <span>{kw}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Save Success Toast */}
            {saveSuccessMessage && (
              <div className="px-6 py-2.5 bg-emerald-50 border-t border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{saveSuccessMessage}</span>
                </div>
                <button
                  onClick={() => setSaveSuccessMessage(null)}
                  className="text-emerald-700 hover:text-emerald-900"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Footer Action Bar */}
            <div className="p-4 px-6 border-t border-slate-200 bg-slate-50/90 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              
              {/* Title input for saving to Drive */}
              <div className="flex-1 flex items-center gap-2 max-w-md">
                <span className="text-xs text-slate-500 font-bold shrink-0 hidden sm:inline">اسم المستند:</span>
                <input
                  type="text"
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  placeholder="اسم المستند الجديد..."
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-medium text-slate-800"
                />
              </div>

              {/* Buttons */}
              <div className="flex flex-wrap items-center justify-end gap-2">
                <button
                  onClick={handleCopyText}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-xl border border-slate-200 shadow-2xs transition-colors cursor-pointer"
                  title="نسخ النص للحافظة"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'تم النسخ!' : 'نسخ النص'}</span>
                </button>

                <button
                  onClick={handleDownloadFile}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-xl border border-slate-200 shadow-2xs transition-colors cursor-pointer"
                  title="تحميل ملف Markdown إلى جهازك"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تنزيل (.md)</span>
                </button>

                {onOpenAIChatWithContext && (
                  <button
                    onClick={handleAskAI}
                    className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100/80 rounded-xl border border-indigo-200 shadow-2xs transition-colors cursor-pointer"
                    title="فتح محادثة AI مع هذا المستند"
                  >
                    <MessageSquarePlus className="w-3.5 h-3.5 text-indigo-600" />
                    <span>محادثة بالـ AI</span>
                  </button>
                )}

                <button
                  onClick={handleSaveToDrive}
                  disabled={isSavingToDrive}
                  className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-500/20 transition-all cursor-pointer disabled:opacity-50"
                  title="حفظ النص كمستند رسمي في Google Drive"
                >
                  <Save className={`w-3.5 h-3.5 ${isSavingToDrive ? 'animate-spin' : ''}`} />
                  <span>{isSavingToDrive ? 'جاري الحفظ...' : 'حفظ في Google Drive'}</span>
                </button>
              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
