import React, { useState, useEffect } from 'react';
import {
  X,
  Archive,
  Download,
  FolderArchive,
  CheckCircle2,
  AlertCircle,
  FolderTree,
  FileText,
  FileSpreadsheet,
  FileCode,
  Image as ImageIcon,
  HardDrive,
  Sparkles,
  ArrowDownToLine,
  RefreshCw,
  Folder,
  Layers
} from 'lucide-react';
import { DriveFile } from '../types';
import { FolderBackupService, BackupProgress, BackupOptions, BackupResult } from '../services/folderBackupService';
import { formatBytes } from '../services/driveService';
import { SoundEffects } from '../utils/audioChime';

interface FolderBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  folderId: string;
  folderName: string;
  initialFiles?: DriveFile[];
  token: string | null;
}

export const FolderBackupModal: React.FC<FolderBackupModalProps> = ({
  isOpen,
  onClose,
  folderId,
  folderName,
  initialFiles = [],
  token,
}) => {
  const currentFiles = initialFiles || [];
  const [options, setOptions] = useState<BackupOptions>({
    includeSubfolders: true,
    exportGoogleDocsFormat: 'office',
    includeManifest: true,
  });

  const [status, setStatus] = useState<'idle' | 'running' | 'success' | 'error'>('idle');
  const [progress, setProgress] = useState<BackupProgress | null>(null);
  const [result, setResult] = useState<BackupResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setStatus('idle');
      setProgress(null);
      setResult(null);
      setErrorMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Calculate file composition stats
  const subfolderCount = currentFiles.filter(f => f.mimeType === 'application/vnd.google-apps.folder').length;
  const docsCount = currentFiles.filter(f => f.mimeType?.includes('document') || f.name.endsWith('.docx') || f.name.endsWith('.pdf')).length;
  const sheetsCount = currentFiles.filter(f => f.mimeType?.includes('spreadsheet') || f.name.endsWith('.xlsx') || f.name.endsWith('.csv')).length;
  const imagesCount = currentFiles.filter(f => f.mimeType?.startsWith('image/') || /\.(png|jpg|jpeg|webp|gif)$/i.test(f.name)).length;
  const totalDirectSize = currentFiles.reduce((acc, f) => acc + (parseInt(f.size || '0', 10) || 0), 0);

  const handleStartBackup = async () => {
    SoundEffects.playPop();
    setStatus('running');
    setErrorMessage(null);

    try {
      const backupRes = await FolderBackupService.backupFolder(
        token,
        folderId,
        folderName,
        currentFiles,
        options,
        (prog) => {
          setProgress(prog);
        }
      );

      setResult(backupRes);
      setStatus('success');
      SoundEffects.playSuccess();

      // Automatically trigger browser download
      FolderBackupService.triggerBrowserDownload(backupRes.zipBlob, backupRes.fileName);
    } catch (err: any) {
      console.error('Backup error:', err);
      setStatus('error');
      setErrorMessage(err.message || 'حدث خطأ غير متوقع أثناء تجميع وضغط النسخة الاحتياطية.');
    }
  };

  const handleManualDownloadAgain = () => {
    if (result) {
      SoundEffects.playPop();
      FolderBackupService.triggerBrowserDownload(result.zipBlob, result.fileName);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
      dir="rtl"
    >
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
              <FolderArchive className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black tracking-tight">
                  النسخ الاحتياطي للمجلد (ZIP Archive)
                </h3>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-sm text-emerald-100 font-bold">
                  {folderName}
                </span>
              </div>
              <p className="text-xs text-emerald-100/90 mt-0.5">
                تنزيل حزمة مضغوطة تشمل جميع الملفات والمجلدات إلى جهازك
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            disabled={status === 'running'}
            className="p-2 text-white/80 hover:text-white hover:bg-white/15 rounded-xl transition-colors cursor-pointer disabled:opacity-50"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-5">
          
          {/* Status 1: IDLE - Settings and Preview */}
          {status === 'idle' && (
            <>
              {/* Folder Content Snapshot */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
                  <span className="flex items-center gap-1.5 font-bold text-slate-800 text-sm">
                    <Folder className="w-4 h-4 text-amber-500" />
                    <span>محتويات المجلد الحالي:</span>
                  </span>
                  <span>{currentFiles.length} عنصر مباشر</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/70 flex items-center gap-2">
                    <FolderTree className="w-4 h-4 text-amber-600 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-800">{subfolderCount}</div>
                      <div className="text-[10px] text-slate-500 truncate">مجلدات فرعية</div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/70 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-800">{docsCount}</div>
                      <div className="text-[10px] text-slate-500 truncate">مستندات وPDF</div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/70 flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-800">{sheetsCount}</div>
                      <div className="text-[10px] text-slate-500 truncate">جداول وبيانات</div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/70 flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-rose-600 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-800">{imagesCount}</div>
                      <div className="text-[10px] text-slate-500 truncate">صور ووسائط</div>
                    </div>
                  </div>
                </div>

                {totalDirectSize > 0 && (
                  <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-xs">
                    <span className="text-slate-600 flex items-center gap-1">
                      <HardDrive className="w-3.5 h-3.5 text-slate-400" />
                      إجمالي الحجم التقديري:
                    </span>
                    <span className="font-bold text-slate-900">{formatBytes(totalDirectSize)}</span>
                  </div>
                )}
              </div>

              {/* Compression & Export Options */}
              <div className="space-y-4">
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  <span>خيارات التصدير والضغط</span>
                </h4>

                {/* Subfolder inclusion */}
                <label className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 hover:bg-emerald-50/50 border border-slate-200 hover:border-emerald-200 transition-all cursor-pointer">
                  <input
                    type="checkbox"
                    checked={options.includeSubfolders}
                    onChange={(e) => setOptions({ ...options, includeSubfolders: e.target.checked })}
                    className="w-4 h-4 mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                  />
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      تضمين كافة المجلدات الفرعية تفرعياً (Recursive Subfolders)
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      الحفاظ على نفس الهيكل الشجري للمجلدات والمجلدات المتداخلة داخل ملف ZIP
                    </div>
                  </div>
                </label>

                {/* Google Docs Export Format */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
                  <div className="text-xs font-bold text-slate-900">
                    صيغة تحويل مستندات وجداول Google Docs:
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label
                      className={`flex items-center gap-2.5 p-2.5 rounded-xl border transition-all cursor-pointer ${
                        options.exportGoogleDocsFormat === 'office'
                          ? 'bg-white border-emerald-500 shadow-xs ring-1 ring-emerald-500'
                          : 'bg-white/70 border-slate-200 hover:bg-white'
                      }`}
                    >
                      <input
                        type="radio"
                        name="exportFormat"
                        checked={options.exportGoogleDocsFormat === 'office'}
                        onChange={() => setOptions({ ...options, exportGoogleDocsFormat: 'office' })}
                        className="w-4 h-4 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                      <div>
                        <div className="text-xs font-bold text-slate-800">Microsoft Office</div>
                        <div className="text-[10px] text-slate-500">.docx, .xlsx, .pptx</div>
                      </div>
                    </label>

                    <label
                      className={`flex items-center gap-2.5 p-2.5 rounded-xl border transition-all cursor-pointer ${
                        options.exportGoogleDocsFormat === 'pdf'
                          ? 'bg-white border-emerald-500 shadow-xs ring-1 ring-emerald-500'
                          : 'bg-white/70 border-slate-200 hover:bg-white'
                      }`}
                    >
                      <input
                        type="radio"
                        name="exportFormat"
                        checked={options.exportGoogleDocsFormat === 'pdf'}
                        onChange={() => setOptions({ ...options, exportGoogleDocsFormat: 'pdf' })}
                        className="w-4 h-4 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                      <div>
                        <div className="text-xs font-bold text-slate-800">مستندات PDF</div>
                        <div className="text-[10px] text-slate-500">جاهزة للطباعة والمشاركة</div>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Manifest Report */}
                <label className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 hover:bg-emerald-50/50 border border-slate-200 hover:border-emerald-200 transition-all cursor-pointer">
                  <input
                    type="checkbox"
                    checked={options.includeManifest}
                    onChange={(e) => setOptions({ ...options, includeManifest: e.target.checked })}
                    className="w-4 h-4 mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                  />
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      تضمين ملف فهرس البيانات والتقرير (README & manifest.json)
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      إنشاء سجل يحتوي على تواريخ التعديل، الأحجام، ومطابقة البيانات لكل ملف
                    </div>
                  </div>
                </label>
              </div>
            </>
          )}

          {/* Status 2: RUNNING - Active Progress */}
          {status === 'running' && (
            <div className="py-6 space-y-6 text-center">
              <div className="relative w-24 h-24 mx-auto">
                <div className="w-24 h-24 rounded-full border-4 border-emerald-100 border-t-emerald-600 animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Archive className="w-8 h-8 text-emerald-600 animate-bounce" />
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-base font-black text-slate-900">
                  {progress?.message || 'جاري تجهيز وضغط النسخة الاحتياطية...'}
                </h4>
                {progress?.currentFileName && (
                  <p className="text-xs text-slate-500 font-mono truncate max-w-sm mx-auto px-3 py-1 rounded-lg bg-slate-100">
                    {progress.currentFileName}
                  </p>
                )}
              </div>

              {/* Progress bar */}
              <div className="space-y-1.5 max-w-md mx-auto">
                <div className="flex justify-between text-xs font-bold text-slate-600 px-1">
                  <span>
                    {progress?.phase === 'scanning' && 'فحص وهيكلة الملفات...'}
                    {progress?.phase === 'downloading' && `تحميل الملفات (${progress.processedFiles} من ${progress.totalFiles})`}
                    {progress?.phase === 'compressing' && 'ضغط أرشيف ZIP النهائي...'}
                    {progress?.phase === 'completed' && 'اكتمل الضغط'}
                  </span>
                  <span className="text-emerald-700 font-black">{progress?.percent || 10}%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-slate-100 overflow-hidden p-0.5 border border-slate-200">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 transition-all duration-300 shadow-sm"
                    style={{ width: `${progress?.percent || 10}%` }}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-400 px-1 pt-1">
                  <span>تمت معالجة: {formatBytes(progress?.downloadedBytes || 0)}</span>
                  <span>ضغط DEFLATE عالي الكفاءة</span>
                </div>
              </div>
            </div>
          )}

          {/* Status 3: SUCCESS - Completion and Download */}
          {status === 'success' && result && (
            <div className="py-4 space-y-5">
              <div className="p-5 rounded-3xl bg-emerald-50/80 border border-emerald-200 text-center space-y-3">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30 animate-in zoom-in-50">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-base font-black text-emerald-950">
                    اكتمل إنشاء النسخة الاحتياطية بنجاح!
                  </h4>
                  <p className="text-xs text-emerald-800 mt-1">
                    تم بدء تنزيل ملف الـ ZIP تلقائياً إلى جهازك. يمكنك النقر أدناه لإعادة التنزيل في أي وقت.
                  </p>
                </div>
              </div>

              {/* Result Summary Card */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="text-xs font-bold text-slate-800 border-b border-slate-200/80 pb-2">
                  تفاصيل الأرشيف المضغوط:
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[11px]">اسم الملف:</span>
                    <span className="font-bold font-mono text-slate-900 truncate block">
                      {result.fileName}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[11px]">إجمالي الملفات:</span>
                    <span className="font-bold text-slate-900">
                      {result.totalFilesCount} ملف ({result.totalFoldersCount} مجلد)
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[11px]">الحجم الأصلي:</span>
                    <span className="font-bold text-slate-900">
                      {formatBytes(result.uncompressedBytes)}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[11px]">حجم ملف ZIP:</span>
                    <span className="font-bold text-emerald-700">
                      {formatBytes(result.compressedBytes)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Status 4: ERROR */}
          {status === 'error' && (
            <div className="p-5 rounded-2xl bg-rose-50 border border-rose-200 text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-rose-900">فشل في إنشاء النسخة الاحتياطية</h4>
                <p className="text-xs text-rose-700 mt-1">{errorMessage}</p>
              </div>
              <button
                onClick={handleStartBackup}
                className="inline-flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-sm transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>إعادة المحاولة</span>
              </button>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          {status === 'idle' && (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2.5 text-slate-700 hover:bg-slate-200/70 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                إلغاء
              </button>

              <button
                onClick={handleStartBackup}
                className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-600/25 transition-all cursor-pointer"
              >
                <Archive className="w-4 h-4" />
                <span>بدء الضغط وتنزيل ZIP</span>
              </button>
            </>
          )}

          {status === 'running' && (
            <div className="text-xs text-slate-500 text-center w-full font-medium">
              يرجى عدم إغلاق النافذة أثناء عملية التنزيل والضغط...
            </div>
          )}

          {status === 'success' && (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2.5 text-slate-700 hover:bg-slate-200/70 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                إغلاق النافذة
              </button>

              <button
                onClick={handleManualDownloadAgain}
                className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-600/25 transition-all cursor-pointer"
              >
                <ArrowDownToLine className="w-4 h-4" />
                <span>تنزيل الملف مرة أخرى</span>
              </button>
            </>
          )}

          {status === 'error' && (
            <div className="flex items-center justify-end w-full">
              <button
                onClick={onClose}
                className="px-4 py-2 text-slate-700 hover:bg-slate-200/70 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
