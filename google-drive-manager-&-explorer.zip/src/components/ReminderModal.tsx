import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Calendar, 
  Clock, 
  FileText, 
  Trash2, 
  Check, 
  X, 
  AlertCircle,
  Sparkles,
  Tag,
  Folder,
  File
} from 'lucide-react';
import { DriveFile, FileReminder } from '../types';
import { ReminderService } from '../services/reminderService';
import { NotificationService, WebNotificationPermission } from '../services/notificationService';
import { getFileTypeMeta } from '../services/driveService';

interface ReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  file: DriveFile | null;
  existingReminder?: FileReminder;
  onSave: (reminder: FileReminder) => void;
  onDelete?: (fileId: string) => void;
}

export const ReminderModal: React.FC<ReminderModalProps> = ({
  isOpen,
  onClose,
  file,
  existingReminder,
  onSave,
  onDelete,
}) => {
  const [dateStr, setDateStr] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [priority, setPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [error, setError] = useState<string>('');
  const [notificationPermission, setNotificationPermission] = useState<WebNotificationPermission>('default');

  useEffect(() => {
    if (isOpen) {
      setNotificationPermission(NotificationService.getPermission());
    }
  }, [isOpen]);

  useEffect(() => {
    if (isOpen && file) {
      if (existingReminder) {
        // Pre-fill existing reminder
        const d = new Date(existingReminder.remindAt);
        // Format for input datetime-local: YYYY-MM-DDTHH:mm
        const pad = (n: number) => n.toString().padStart(2, '0');
        const formatted = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
        setDateStr(formatted);
        setNote(existingReminder.note || '');
        setPriority(existingReminder.priority || 'medium');
      } else {
        // Default to tomorrow 9:00 AM
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(9, 0, 0, 0);
        const pad = (n: number) => n.toString().padStart(2, '0');
        const formatted = `${tomorrow.getFullYear()}-${pad(tomorrow.getMonth() + 1)}-${pad(tomorrow.getDate())}T${pad(tomorrow.getHours())}:${pad(tomorrow.getMinutes())}`;
        setDateStr(formatted);
        setNote('');
        setPriority('medium');
      }
      setError('');
    }
  }, [isOpen, file, existingReminder]);

  if (!isOpen || !file) return null;

  const meta = getFileTypeMeta(file.mimeType);
  const presets = ReminderService.getPresets();

  const handleApplyPreset = (presetDate: Date) => {
    const pad = (n: number) => n.toString().padStart(2, '0');
    const formatted = `${presetDate.getFullYear()}-${pad(presetDate.getMonth() + 1)}-${pad(presetDate.getDate())}T${pad(presetDate.getHours())}:${pad(presetDate.getMinutes())}`;
    setDateStr(formatted);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dateStr) {
      setError('يرجى تحديد تاريخ ووقت التذكير');
      return;
    }

    const selectedTime = new Date(dateStr).getTime();
    if (isNaN(selectedTime)) {
      setError('تنسيق التاريخ والوقت غير صحيح');
      return;
    }

    const saved = ReminderService.setReminder({
      fileId: file.id,
      fileName: file.name,
      fileMimeType: file.mimeType,
      remindAt: new Date(dateStr).toISOString(),
      note: note.trim(),
      priority,
      id: existingReminder?.id,
    });

    onSave(saved);
    onClose();
  };

  const handleDelete = () => {
    if (existingReminder) {
      ReminderService.deleteReminder(existingReminder.id);
      if (onDelete) {
        onDelete(file.id);
      }
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="reminder-modal-content"
        className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col animate-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600 border border-amber-200/60">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {existingReminder ? 'تعديل التذكير' : 'إضافة تذكير للملف'}
              </h2>
              <p className="text-xs text-slate-500">
                جدولة تنبيه مرئي للرجوع إلى هذا الملف
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* File Target Pill */}
        <div className="px-6 pt-4 pb-2">
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-blue-50/60 border border-blue-100">
            <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-blue-600 shadow-2xs shrink-0">
              <File className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-slate-800 truncate" title={file.name}>
                {file.name}
              </p>
              <p className="text-[10px] text-slate-500 font-mono">
                {meta.label}
              </p>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-6 pt-2 flex flex-col gap-4">
          {error && (
            <div className="flex items-center gap-2 p-3 text-xs text-rose-700 bg-rose-50 border border-rose-200/70 rounded-xl">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Quick Presets */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              اقتراحات الموعد السريعة:
            </label>
            <div className="flex flex-wrap gap-1.5">
              {presets.map((preset, idx) => (
                <button
                  type="button"
                  key={idx}
                  onClick={() => handleApplyPreset(preset.date)}
                  className="px-2.5 py-1.5 text-xs font-medium bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-200 border border-slate-200/80 rounded-xl transition-all cursor-pointer"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Date Time */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              تاريخ ووقت التنبيه:
            </label>
            <div className="relative">
              <input
                type="datetime-local"
                value={dateStr}
                onChange={(e) => setDateStr(e.target.value)}
                className="w-full pl-3 pr-10 py-2.5 text-sm bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl outline-none focus:ring-3 focus:ring-blue-500/10 font-mono transition-all text-slate-800"
                required
              />
              <Clock className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Priority Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              مستوى الأهمية (الأولوية):
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPriority('low')}
                className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all flex items-center justify-center gap-1.5 ${
                  priority === 'low'
                    ? 'bg-slate-100 text-slate-800 border-slate-400 shadow-2xs'
                    : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-slate-400" />
                <span>عادي</span>
              </button>
              <button
                type="button"
                onClick={() => setPriority('medium')}
                className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all flex items-center justify-center gap-1.5 ${
                  priority === 'medium'
                    ? 'bg-amber-50 text-amber-800 border-amber-400 shadow-2xs'
                    : 'bg-white text-slate-500 border-slate-200 hover:bg-amber-50/50'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span>متوسط</span>
              </button>
              <button
                type="button"
                onClick={() => setPriority('high')}
                className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all flex items-center justify-center gap-1.5 ${
                  priority === 'high'
                    ? 'bg-rose-50 text-rose-800 border-rose-400 shadow-2xs'
                    : 'bg-white text-slate-500 border-slate-200 hover:bg-rose-50/50'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                <span>عالي الأهمية</span>
              </button>
            </div>
          </div>

          {/* Note Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              ملاحظة التذكير (اختياري):
            </label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="مثال: مراجعة التقرير وتوقيعه، تسليم الفاتورة للعميل..."
              rows={2}
              className="w-full p-3 text-xs bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl outline-none focus:ring-3 focus:ring-blue-500/10 transition-all text-slate-800 placeholder-slate-400 resize-none"
            />
          </div>

          {/* Web Notifications Desktop Info & Permission Banner */}
          <div className="p-3 bg-slate-900 text-white rounded-2xl flex flex-col gap-2 text-[11px] border border-slate-800 shadow-sm">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 font-bold">
                <Bell className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span className="text-slate-100">تنبيهات سطح المكتب (Web Notifications):</span>
              </div>
              {notificationPermission === 'granted' ? (
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  مفعلة ✅
                </span>
              ) : notificationPermission === 'denied' ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  محظورة بالمتصفح
                </span>
              ) : (
                <button
                  type="button"
                  onClick={async () => {
                    const res = await NotificationService.requestPermission();
                    setNotificationPermission(res);
                  }}
                  className="text-[10px] font-black px-2.5 py-0.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-900 transition-colors shadow-xs cursor-pointer"
                >
                  تفعيل التنبيهات الآن
                </button>
              )}
            </div>
            <p className="text-[10px] text-slate-300 leading-relaxed">
              ستتلقى إشعاراً منبثقاً على سطح المكتب قبل الموعد بـ 15 دقيقة وعند حلوله مباشرة، حتى لو كنت تعمل في نافذة أو تطبيق آخر خارج المتصفح.
            </p>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 mt-2">
            {existingReminder ? (
              <button
                type="button"
                onClick={handleDelete}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>حذف التذكير</span>
              </button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-xl shadow-md shadow-blue-500/20 transition-all cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>حفظ التذكير</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
