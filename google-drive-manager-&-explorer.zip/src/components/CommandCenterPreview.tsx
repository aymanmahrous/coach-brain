import React, { useState, useEffect } from 'react';
import { 
  Compass, 
  Sparkles, 
  MessageSquare, 
  FolderGit2, 
  Activity, 
  Search, 
  Palette, 
  Bell, 
  Plus, 
  AlertCircle, 
  CheckCircle2, 
  Check, 
  Send, 
  Upload, 
  Layers, 
  Wand2, 
  X, 
  AlertTriangle,
  ArrowRight,
  Eye,
  EyeOff,
  Calendar,
  Layers as LayersIcon,
  PhoneCall,
  User,
  ShieldCheck,
  RotateCcw,
  Clock,
  Trash2,
  ExternalLink,
  Edit3,
  Video,
  Image as ImageIcon,
  Share2,
  Play,
  FileText,
  Sliders,
  ChevronDown,
  Radio
} from 'lucide-react';
import { N8nConnectionModal } from './N8nConnectionModal';
import { SettingsModal } from './SettingsModal';
import { CoachBrainCenter } from './CoachBrainCenter';
import { PublishingReceiptModal, PublishingReceipt } from './PublishingReceiptModal';

interface CommandCenterPreviewProps {
  onClosePreview?: () => void;
}

type TabType = 'cockpit' | 'brain' | 'factory' | 'whatsapp' | 'media';

interface ScheduledPost {
  id: string;
  title: string;
  platform: 'Instagram' | 'TikTok' | 'Facebook' | 'YouTube Shorts';
  aspectRatio: '9:16' | '4:5' | '1:1';
  templateType: string;
  scheduledTime: string;
  hookCaption: string;
  brief: string;
  status: 'needs_review' | 'scheduled' | 'published';
  showPoster: boolean;
  branch: string;
}

export const CommandCenterPreview: React.FC<CommandCenterPreviewProps> = ({ onClosePreview }) => {
  // Navigation: Cockpit, Coach Brain, Content Factory, WhatsApp, Media
  const [activeTab, setActiveTab] = useState<TabType>('factory');
  
  // Accent theme state (saved in localStorage)
  const [accentColor, setAccentColor] = useState<string>(() => {
    return localStorage.getItem('cockpit_accent_color') || 'cyan';
  });
  const [showColorModal, setShowColorModal] = useState(false);
  const [showN8nModal, setShowN8nModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Real Publishing & Live Receipts State (Meta Graph API & Safe Publisher)
  const [publishingPostId, setPublishingPostId] = useState<string | null>(null);
  const [activeReceipt, setActiveReceipt] = useState<PublishingReceipt | null>(null);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [receiptsList, setReceiptsList] = useState<PublishingReceipt[]>([]);

  // Load existing receipts on mount
  useEffect(() => {
    fetch('/api/meta/receipts')
      .then(res => res.json())
      .then(data => {
        if (data?.receipts) setReceiptsList(data.receipts);
      })
      .catch(() => {});
  }, []);

  // Content Factory state
  const [planMode, setPlanMode] = useState<'3days' | 'weekly' | 'monthly' | 'custom'>('3days');
  const [generatorPlatform, setGeneratorPlatform] = useState<string>('TikTok');
  const [generatorIdea, setGeneratorIdea] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  // Media Tab state
  const [mediaFilter, setMediaFilter] = useState<'all' | 'review' | 'approved' | 'external' | 'archive' | 'trash'>('all');

  // Posts State (Matches Image 3)
  const [reviewPosts, setReviewPosts] = useState<ScheduledPost[]>([
    {
      id: 'rev-1',
      title: 'ريلز تكتيك وتصحيح تكنيك (9:16)',
      platform: 'Instagram',
      aspectRatio: '9:16',
      templateType: 'ريلز تكتيك وتصحيح تكنيك (9:16)',
      scheduledTime: 'غداً 07:00 م',
      hookCaption: '🏊‍♂️ السر الأكبر اللي يخليك تتعب بسرعة أثناء السباحة مش نقص اللياقة، بل التكنيك الخاطئ في التنفس الجانبي وحركة الكوع العالي!\n\nفي أكاديمية كوتش أيمن (Swim Fluent UAE)، بنعلمك كيف تطفو وتتحرك بانسيابية تامة بدون أي مجهود مضاعف.\n\n📍 احجز جلستك التجريبية الآن في فروع أبوظبي: الكورنيش • البطين • المشرف.\n💬 راسلنا عبر الواتساب للاستفسار عن الباقات والعروض الخاصة.',
      brief: 'فيديو تعليمي عالي الجودة للسباحة الحرة (Freestyle) مع أسهم توضيحية رقمية لتكنيك اليد، شعار Swim Fluent & Relax Fix الرسمي، وألوان الهوية البحرية مع درجات الأزرق والسيان.',
      status: 'needs_review',
      showPoster: true,
      branch: 'أبوظبي: الكورنيش'
    }
  ]);

  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPost[]>([
    {
      id: 'sch-1',
      title: 'إنفوجرافيك خطوات علاج رهبة الماء (4:5)',
      platform: 'Instagram',
      aspectRatio: '4:5',
      templateType: 'قصة نجاح وعلاج رهبة الماء (4:5)',
      scheduledTime: 'بعد غد 10:00 ص',
      hookCaption: 'كيف تتغلب على الخوف من الماء في 3 جلسات فقط؟ منهجية Relax Fix المعتمدة عالمياً تعتمد على الأمان النفسي والتنفس التدريجي.',
      brief: 'قالب كاروسيل تعليمي مكون من 3 شرائح بتصميم Canva المعتمد EAHVAAahmjU، ألوان هادئة وخط عربي حديث.',
      status: 'scheduled',
      showPoster: false,
      branch: 'أبوظبي: المشرف'
    }
  ]);

  // Multi-Channel CRM State (WhatsApp & Facebook Messenger via n8n)
  const [conversations, setConversations] = useState<any[]>([
    {
      id: 'conv-wa-1',
      customerName: 'أم راشد (حصة خاصة للأطفال)',
      customerPhoneOrId: '+971 50 842 1920',
      platform: 'whatsapp',
      branch: 'أبوظبي: البطين',
      program: 'علاج رهبة الماء (Relax Fix)',
      lastMessage: 'السلام عليكم كوتش، ابني عمره 5 سنوات وعنده خوف شديد من المسبح، هل كوتش أيمن يدربه بنفسه؟',
      lastMessageTime: '11:15 ص',
      unreadCount: 1,
      n8nBotActive: true,
      needsHumanTakeover: true,
      aiDraftReply: 'وعليكم السلام ورحمة الله أهلاً بك يا فندم! نعم بالتأكيد، في فرع البطين لدينا منهجية متخصصة للأطفال لعلاج رهبة الماء بلطف وتدريج يبدأ باللعب وبناء الثقة دون أي ضغط. نوفر جلسة تقييم تشخيصية مجانية لمعرفة درجة التجاوب. هل يناسبك موعد يوم الثلاثاء أو الخميس الساعة 5 مساءً؟',
      messages: [
        {
          id: 'msg-1',
          sender: 'user',
          text: 'السلام عليكم كوتش، ابني عمره 5 سنوات وعنده خوف شديد من المسبح، هل كوتش أيمن يدربه بنفسه؟',
          timestamp: '11:15 ص',
          platform: 'whatsapp'
        }
      ]
    },
    {
      id: 'conv-msg-1',
      customerName: 'م. خالد النعيمي',
      customerPhoneOrId: 'fb_user_8829104',
      platform: 'messenger',
      branch: 'أبوظبي: الكورنيش',
      program: 'كورس إتقان السباحة الحرة للكبار',
      lastMessage: 'مرحباً، حابب أستفسر عن مواعيد الحصص المسائية للكبار في مسبح الكورنيش والأسعار للباقة الكاملة.',
      lastMessageTime: '01:20 م',
      unreadCount: 1,
      n8nBotActive: true,
      needsHumanTakeover: false,
      aiDraftReply: 'أهلاً بك م. خالد! مواعيد تدريب الكبار في مسبح الكورنيش الأولمبي متوفرة أيام الأحد والثلاثاء والخميس من 07:30 إلى 08:30 مساءً. باقة الـ 12 حصة تشمل تصحيح تكنيك التنفس والطفو مع فيديو تحليلي. هل ترغب بحجز مكانك في مجموعة الأسبوع القادم؟',
      messages: [
        {
          id: 'msg-2',
          sender: 'user',
          text: 'مرحباً، حابب أستفسر عن مواعيد الحصص المسائية للكبار في مسبح الكورنيش والأسعار للباقة الكاملة.',
          timestamp: '01:20 م',
          platform: 'messenger'
        }
      ]
    },
    {
      id: 'conv-wa-2',
      customerName: 'سعيد المنصوري',
      customerPhoneOrId: '+971 55 319 4482',
      platform: 'whatsapp',
      branch: 'أبوظبي: المشرف',
      program: 'تأهيل إصابات الظهر وتمارين الإطالة المائية',
      lastMessage: 'تم تحويل رسوم الباقة كوتش، متى أول جلسة تقييم؟',
      lastMessageTime: 'أمس 06:45 م',
      unreadCount: 0,
      n8nBotActive: true,
      needsHumanTakeover: false,
      messages: [
        {
          id: 'msg-3',
          sender: 'user',
          text: 'تم تحويل رسوم الباقة كوتش، متى أول جلسة تقييم؟',
          timestamp: 'أمس 06:45 م',
          platform: 'whatsapp'
        },
        {
          id: 'msg-4',
          sender: 'bot',
          text: 'أهلاً بك يا أستاذ سعيد! تم استلام التأكيد وتحديد جلستك الأولى يوم الأربعاء القادم الساعة 6 مساءً في فرع المشرف مع كابتن أيمن. نتطلع للقائك!',
          timestamp: 'أمس 06:46 م',
          platform: 'whatsapp'
        }
      ]
    }
  ]);
  const [selectedConvoId, setSelectedConvoId] = useState<string>('conv-wa-1');
  const [convoFilter, setConvoFilter] = useState<'all' | 'whatsapp' | 'messenger' | 'takeover' | 'bot'>('all');
  const [customReplyText, setCustomReplyText] = useState<string>('');

  // Drawer & Notification State
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerContent, setDrawerContent] = useState<{
    title: string;
    subtitle: string;
    type: string;
    data?: any;
  } | null>(null);

  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  const handleAccentChange = (color: string) => {
    setAccentColor(color);
    localStorage.setItem('cockpit_accent_color', color);
    showNotification(`تم تغيير لون التمييز بنجاح إلى (${color}) وحفظه في التفضيلات`);
  };

  // Helper colors based on accent
  const getAccentStyles = () => {
    switch (accentColor) {
      case 'emerald':
        return {
          primaryBg: 'bg-emerald-500',
          primaryBorder: 'border-emerald-500',
          primaryText: 'text-emerald-400',
          glow: 'shadow-emerald-500/20',
          badgeBg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
          activeTab: 'bg-emerald-500/20 text-emerald-300 border-emerald-400 font-bold shadow-lg shadow-emerald-500/20'
        };
      case 'blue':
        return {
          primaryBg: 'bg-blue-600',
          primaryBorder: 'border-blue-500',
          primaryText: 'text-blue-400',
          glow: 'shadow-blue-500/20',
          badgeBg: 'bg-blue-500/10 text-blue-300 border-blue-500/30',
          activeTab: 'bg-blue-500/20 text-blue-300 border-blue-400 font-bold shadow-lg shadow-blue-500/20'
        };
      case 'purple':
        return {
          primaryBg: 'bg-purple-600',
          primaryBorder: 'border-purple-500',
          primaryText: 'text-purple-400',
          glow: 'shadow-purple-500/20',
          badgeBg: 'bg-purple-500/10 text-purple-300 border-purple-500/30',
          activeTab: 'bg-purple-500/20 text-purple-300 border-purple-400 font-bold shadow-lg shadow-purple-500/20'
        };
      case 'amber':
        return {
          primaryBg: 'bg-amber-500',
          primaryBorder: 'border-amber-500',
          primaryText: 'text-amber-400',
          glow: 'shadow-amber-500/20',
          badgeBg: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
          activeTab: 'bg-amber-500/20 text-amber-300 border-amber-400 font-bold shadow-lg shadow-amber-500/20'
        };
      case 'cyan':
      default:
        return {
          primaryBg: 'bg-cyan-500',
          primaryBorder: 'border-cyan-400',
          primaryText: 'text-cyan-400',
          glow: 'shadow-cyan-500/20',
          badgeBg: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30',
          activeTab: 'bg-cyan-500/20 text-cyan-300 border-cyan-400 font-bold shadow-lg shadow-cyan-500/20'
        };
    }
  };

  const currentTheme = getAccentStyles();

  // Generator simulation
  const handleGenerateContent = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const newPost: ScheduledPost = {
        id: `gen-${Date.now()}`,
        title: generatorIdea ? `${generatorIdea.slice(0, 35)}...` : 'قصة نجاح وعلاج رهبة الماء (4:5)',
        platform: (generatorPlatform as any) || 'TikTok',
        aspectRatio: generatorPlatform === 'TikTok' ? '9:16' : '4:5',
        templateType: 'قصة نجاح وعلاج رهبة الماء (4:5)',
        scheduledTime: 'اليوم 08:30 م',
        hookCaption: generatorIdea 
          ? `💡 فكرة جديدة: ${generatorIdea}\n\nنصائح عملية من الكوتش أيمن لتطبيقها فوراً في تدريب السباحة اليومي.\n📍 فروع أبوظبي: الكورنيش، المشرف، البطين.`
          : 'من الخوف من وضع الوجه تحت الماء إلى السباحة لمسافة 50 متراً بكل هدوء! شاهد كيف تغلب المشترك سعيد على الفوبيا في أسبوعين.',
        brief: 'مشاهد متتابعة قبل وبعد التدريب مع موسيقى محفزة ونص عريض واضح للقراءة السريعة.',
        status: 'needs_review',
        showPoster: true,
        branch: 'أبوظبي: البطين'
      };
      setReviewPosts([newPost, ...reviewPosts]);
      setIsGenerating(false);
      showNotification('تم توليد المحتوى بنجاح وإضافته إلى (بانتظار المراجعة والاعتماد)!');
    }, 1200);
  };

  // Schedule generator simulation (7 posts)
  const handleAutoWeeklySchedule = () => {
    showNotification('جاري جدولة 7 منشورات ذكية موزعة على أيام الأسبوع وفروع أبوظبي...');
    setTimeout(() => {
      showNotification('تمت الجدولة الأسبوعية التلقائية بنجاح! تم تجهيز 7 منشورات في الكوكبيت.');
    }, 1500);
  };

  // Approve post
  const handleApprovePost = (id: string) => {
    const post = reviewPosts.find(p => p.id === id);
    if (post) {
      setReviewPosts(reviewPosts.filter(p => p.id !== id));
      setScheduledPosts([{ ...post, status: 'scheduled' }, ...scheduledPosts]);
      showNotification('تم اعتماد المنشور بنجاح ونقله إلى قائمة الجدولة والنشر!');
    }
  };

  // Toggle poster visibility
  const togglePoster = (id: string) => {
    setReviewPosts(reviewPosts.map(p => {
      if (p.id === id) return { ...p, showPoster: !p.showPoster };
      return p;
    }));
  };

  // Update post field
  const updatePostField = (id: string, field: keyof ScheduledPost, val: any) => {
    setReviewPosts(reviewPosts.map(p => {
      if (p.id === id) return { ...p, [field]: val };
      return p;
    }));
  };

  // Real Publish Now Handler (Invokes Meta Graph API & Safe Content Publisher)
  const handlePublishNow = async (post: ScheduledPost) => {
    setPublishingPostId(post.id);
    showNotification(`جاري استدعاء Meta Graph API لنشر: ${post.title}...`);

    try {
      const res = await fetch('/api/meta/publish-now', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          postId: post.id,
          title: post.title,
          hookCaption: post.hookCaption,
          platform: post.platform,
          branch: post.branch,
          aspectRatio: post.aspectRatio,
          templateType: post.templateType,
          author: 'Ayman Mahrous (الموظف المعتمد)'
        })
      });

      const data = await res.json();
      if (data?.success && data.receipt) {
        setActiveReceipt(data.receipt);
        setIsReceiptModalOpen(true);
        setReceiptsList(prev => [data.receipt, ...prev]);

        // Remove from review or scheduled posts
        setReviewPosts(prev => prev.filter(p => p.id !== post.id));
        setScheduledPosts(prev => prev.filter(p => p.id !== post.id));

        showNotification(`🎉 تم النشر بنجاح! تم استخراج Facebook Post ID: ${data.receipt.facebookPostId}`);
      } else {
        showNotification(`فشل النشر: ${data?.error || 'خطأ غير معروف في واجهة Meta'}`);
      }
    } catch (err: any) {
      showNotification(`تعذر الاتصال بخادم النشر: ${err.message}`);
    } finally {
      setPublishingPostId(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#070e17] text-slate-100 flex flex-col font-sans antialiased selection:bg-cyan-500 selection:text-black" dir="rtl">
      
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-14 left-1/2 transform -translate-x-1/2 z-50 bg-[#0c1f2e] text-cyan-300 px-5 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-bounce border border-cyan-500/40">
          <CheckCircle2 className="w-4 h-4 text-cyan-400" />
          <span>{notification}</span>
        </div>
      )}

      {/* Topmost Control Bar & Switcher */}
      <div className="bg-[#050b12] border-b border-cyan-950/80 px-4 py-2 text-xs flex items-center justify-between text-slate-400">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-cyan-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            معاينة حية للمشروع: Coach Ayman Cockpit (الواجهة المعتمدة)
          </span>
          <span className="hidden md:inline text-slate-500 text-[11px]">
            فروع أبوظبي: الكورنيش • البطين • المشرف | السباحة والاسترخاء (Swim Fluent & Relax Fix UAE)
          </span>
        </div>
        <div className="flex items-center gap-2">
          {/* Accent Color Trigger with Tooltip */}
          <div className="relative group/tip">
            <button 
              onClick={() => setShowColorModal(true)}
              className="px-2.5 py-1 bg-[#0d1a29] hover:bg-[#13273e] text-cyan-300 rounded-lg border border-cyan-800/50 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Palette className="w-3.5 h-3.5" />
              <span>تخصيص الألوان</span>
            </button>
            <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-[#091522] text-cyan-300 text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-cyan-700/80">
              <span>تغيير لون التمييز وحفظه في التفضيلات</span>
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#091522] border-t border-l border-cyan-700/80 rotate-45" />
            </div>
          </div>

          {/* Settings & Webhooks Trigger */}
          <div className="relative group/tip">
            <button 
              id="cockpit-settings-webhooks-btn"
              onClick={() => setShowSettingsModal(true)}
              className="px-2.5 py-1 bg-[#0c1e33] hover:bg-[#122e4d] text-emerald-300 rounded-lg border border-emerald-700/50 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>إعدادات Webhooks والربط</span>
            </button>
            <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-[#091522] text-emerald-300 text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-emerald-700/80">
              <span>إدارة عناوين الـ Webhooks لـ WhatsApp و Messenger وفحص الاتصال</span>
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#091522] border-t border-l border-emerald-700/80 rotate-45" />
            </div>
          </div>

          {onClosePreview && (
            <div className="relative group/tip">
              <button 
                onClick={onClosePreview}
                className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-700 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
              >
                <span>العودة للملفات</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-slate-900 text-white text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-slate-700">
                <span>الرجوع إلى مستكشف ملفات Google Drive</span>
                <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-slate-900 border-t border-l border-slate-700 rotate-45" />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Connection Status Bar (Matches Image 1 & 2 Live Badges) */}
      <div className="bg-[#091522] border-b border-slate-800/80 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Facebook */}
          <div className="relative group/tip">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0d1b2a] border border-cyan-900/60 text-slate-200 cursor-help">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span className="font-semibold">Facebook</span>
              <span className="text-[10px] text-emerald-400 font-medium">(متصل)</span>
            </div>
            <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-[#091522] text-emerald-300 text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-emerald-700/80">
              <span>صفحة فيسبوك الرسمية متصلة ومفعّلة للنشر التلقائي</span>
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#091522] border-t border-l border-emerald-700/80 rotate-45" />
            </div>
          </div>

          {/* Instagram */}
          <div className="relative group/tip">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0d1b2a] border border-cyan-900/60 text-slate-200 cursor-help">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span className="font-semibold">Instagram</span>
              <span className="text-[10px] text-emerald-400 font-medium">(متصل)</span>
            </div>
            <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-[#091522] text-emerald-300 text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-emerald-700/80">
              <span>حساب إنستغرام للأعمال متصل ومفعل لنشر الريلز والبوستات</span>
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#091522] border-t border-l border-emerald-700/80 rotate-45" />
            </div>
          </div>

          {/* Canva & Gemini */}
          <div className="relative group/tip">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0d1b2a] border border-cyan-900/60 text-slate-200 cursor-help">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span className="font-semibold">Canva & Gemini AI</span>
              <span className="text-[10px] text-cyan-400 font-medium">(متصل)</span>
            </div>
            <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-[#091522] text-cyan-300 text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-cyan-700/80">
              <span>Canva Developer API & Gemini 2.5 Flash متصلان لتوليد القوالب</span>
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#091522] border-t border-l border-cyan-700/80 rotate-45" />
            </div>
          </div>

          {/* Coach Brain */}
          <div className="relative group/tip">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0d1b2a] border border-cyan-900/60 text-slate-200 cursor-help">
              <span className="text-cyan-400">🧠</span>
              <span className="font-semibold">كوتش براين</span>
              <span className="text-[10px] text-emerald-400 font-medium">(نشط)</span>
            </div>
            <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-[#091522] text-cyan-300 text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-cyan-700/80">
              <span>العقل المعرفي المعتمد لأكاديمية السباحة وفروع أبوظبي الثلاثة</span>
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#091522] border-t border-l border-cyan-700/80 rotate-45" />
            </div>
          </div>

          {/* WhatsApp */}
          <div className="relative group/tip">
            <button 
              onClick={() => setActiveTab('whatsapp')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0d1b2a] hover:bg-[#14283d] border border-emerald-900/60 text-slate-200 transition-colors cursor-pointer"
            >
              <span className="text-emerald-400">💬</span>
              <span className="font-semibold">WhatsApp (n8n)</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded-full font-bold">2</span>
            </button>
            <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-[#091522] text-emerald-300 text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-emerald-700/80">
              <span>وارد واتساب المربوط ببوت n8n السحابي</span>
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#091522] border-t border-l border-emerald-700/80 rotate-45" />
            </div>
          </div>

          {/* Messenger */}
          <div className="relative group/tip">
            <button 
              onClick={() => setActiveTab('whatsapp')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0d1b2a] hover:bg-[#14283d] border border-blue-900/60 text-slate-200 transition-colors cursor-pointer"
            >
              <span className="text-blue-400">⚡</span>
              <span className="font-semibold">Messenger (n8n)</span>
              <span className="text-[10px] bg-blue-500/20 text-blue-300 px-1.5 py-0.2 rounded-full font-bold">1</span>
            </button>
            <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-[#091522] text-blue-300 text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-blue-700/80">
              <span>وارد فيسبوك مسنجر المربوط بأتمتة n8n</span>
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#091522] border-t border-l border-blue-700/80 rotate-45" />
            </div>
          </div>

          {/* n8n Status & Test Connection Button */}
          <div className="relative group/tip">
            <button 
              onClick={() => setShowN8nModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gradient-to-r from-emerald-950/80 to-[#0d1b2a] hover:from-emerald-900/90 hover:to-[#13273e] border border-emerald-500/50 text-emerald-300 transition-all cursor-pointer shadow-xs hover:shadow"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <Radio className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-bold text-[11px]">اختبار ربط n8n</span>
            </button>
            <div className="pointer-events-none absolute top-full mt-2 left-1/2 -translate-x-1/2 hidden group-hover/tip:flex items-center gap-1 px-2.5 py-1 bg-[#091522] text-emerald-300 text-[11px] rounded-lg shadow-2xl whitespace-nowrap z-50 border border-emerald-700/80">
              <span>فحص حالة ربط n8n النشطة واختبار الويبهوك ومحاكاة رسائل الواتساب</span>
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#091522] border-t border-l border-emerald-700/80 rotate-45" />
            </div>
          </div>
        </div>

        <div className="text-[11px] text-slate-400 flex items-center gap-2">
          <span>الحساب الإداري: <strong className="text-cyan-400">Coach Ayman Mahrous</strong></span>
        </div>
      </div>

      {/* Main Top Navigation Tabs (Exact matches Image 1, 2, 3) */}
      <nav className="bg-[#07131e] border-b border-cyan-950 px-4 py-2.5 sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-2 overflow-x-auto py-1 scrollbar-none w-full max-w-4xl">
          {/* 1. Cockpit */}
          <button 
            onClick={() => setActiveTab('cockpit')}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 transition-all shrink-0 border ${
              activeTab === 'cockpit'
                ? currentTheme.activeTab
                : 'bg-[#0a1827] text-slate-300 border-slate-800 hover:border-cyan-800 hover:text-white'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>المقصورة</span>
          </button>

          {/* 2. Coach Brain */}
          <button 
            onClick={() => setActiveTab('brain')}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 transition-all shrink-0 border ${
              activeTab === 'brain'
                ? currentTheme.activeTab
                : 'bg-[#0a1827] text-slate-300 border-slate-800 hover:border-cyan-800 hover:text-white'
            }`}
          >
            <span>🧠</span>
            <span>كوتش براين</span>
          </button>

          {/* 3. Content Factory (Active in Image 1 & 3) */}
          <button 
            onClick={() => setActiveTab('factory')}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 transition-all shrink-0 border ${
              activeTab === 'factory'
                ? currentTheme.activeTab
                : 'bg-[#0a1827] text-slate-300 border-slate-800 hover:border-cyan-800 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>مصنع المحتوى</span>
          </button>

          {/* 4. WhatsApp & Messenger via n8n */}
          <button 
            onClick={() => setActiveTab('whatsapp')}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 transition-all shrink-0 border ${
              activeTab === 'whatsapp'
                ? currentTheme.activeTab
                : 'bg-[#0a1827] text-slate-300 border-slate-800 hover:border-cyan-800 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>المحادثات (واتساب ومسنجر)</span>
          </button>

          {/* 5. Media (Active in Image 2) */}
          <button 
            onClick={() => setActiveTab('media')}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 transition-all shrink-0 border ${
              activeTab === 'media'
                ? currentTheme.activeTab
                : 'bg-[#0a1827] text-slate-300 border-slate-800 hover:border-cyan-800 hover:text-white'
            }`}
          >
            <FolderGit2 className="w-3.5 h-3.5" />
            <span>الوسائط</span>
          </button>
        </div>

        <div className="hidden lg:flex items-center gap-2 text-xs text-slate-400">
          <span className="font-mono text-cyan-400 text-[11px]">new-coach-mu.vercel.app</span>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 p-4 lg:p-6 max-w-7xl w-full mx-auto space-y-6">

        {/* ======================================================== */}
        {/* TAB 1: CONTENT FACTORY (مصنع المحتوى - EXACT IMAGE 1 & 3) */}
        {/* ======================================================== */}
        {activeTab === 'factory' && (
          <div className="space-y-6">
            
            {/* Header Title Section */}
            <div className="space-y-1">
              <h2 className="text-lg md:text-xl font-bold text-white flex items-center gap-2">
                <span>مصنع المحتوى الذكي</span>
                <span className="text-cyan-400 font-normal">— Swim Fluent & Relax Fix UAE</span>
                <span className="text-xs font-normal text-slate-400">(فروع أبوظبي: الكورنيش، البطين، المشرف)</span>
              </h2>
              <p className="text-xs text-slate-400">
                توليد ونشر آلي فوري، جدولة أسبوعية، وصندوق حماية ذهبي للتحكم المطلق قبل النشر.
              </p>
            </div>

            {/* Mode Pills (Image 1 top pills) */}
            <div className="flex flex-wrap items-center gap-2">
              <button 
                onClick={() => setPlanMode('3days')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors border ${
                  planMode === '3days'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400'
                    : 'bg-[#0c1926] text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                3 أيام متنوعة
              </button>

              <button 
                onClick={() => setPlanMode('weekly')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors border ${
                  planMode === 'weekly'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400'
                    : 'bg-[#0c1926] text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                خطة أسبوعية
              </button>

              <button 
                onClick={() => setPlanMode('monthly')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors border ${
                  planMode === 'monthly'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400'
                    : 'bg-[#0c1926] text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                خطة شهرية كاملة (30 يوم)
              </button>

              <button 
                onClick={() => setPlanMode('custom')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors border ${
                  planMode === 'custom'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400'
                    : 'bg-[#0c1926] text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                فكرة مخصصة
              </button>
            </div>

            {/* Quick Generator Box (Image 1 Generator Controls) */}
            <div className="bg-[#0b1724] border border-cyan-950/80 rounded-2xl p-4 space-y-4 shadow-xl">
              <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
                {/* Platform select */}
                <div className="w-full md:w-48">
                  <label className="text-[11px] text-slate-400 block mb-1">المنصة المستهدفة:</label>
                  <select 
                    value={generatorPlatform}
                    onChange={(e) => setGeneratorPlatform(e.target.value)}
                    className="w-full bg-[#07111b] border border-cyan-900/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="TikTok">TikTok (تيك توك)</option>
                    <option value="Instagram">Instagram (إنستغرام)</option>
                    <option value="Facebook">Facebook (فيسبوك)</option>
                    <option value="YouTube Shorts">YouTube Shorts</option>
                  </select>
                </div>

                {/* Idea text */}
                <div className="flex-1">
                  <label className="text-[11px] text-slate-400 block mb-1">فكرة المنشور أو اتركها للكوتش براين:</label>
                  <input 
                    type="text" 
                    value={generatorIdea}
                    onChange={(e) => setGeneratorIdea(e.target.value)}
                    placeholder="اكتب فكرة المنشور هنا أو اضغط توليد فكرة من الكوتش براين..."
                    className="w-full bg-[#07111b] border border-cyan-900/60 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Action Buttons Row (Matches Image 1 Buttons) */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-cyan-950">
                <div className="flex flex-wrap items-center gap-2">
                  <button 
                    onClick={handleAutoWeeklySchedule}
                    className="px-4 py-2 bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-600 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-900/30 flex items-center gap-2 transition-transform active:scale-95"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>جدولة أسبوعية تلقائية (7 منشورات)</span>
                  </button>

                  <button 
                    onClick={handleGenerateContent}
                    disabled={isGenerating}
                    className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-black rounded-xl text-xs font-bold shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition-transform active:scale-95 disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isGenerating ? 'جاري التوليد من براين...' : `توليد محتوى الآن (${generatorPlatform})`}</span>
                  </button>
                </div>

                <button 
                  onClick={() => showNotification('فتح نافذة النشر الفوري المباشر')}
                  className="px-4 py-2 bg-[#0d1e2e] hover:bg-[#152e47] text-cyan-300 border border-cyan-800/60 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>نشر يدوي الآن</span>
                </button>
              </div>
            </div>

            {/* ======================================================== */}
            {/* SECTION 1: بانتظار المراجعة والاعتماد (EXACT MATCH IMAGE 3) */}
            {/* ======================================================== */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
                  <span>بانتظار المراجعة والاعتماد ({reviewPosts.length})</span>
                </h3>
                <span className="text-xs text-slate-400">تحتاج موافقتك الصريحة قبل دخول جدول النشر</span>
              </div>

              {reviewPosts.length === 0 ? (
                <div className="bg-[#0b1724] border border-cyan-950/60 rounded-2xl p-8 text-center text-slate-400 text-xs">
                  لا توجد عناصر بانتظار المراجعة حالياً. اضغط "توليد محتوى الآن" لإضافة منشور جديد.
                </div>
              ) : (
                reviewPosts.map((post) => (
                  <div 
                    key={post.id}
                    className="bg-[#08131e] border border-cyan-800/40 rounded-2xl p-5 space-y-4 shadow-2xl relative overflow-hidden"
                  >
                    {/* Top Card Row (Status, 9:16, Platform, Title, Poster Toggle) */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-cyan-950/80 pb-3">
                      <div className="flex items-center gap-2.5 flex-wrap">
                        <span className="text-[10px] bg-slate-800 text-slate-300 border border-slate-700 px-2.5 py-0.5 rounded-md font-bold">
                          Needs Review
                        </span>
                        <span className="text-[10px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-md font-mono font-bold">
                          {post.aspectRatio}
                        </span>
                        <span className="text-[10px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 px-2.5 py-0.5 rounded-md font-bold">
                          {post.platform}
                        </span>
                        <span className="text-sm font-bold text-white mr-1 flex items-center gap-1.5">
                          <Video className="w-4 h-4 text-cyan-400" />
                          <span>{post.title}</span>
                        </span>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-auto">
                        <button 
                          onClick={() => togglePoster(post.id)}
                          className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 bg-[#0e1d2c] px-3 py-1.5 rounded-lg border border-cyan-900 transition-colors"
                        >
                          {post.showPoster ? (
                            <>
                              <EyeOff className="w-3.5 h-3.5" />
                              <span>إخفاء البوستر</span>
                            </>
                          ) : (
                            <>
                              <Eye className="w-3.5 h-3.5" />
                              <span>عرض البوستر</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Visual Poster Mockup (Shown when showPoster is true) */}
                    {post.showPoster && (
                      <div className="bg-[#040b12] border border-cyan-950 rounded-xl p-3 flex flex-col sm:flex-row items-center gap-4">
                        <div className="w-36 h-56 bg-gradient-to-b from-blue-900 via-cyan-950 to-slate-900 rounded-lg border border-cyan-700/50 flex flex-col justify-between p-2.5 text-center shrink-0 shadow-lg relative overflow-hidden">
                          <div className="flex items-center justify-between text-[9px] text-cyan-300 font-bold">
                            <span>SWIM FLUENT</span>
                            <span>9:16</span>
                          </div>
                          <div className="space-y-1 my-auto">
                            <span className="text-2xl">🏊‍♂️</span>
                            <p className="text-[10px] font-bold text-white leading-tight">
                              تصحيح تكنيك الذراع والتنفس
                            </p>
                            <span className="text-[8px] bg-cyan-500/30 text-cyan-200 px-1.5 py-0.2 rounded-full inline-block">
                              فروع أبوظبي
                            </span>
                          </div>
                          <div className="text-[8px] text-slate-400 border-t border-cyan-900/60 pt-1">
                            Coach Ayman Mahrous
                          </div>
                        </div>

                        <div className="flex-1 space-y-2 text-xs text-slate-300">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-cyan-400">معاينة ريلز إنستغرام الذكي:</span>
                            <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded">Canva Brief Ready</span>
                          </div>
                          <p className="text-[11px] text-slate-400 leading-relaxed">
                            تم تجهيز الإطار والأبعاد المعتمدة 1080x1920 (9:16). يمكنك تعديل نص المنشور والخطاف بالأسفل أو الحفظ لنقل المنشور مباشرة إلى جدول النشر الآلي.
                          </p>
                          <div className="flex items-center gap-3 text-[11px] text-slate-400">
                            <span>الفرع: <strong className="text-slate-200">{post.branch}</strong></span>
                            <span>•</span>
                            <span>الهدف: <strong className="text-slate-200">تعليم وتفاعل واستقطاب متدربين</strong></span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Dropdowns Row (المنصة & نوع القالب والتصميم) */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                          المنصة:
                        </label>
                        <select 
                          value={post.platform}
                          onChange={(e) => updatePostField(post.id, 'platform', e.target.value)}
                          className="w-full bg-[#061019] border border-cyan-900/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                        >
                          <option value="Instagram">Instagram (إنستغرام)</option>
                          <option value="TikTok">TikTok (تيك توك)</option>
                          <option value="Facebook">Facebook (فيسبوك)</option>
                          <option value="YouTube Shorts">YouTube Shorts</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                          نوع القالب والتصميم:
                        </label>
                        <select 
                          value={post.templateType}
                          onChange={(e) => updatePostField(post.id, 'templateType', e.target.value)}
                          className="w-full bg-[#061019] border border-cyan-900/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                        >
                          <option value="ريلز تكتيك وتصحيح تكنيك (9:16)">ريلز تكتيك وتصحيح تكنيك (9:16)</option>
                          <option value="إنفوجرافيك خطوات تعليمية (4:5)">إنفوجرافيك خطوات تعليمية (4:5)</option>
                          <option value="قصة نجاح وعلاج رهبة الماء (4:5)">قصة نجاح وعلاج رهبة الماء (4:5)</option>
                          <option value="عرض باقات فروع أبوظبي (1:1)">عرض باقات فروع أبوظبي (1:1)</option>
                          <option value="سؤال وتحدي تفاعلي للجمهور (9:16)">سؤال وتحدي تفاعلي للجمهور (9:16)</option>
                        </select>
                      </div>
                    </div>

                    {/* Textarea 1: نص المنشور والخطاف */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                        نص المنشور والخطاف:
                      </label>
                      <textarea 
                        rows={4}
                        value={post.hookCaption}
                        onChange={(e) => updatePostField(post.id, 'hookCaption', e.target.value)}
                        className="w-full bg-[#061019] border border-cyan-900/80 rounded-xl p-3 text-xs text-slate-100 focus:outline-none focus:border-cyan-400 leading-relaxed font-sans"
                        placeholder="اكتب أو عدل نص المنشور والخطاف..."
                      />
                    </div>

                    {/* Textarea 2: موجز التصميم وهوية القالب */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                        موجز التصميم وهوية القالب:
                      </label>
                      <textarea 
                        rows={2}
                        value={post.brief}
                        onChange={(e) => updatePostField(post.id, 'brief', e.target.value)}
                        className="w-full bg-[#061019] border border-cyan-900/80 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 leading-relaxed font-sans"
                        placeholder="موجز توجيهات التصميم وأبعاد الهوية..."
                      />
                    </div>

                    {/* Card Actions Row (حفظ، اعتماد، نشر فوري، توليد بديل) */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-cyan-950/80">
                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Save Button (Matches Image 3 حفظ) */}
                        <button 
                          onClick={() => showNotification('تم حفظ التعديلات بنجاح')}
                          className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold rounded-xl shadow-md shadow-cyan-500/20 transition-all active:scale-95 cursor-pointer"
                        >
                          حفظ
                        </button>

                        {/* Publish Now Direct Button */}
                        <button 
                          onClick={() => handlePublishNow(post)}
                          disabled={publishingPostId === post.id}
                          className="px-4 py-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-600/30 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer disabled:opacity-50"
                        >
                          {publishingPostId === post.id ? (
                            <>
                              <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                              <span>جارٍ النشر...</span>
                            </>
                          ) : (
                            <>
                              <span>🚀</span>
                              <span>نشر الآن (Meta Live)</span>
                            </>
                          )}
                        </button>

                        {/* Approve to Schedule */}
                        <button 
                          onClick={() => handleApprovePost(post.id)}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>اعتماد ونقل للجدولة</span>
                        </button>

                        {/* Regenerate alternative */}
                        <button 
                          onClick={() => {
                            showNotification('جاري توليد صيغة بديلة للخطاف والتصميم...');
                            setTimeout(() => {
                              updatePostField(post.id, 'hookCaption', '⚠️ هل تعلم أن كتم النفس تحت الماء يسبب تشنج العضلات؟ إليك التكنيك الصحيح لإخراج الزفير ببطء مع كوتش أيمن في فرع الكورنيش!');
                              showNotification('تم توليد صيغة بديلة بنجاح');
                            }, 800);
                          }}
                          className="px-3.5 py-2 bg-[#0c1a28] hover:bg-[#122438] text-slate-300 hover:text-white text-xs font-semibold rounded-xl border border-cyan-900/60 transition-colors"
                        >
                          <RotateCcw className="w-3.5 h-3.5 inline mr-1 text-cyan-400" />
                          <span>توليد بديل</span>
                        </button>
                      </div>

                      <button 
                        onClick={() => {
                          setReviewPosts(reviewPosts.filter(p => p.id !== post.id));
                          showNotification('تم نقل المنشور إلى سلة الأرشيف بنجاح');
                        }}
                        className="text-xs text-rose-400 hover:text-rose-300 font-semibold p-2"
                      >
                        أرشفة المنشور
                      </button>
                    </div>

                  </div>
                ))
              )}
            </div>

            {/* ======================================================== */}
            {/* SECTION 2: مجدولة ومجهزة للنشر (0 / 1)                     */}
            {/* ======================================================== */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Clock className="w-4 h-4 text-emerald-400" />
                  <span>مجدولة ومجهزة للنشر ({scheduledPosts.length})</span>
                </h3>
                <span className="text-xs text-slate-400">ستُنشر آلياً وفق الموعد المحدد عبر Meta & TikTok APIs</span>
              </div>

              {scheduledPosts.length === 0 ? (
                <div className="bg-[#0b1724] border border-cyan-950/60 rounded-2xl p-6 text-center text-slate-400 text-xs">
                  لا توجد منشورات مجدولة حالياً. اعتمد منشوراً من القائمة أعلاه لنقله للجدولة.
                </div>
              ) : (
                scheduledPosts.map((post) => (
                  <div 
                    key={post.id}
                    className="bg-[#091522] border border-emerald-900/40 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold shrink-0">
                        ✓
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold text-white">{post.title}</span>
                          <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono">
                            {post.scheduledTime}
                          </span>
                          <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded">
                            {post.platform}
                          </span>
                        </div>
                        <p className="text-xs text-slate-300 line-clamp-1">{post.hookCaption}</p>
                        <span className="text-[10px] text-slate-400">{post.branch}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button 
                        onClick={() => handlePublishNow(post)}
                        disabled={publishingPostId === post.id}
                        className="px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                      >
                        {publishingPostId === post.id ? (
                          <>
                            <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            <span>جارٍ النشر...</span>
                          </>
                        ) : (
                          <>
                            <span>🚀</span>
                            <span>نشر الآن فوراً (Meta Live)</span>
                          </>
                        )}
                      </button>
                      <button 
                        onClick={() => {
                          setScheduledPosts(scheduledPosts.filter(p => p.id !== post.id));
                          setReviewPosts([...reviewPosts, post]);
                          showNotification('تمت إعادة المنشور إلى مرحلة المراجعة');
                        }}
                        className="px-3 py-1.5 bg-[#0b1724] hover:bg-[#122438] text-slate-300 text-xs rounded-xl border border-slate-700 cursor-pointer"
                      >
                        إلغاء وتعديل
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* ======================================================== */}
            {/* SECTION 3: سجل إيصالات النشر المعتمدة (Live Meta Receipts) */}
            {/* ======================================================== */}
            <div className="space-y-3 pt-4 border-t border-cyan-950/80">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span className="text-emerald-400">📜</span>
                  <span>سجل إيصالات النشر المعتمدة — Meta & Safe Publisher ({receiptsList.length})</span>
                </h3>
                <span className="text-xs text-emerald-400 font-mono">
                  Safe Publisher V27 ACTIVE • RLS Bypassed
                </span>
              </div>

              {receiptsList.length === 0 ? (
                <div className="bg-[#0b1724] border border-cyan-950/60 rounded-2xl p-6 text-center text-slate-400 text-xs">
                  لا توجد إيصالات نشر حتى الآن. اضغط "نشر الآن" لنشر منشور إلى Meta وتوليد إيصال فوري.
                </div>
              ) : (
                <div className="space-y-2">
                  {receiptsList.map((rcp) => (
                    <div 
                      key={rcp.receiptId}
                      className="bg-[#07131e] border border-emerald-900/50 hover:border-emerald-500/50 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold shrink-0">
                          ✓
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-white">{rcp.title}</span>
                            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded font-mono font-bold">
                              {rcp.receiptId}
                            </span>
                            <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded">
                              {rcp.platform}
                            </span>
                            <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                              FB: {rcp.facebookPostId}
                            </span>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-slate-400">
                            <span>الفرع: <strong className="text-slate-200">{rcp.branch}</strong></span>
                            <span>•</span>
                            <span>المسؤول: <strong className="text-emerald-400">{rcp.author}</strong></span>
                            <span>•</span>
                            <span className="font-mono text-[10px] text-slate-400">
                              {new Date(rcp.publishedAt).toLocaleDateString('ar-AE')}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 flex-wrap">
                        {rcp.facebookUrl && (
                          <a
                            href={rcp.facebookUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3 py-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-600/40 text-xs font-semibold rounded-xl flex items-center gap-1 transition-all"
                          >
                            <span>فيسبوك</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}

                        {rcp.instagramUrl && (
                          <a
                            href={rcp.instagramUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3 py-1.5 bg-pink-600/20 hover:bg-pink-600/30 text-pink-300 border border-pink-600/40 text-xs font-semibold rounded-xl flex items-center gap-1 transition-all"
                          >
                            <span>إنستغرام</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}

                        <button 
                          onClick={() => {
                            setActiveReceipt(rcp);
                            setIsReceiptModalOpen(true);
                          }}
                          className="px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
                        >
                          عرض بطاقة الإيصال الرسمية
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: MEDIA STUDIO (الوسائط - EXACT MATCH IMAGE 2)        */}
        {/* ======================================================== */}
        {activeTab === 'media' && (
          <div className="space-y-6">
            
            {/* Header & Subtitle */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <h2 className="text-lg md:text-xl font-bold text-white flex items-center gap-2">
                  <span>استوديو ومخزن الوسائط المرئية الذكي</span>
                  <span className="text-cyan-400 font-normal">— Canva & Gemini AI</span>
                </h2>
                <p className="text-xs text-slate-400">
                  فروع أبوظبي (الكورنيش، البطين، المشرف) — قوالب هوية معتمدة لكل مقاسات النشر (1:1, 4:5, 9:16).
                </p>
              </div>

              {/* Big Action Button (Image 2) */}
              <button 
                onClick={() => showNotification('تم فتح نافذة اختيار ورفع الملفات من جهازك')}
                className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-black rounded-xl text-xs font-bold shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 transition-transform active:scale-95"
              >
                <Upload className="w-4 h-4" />
                <span>رفع وسائط من جهازك</span>
              </button>
            </div>

            {/* Status Chips (Image 2) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="bg-[#0b1724] border border-cyan-900/60 rounded-xl p-3 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-400 text-[11px] block">بوابة المطور:</span>
                  <span className="font-bold text-white">Canva Developer Portal</span>
                </div>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono">
                  متصل (1066347...)
                </span>
              </div>

              <div className="bg-[#0b1724] border border-cyan-900/60 rounded-xl p-3 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-400 text-[11px] block">الذكاء الاصطناعي:</span>
                  <span className="font-bold text-white">Gemini 2.5 Flash / Imagen</span>
                </div>
                <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded font-mono">
                  جاهز للتوليد
                </span>
              </div>

              <div className="bg-[#0b1724] border border-cyan-900/60 rounded-xl p-3 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-400 text-[11px] block">الأرشيف السحابي:</span>
                  <span className="font-bold text-white">Google Drive Connected</span>
                </div>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono">
                  142 ملفاً متزامناً
                </span>
              </div>
            </div>

            {/* Format Starter Cards (1:1, 4:5, 9:16) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-[#08131e] border border-cyan-900/50 hover:border-cyan-500/50 rounded-2xl p-4 text-center space-y-2 transition-all">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto text-lg font-bold">
                  1:1
                </div>
                <h4 className="text-xs font-bold text-white">بوست مربع (1080x1080)</h4>
                <p className="text-[11px] text-slate-400">عروض الاشتراكات والباقات لفروع أبوظبي</p>
                <button 
                  onClick={() => showNotification('فتح محرر Canva لقالب 1:1')}
                  className="text-xs text-cyan-400 hover:underline font-semibold"
                >
                  فتح القالب المعتمد ↗
                </button>
              </div>

              <div className="bg-[#08131e] border border-cyan-900/50 hover:border-cyan-500/50 rounded-2xl p-4 text-center space-y-2 transition-all">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto text-lg font-bold">
                  4:5
                </div>
                <h4 className="text-xs font-bold text-white">إنفوجرافيك عمودي (1080x1350)</h4>
                <p className="text-[11px] text-slate-400">كاروسيل تعليمي وخطوات التكنيك وعلاج الفوبيا</p>
                <button 
                  onClick={() => showNotification('فتح محرر Canva لقالب 4:5')}
                  className="text-xs text-emerald-400 hover:underline font-semibold"
                >
                  فتح القالب المعتمد ↗
                </button>
              </div>

              <div className="bg-[#08131e] border border-cyan-900/50 hover:border-cyan-500/50 rounded-2xl p-4 text-center space-y-2 transition-all">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mx-auto text-lg font-bold">
                  9:16
                </div>
                <h4 className="text-xs font-bold text-white">ريلز وستوري وتيك توك (1080x1920)</h4>
                <p className="text-[11px] text-slate-400">فيديوهات تصحيح الحركة وتوثيق نتائج المتدربين</p>
                <button 
                  onClick={() => showNotification('فتح محرر Canva لقالب 9:16')}
                  className="text-xs text-purple-400 hover:underline font-semibold"
                >
                  فتح القالب المعتمد ↗
                </button>
              </div>
            </div>

            {/* Filter Tabs (Image 2) */}
            <div className="flex flex-wrap items-center gap-1.5 border-b border-cyan-950 pb-2 text-xs">
              <button 
                onClick={() => setMediaFilter('all')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  mediaFilter === 'all'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                كل الوسائط (142)
              </button>

              <button 
                onClick={() => setMediaFilter('review')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  mediaFilter === 'review'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                بانتظار المراجعة (4)
              </button>

              <button 
                onClick={() => setMediaFilter('approved')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  mediaFilter === 'approved'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                معتمدة (118)
              </button>

              <button 
                onClick={() => setMediaFilter('external')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  mediaFilter === 'external'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                مصادر خارجية (Drive / Canva)
              </button>

              <button 
                onClick={() => setMediaFilter('archive')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  mediaFilter === 'archive'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                الأرشيف
              </button>

              <button 
                onClick={() => setMediaFilter('trash')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  mediaFilter === 'trash'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                سلة المحذوفات
              </button>
            </div>

            {/* Media Asset Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              <div className="bg-[#091522] border border-cyan-900/40 hover:border-cyan-400/60 rounded-2xl p-2.5 space-y-2 transition-all group">
                <div className="aspect-square rounded-xl bg-[#050e17] flex items-center justify-center text-3xl relative overflow-hidden">
                  🏊‍♂️
                  <span className="absolute top-1.5 right-1.5 text-[9px] bg-cyan-500 text-black font-bold px-1.5 py-0.5 rounded">
                    9:16
                  </span>
                </div>
                <div>
                  <p className="text-xs font-bold text-white truncate">freestyle_drill_corniche.mp4</p>
                  <p className="text-[10px] text-slate-400">Reel • فرع الكورنيش</p>
                </div>
              </div>

              <div className="bg-[#091522] border border-cyan-900/40 hover:border-cyan-400/60 rounded-2xl p-2.5 space-y-2 transition-all group">
                <div className="aspect-square rounded-xl bg-[#050e17] flex items-center justify-center text-3xl relative overflow-hidden">
                  🌊
                  <span className="absolute top-1.5 right-1.5 text-[9px] bg-emerald-500 text-white font-bold px-1.5 py-0.5 rounded">
                    4:5
                  </span>
                </div>
                <div>
                  <p className="text-xs font-bold text-white truncate">relax_fix_water_phobia.png</p>
                  <p className="text-[10px] text-slate-400">Canva Design • معتمد</p>
                </div>
              </div>

              <div className="bg-[#091522] border border-cyan-900/40 hover:border-cyan-400/60 rounded-2xl p-2.5 space-y-2 transition-all group">
                <div className="aspect-square rounded-xl bg-[#050e17] flex items-center justify-center text-3xl relative overflow-hidden">
                  🏆
                  <span className="absolute top-1.5 right-1.5 text-[9px] bg-amber-500 text-black font-bold px-1.5 py-0.5 rounded">
                    1:1
                  </span>
                </div>
                <div>
                  <p className="text-xs font-bold text-white truncate">abu_dhabi_packages_offer.png</p>
                  <p className="text-[10px] text-slate-400">Promo Card • 1:1</p>
                </div>
              </div>

              <div className="bg-[#091522] border border-cyan-900/40 hover:border-cyan-400/60 rounded-2xl p-2.5 space-y-2 transition-all group">
                <div className="aspect-square rounded-xl bg-[#050e17] flex items-center justify-center text-3xl relative overflow-hidden">
                  🧒
                  <span className="absolute top-1.5 right-1.5 text-[9px] bg-purple-500 text-white font-bold px-1.5 py-0.5 rounded">
                    9:16
                  </span>
                </div>
                <div>
                  <p className="text-xs font-bold text-white truncate">kids_swimming_bateen.mp4</p>
                  <p className="text-[10px] text-slate-400">موافقة موثقة • البطين</p>
                </div>
              </div>

              <div className="bg-[#091522] border border-cyan-900/40 hover:border-cyan-400/60 rounded-2xl p-2.5 space-y-2 transition-all group">
                <div className="aspect-square rounded-xl bg-[#050e17] flex items-center justify-center text-3xl relative overflow-hidden">
                  🏅
                  <span className="absolute top-1.5 right-1.5 text-[9px] bg-emerald-500 text-white font-bold px-1.5 py-0.5 rounded">
                    1:1
                  </span>
                </div>
                <div>
                  <p className="text-xs font-bold text-white truncate">certificate_achievement.jpg</p>
                  <p className="text-[10px] text-slate-400">فرع المشرف • معتمد</p>
                </div>
              </div>

              <div className="bg-[#091522] border border-cyan-900/40 hover:border-cyan-400/60 rounded-2xl p-2.5 space-y-2 transition-all group">
                <div className="aspect-square rounded-xl bg-[#050e17] flex items-center justify-center text-3xl relative overflow-hidden">
                  📸
                  <span className="absolute top-1.5 right-1.5 text-[9px] bg-blue-500 text-white font-bold px-1.5 py-0.5 rounded">
                    Drive
                  </span>
                </div>
                <div>
                  <p className="text-xs font-bold text-white truncate">raw_archive_session_09.mov</p>
                  <p className="text-[10px] text-slate-400">Google Drive Raw • 85 MB</p>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: COCKPIT (المقصورة / HOME)                           */}
        {/* ======================================================== */}
        {activeTab === 'cockpit' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white">غرفة القيادة والقرارات (المقصورة)</h2>
                <p className="text-xs text-slate-400 mt-1">نظرة عامة شمولية على فروع أبوظبي، القرارات المعلقة، وحالة الحملات.</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-3 py-1 rounded-full font-bold">
                  🟢 النظام يعمل بنسبة 100%
                </span>
              </div>
            </div>

            {/* Quick KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#091522] border border-cyan-900/60 rounded-2xl p-4 space-y-1">
                <span className="text-xs font-semibold text-slate-400">الحملة النشطة</span>
                <div className="text-2xl font-black text-white">Swim Fluent UAE</div>
                <p className="text-[11px] text-cyan-400">فروع الكورنيش، البطين، المشرف</p>
              </div>

              <div className="bg-[#091522] border border-cyan-900/60 rounded-2xl p-4 space-y-1">
                <span className="text-xs font-semibold text-slate-400">منشورات بانتظار القرار</span>
                <div className="text-2xl font-black text-amber-400">{reviewPosts.length} منشور</div>
                <p className="text-[11px] text-slate-400">تحتاج اعتماد المالك</p>
              </div>

              <div className="bg-[#091522] border border-cyan-900/60 rounded-2xl p-4 space-y-1">
                <span className="text-xs font-semibold text-slate-400">مجدولة وجاهزة للنشر</span>
                <div className="text-2xl font-black text-emerald-400">{scheduledPosts.length} منشورات</div>
                <p className="text-[11px] text-emerald-300">أوتوماتيكي عبر الـ APIs</p>
              </div>

              <div className="bg-[#091522] border border-cyan-900/60 rounded-2xl p-4 space-y-1">
                <span className="text-xs font-semibold text-slate-400">استفسارات واتساب اليوم</span>
                <div className="text-2xl font-black text-cyan-400">8 عملاء</div>
                <p className="text-[11px] text-slate-400">بانتظار تأكيد المواعيد</p>
              </div>
            </div>

            {/* Needs Your Decision Box */}
            <div className="bg-[#0b1724] border border-cyan-900/60 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                  <span>يحتاج قرارك الآن (Needs Your Decision)</span>
                </h3>
                <span className="text-xs text-slate-400">قرار فوري بنقرة واحدة</span>
              </div>

              <div className="bg-[#07111b] border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">اعتماد دفعة الـ 7 منشورات لأسبوع تدريب الأطفال في أبوظبي</span>
                    <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded">مخطط أسبوعي</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    توصية الذكاء الاصطناعي: تم توليد المنشورات متطابقة مع قوالب Canva EAHVAAahmjU وتوزيعها على أوقات الذروة.
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button 
                    onClick={() => setActiveTab('factory')}
                    className="px-3.5 py-1.5 bg-[#0e1d2c] text-cyan-300 border border-cyan-800 text-xs font-semibold rounded-xl"
                  >
                    فتح المصنع
                  </button>
                  <button 
                    onClick={() => showNotification('تم اعتماد الدفعة ونقلها للجدولة بنجاح!')}
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl"
                  >
                    اعتماد الكل
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 4: COACH BRAIN (كوتش براين — العقل الاستراتيجي)        */}
        {/* ======================================================== */}
        {activeTab === 'brain' && (
          <CoachBrainCenter
            onTransferIdeaToFactory={(idea, platform) => {
              setGeneratorIdea(idea);
              if (platform) setGeneratorPlatform(platform);
              setActiveTab('factory');
              showNotification('🚀 تم نقل الفكرة والمحتوى إلى مصنع الحملات بنجاح!');
            }}
            onBatchSchedulePosts={(newPosts) => {
              setScheduledPosts(prev => [...newPosts, ...prev]);
              setActiveTab('factory');
            }}
            onShowNotification={(msg) => showNotification(msg)}
            onOpenSettingsModal={() => setShowSettingsModal(true)}
            onOpenN8nModal={() => setShowN8nModal(true)}
            waConnected={true}
            msgConnected={true}
          />
        )}

        {/* ======================================================== */}
        {/* TAB 5: MULTI-CHANNEL CRM: WHATSAPP & MESSENGER VIA N8N   */}
        {/* ======================================================== */}
        {activeTab === 'whatsapp' && (() => {
          const activeConvo = conversations.find(c => c.id === selectedConvoId) || conversations[0];
          const filteredConvos = conversations.filter(c => {
            if (convoFilter === 'whatsapp') return c.platform === 'whatsapp';
            if (convoFilter === 'messenger') return c.platform === 'messenger';
            if (convoFilter === 'takeover') return c.needsHumanTakeover;
            if (convoFilter === 'bot') return c.n8nBotActive && !c.needsHumanTakeover;
            return true;
          });

          const handleSendReply = () => {
            if (!customReplyText.trim() || !activeConvo) return;
            const newMsg = {
              id: `msg-${Date.now()}`,
              sender: 'human_agent',
              text: customReplyText,
              timestamp: new Date().toLocaleTimeString('ar-AE', { hour: '2-digit', minute: '2-digit' }),
              platform: activeConvo.platform
            };
            setConversations(conversations.map(c => {
              if (c.id === activeConvo.id) {
                return {
                  ...c,
                  messages: [...c.messages, newMsg],
                  lastMessage: customReplyText,
                  lastMessageTime: newMsg.timestamp,
                  unreadCount: 0
                };
              }
              return c;
            }));
            const sentText = customReplyText;
            setCustomReplyText('');
            showNotification(`تم إرسال الرد بنجاح عبر ${activeConvo.platform === 'whatsapp' ? 'WhatsApp' : 'Facebook Messenger'} وتوثيقه في n8n!`);
          };

          const handleApproveAiDraft = () => {
            if (!activeConvo?.aiDraftReply) return;
            const draft = activeConvo.aiDraftReply;
            const newMsg = {
              id: `msg-${Date.now()}`,
              sender: 'bot',
              text: draft,
              timestamp: new Date().toLocaleTimeString('ar-AE', { hour: '2-digit', minute: '2-digit' }),
              platform: activeConvo.platform
            };
            setConversations(conversations.map(c => {
              if (c.id === activeConvo.id) {
                return {
                  ...c,
                  messages: [...c.messages, newMsg],
                  lastMessage: draft,
                  lastMessageTime: newMsg.timestamp,
                  aiDraftReply: undefined,
                  unreadCount: 0
                };
              }
              return c;
            }));
            showNotification(`تم اعتماد وإرسال رد الذكاء الاصطناعي بنجاح عبر مسار n8n!`);
          };

          const handleToggleBot = (convoId: string) => {
            setConversations(conversations.map(c => {
              if (c.id === convoId) {
                const nextState = !c.n8nBotActive;
                showNotification(nextState 
                  ? 'تمت إعادة تفعيل بوت n8n للردود الآلية' 
                  : 'تم تفعيل وضع الاستلام البشري اليدوي (تم إيقاف بوت n8n مؤقتاً)');
                return {
                  ...c,
                  n8nBotActive: nextState,
                  needsHumanTakeover: !nextState
                };
              }
              return c;
            }));
          };

          const handleSendApprovedTemplate = async (templateName: string) => {
            if (!activeConvo) return;
            try {
              const res = await fetch('/api/whatsapp/send-template', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  templateName,
                  customerPhone: activeConvo.customerPhoneOrId,
                  customerName: activeConvo.customerName
                })
              });
              const data = await res.json();
              if (data?.success && data.sentMessage) {
                setConversations(conversations.map(c => {
                  if (c.id === activeConvo.id) {
                    return {
                      ...c,
                      messages: [...c.messages, data.sentMessage],
                      lastMessage: data.sentMessage.text,
                      lastMessageTime: data.sentMessage.timestamp,
                      unreadCount: 0
                    };
                  }
                  return c;
                }));
                showNotification(`✓ تم إرسال القالب المعتمد (${templateName}) وفق مواصفة Meta v23.0 بنجاح!`);
              }
            } catch (err: any) {
              showNotification(`فشل إرسال القالب: ${err.message}`);
            }
          };

          return (
            <div className="space-y-5">
              {/* Header Title with Multi-Channel Status */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <span className="text-emerald-400">💬</span>
                    <span>المحادثات والوارد الموحد (WhatsApp & Facebook Messenger)</span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    أتمتة المحادثات الذكية عبر مسارات n8n مع الرد الفوري من كوتش براين وبوابة الاستلام البشري المباشر.
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button 
                    onClick={() => setShowN8nModal(true)}
                    className="text-xs bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-3 py-1 rounded-full font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>n8n Engine: متصل ونشط (فحص واختبار)</span>
                  </button>
                  <button 
                    onClick={() => setShowSettingsModal(true)}
                    className="text-xs bg-cyan-950/80 hover:bg-cyan-900/90 text-cyan-300 border border-cyan-600/50 px-3 py-1 rounded-full font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                  >
                    <Sliders className="w-3 h-3 text-cyan-400" />
                    <span>إعدادات Webhooks (n8n)</span>
                  </button>
                  <span className="text-xs bg-blue-500/10 text-blue-300 border border-blue-500/30 px-3 py-1 rounded-full font-semibold">
                    Meta Platform: متصل
                  </span>
                </div>
              </div>

              {/* Channels Filter Tabs */}
              <div className="flex flex-wrap items-center gap-1.5 border-b border-cyan-950 pb-2 text-xs">
                <button 
                  onClick={() => setConvoFilter('all')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                    convoFilter === 'all'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  الكل ({conversations.length})
                </button>

                <button 
                  onClick={() => setConvoFilter('whatsapp')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                    convoFilter === 'whatsapp'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-emerald-400">💬</span>
                  <span>WhatsApp ({conversations.filter(c => c.platform === 'whatsapp').length})</span>
                </button>

                <button 
                  onClick={() => setConvoFilter('messenger')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                    convoFilter === 'messenger'
                      ? 'bg-blue-500/20 text-blue-300 border border-blue-400'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-blue-400">⚡</span>
                  <span>Messenger ({conversations.filter(c => c.platform === 'messenger').length})</span>
                </button>

                <button 
                  onClick={() => setConvoFilter('takeover')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                    convoFilter === 'takeover'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-400'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-rose-400">⚠️</span>
                  <span>يحتاج استلام بشري ({conversations.filter(c => c.needsHumanTakeover).length})</span>
                </button>

                <button 
                  onClick={() => setConvoFilter('bot')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                    convoFilter === 'bot'
                      ? 'bg-purple-500/20 text-purple-300 border border-purple-400'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span>⚡ أتمتة n8n نشطة</span>
                </button>
              </div>

              {/* Chat View Layout */}
              <div className="bg-[#091522] border border-cyan-900/60 rounded-2xl h-[560px] flex flex-col md:flex-row overflow-hidden shadow-2xl">
                
                {/* Conversation List Sidebar */}
                <div className="w-full md:w-80 border-b md:border-b-0 md:border-l border-cyan-950 flex flex-col bg-[#061019]">
                  <div className="p-3 border-b border-cyan-950">
                    <input 
                      type="text" 
                      placeholder="بحث في محادثات أولياء الأمور والعملاء..." 
                      className="w-full bg-[#091522] border border-cyan-900/60 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div className="flex-1 overflow-y-auto divide-y divide-cyan-950/60">
                    {filteredConvos.map(convo => {
                      const isSelected = convo.id === activeConvo?.id;
                      return (
                        <div 
                          key={convo.id}
                          onClick={() => setSelectedConvoId(convo.id)}
                          className={`p-3.5 cursor-pointer transition-all ${
                            isSelected 
                              ? 'bg-cyan-950/50 border-r-4 border-cyan-400' 
                              : 'hover:bg-[#0a1827]'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-bold text-white flex items-center gap-1.5 truncate">
                              {convo.platform === 'whatsapp' ? (
                                <span className="text-emerald-400 text-[10px]">💬</span>
                              ) : (
                                <span className="text-blue-400 text-[10px]">⚡</span>
                              )}
                              <span>{convo.customerName}</span>
                            </span>
                            <span className="text-[10px] text-slate-400 shrink-0">{convo.lastMessageTime}</span>
                          </div>
                          
                          <p className="text-xs text-slate-300 truncate">{convo.lastMessage}</p>
                          
                          <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                            <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                              convo.platform === 'whatsapp' 
                                ? 'bg-emerald-500/20 text-emerald-300' 
                                : 'bg-blue-500/20 text-blue-300'
                            }`}>
                              {convo.platform === 'whatsapp' ? 'WhatsApp' : 'Messenger'}
                            </span>

                            <span className="text-[9px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">
                              {convo.branch}
                            </span>

                            {convo.needsHumanTakeover ? (
                              <span className="text-[9px] bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded font-bold">
                                يحتاج استلام
                              </span>
                            ) : (
                              <span className="text-[9px] bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded">
                                بوت n8n نشط
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Chat Details & Messages Thread */}
                {activeConvo ? (
                  <div className="flex-1 flex flex-col bg-[#08131e]">
                    
                    {/* Active Chat Header */}
                    <div className="p-3.5 border-b border-cyan-950 flex flex-wrap items-center justify-between gap-2 bg-[#061019]">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs ${
                          activeConvo.platform === 'whatsapp'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                            : 'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                        }`}>
                          {activeConvo.platform === 'whatsapp' ? 'WA' : 'FB'}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-xs font-bold text-white">{activeConvo.customerName}</h4>
                            <span className={`text-[10px] px-2 py-0.2 rounded font-bold ${
                              activeConvo.platform === 'whatsapp' 
                                ? 'bg-emerald-500/20 text-emerald-300' 
                                : 'bg-blue-500/20 text-blue-300'
                            }`}>
                              {activeConvo.platform === 'whatsapp' ? 'WhatsApp' : 'Messenger'}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400">
                            {activeConvo.customerPhoneOrId} • {activeConvo.branch} • {activeConvo.program}
                          </p>
                        </div>
                      </div>

                      {/* Bot Control Toggle Button */}
                      <button 
                        onClick={() => handleToggleBot(activeConvo.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                          activeConvo.n8nBotActive 
                            ? 'bg-amber-500/10 text-amber-300 border-amber-500/40 hover:bg-amber-500/20' 
                            : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/20'
                        }`}
                      >
                        {activeConvo.n8nBotActive ? (
                          <>
                            <span>⏸️</span>
                            <span>إيقاف بوت n8n (استلام يدوي)</span>
                          </>
                        ) : (
                          <>
                            <span>▶️</span>
                            <span>إعادة تفعيل بوت n8n الآلي</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Messages Body */}
                    <div className="flex-1 p-4 overflow-y-auto space-y-3">
                      {activeConvo.messages.map((msg: any) => {
                        const isUser = msg.sender === 'user';
                        return (
                          <div 
                            key={msg.id} 
                            className={`flex items-start gap-2 max-w-lg ${isUser ? '' : 'mr-auto flex-row-reverse'}`}
                          >
                            <div className={`p-3 rounded-2xl text-xs leading-relaxed ${
                              isUser 
                                ? 'bg-[#0c1b2a] border border-cyan-900/60 rounded-tr-none text-slate-100' 
                                : msg.sender === 'bot'
                                  ? 'bg-[#102438] border border-purple-800/60 rounded-tl-none text-purple-100'
                                  : 'bg-emerald-950/60 border border-emerald-800/60 rounded-tl-none text-emerald-100'
                            }`}>
                              <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1 gap-4">
                                <span className="font-bold">
                                  {isUser 
                                    ? activeConvo.customerName 
                                    : msg.sender === 'bot' ? '🤖 بوت n8n (كوتش براين)' : '👤 المالك (رد بشري مباشر)'}
                                </span>
                                <span>{msg.timestamp}</span>
                              </div>
                              <p>{msg.text}</p>
                            </div>
                          </div>
                        );
                      })}

                      {/* AI Suggested Reply Box (Draft from Coach Brain & n8n) */}
                      {activeConvo.aiDraftReply && (
                        <div className="bg-[#051824] border border-cyan-500/50 rounded-2xl p-4 my-3 space-y-2 shadow-lg">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                              <Sparkles className="w-3.5 h-3.5" />
                              مسودة مقترحة من كوتش براين عبر مسار n8n (بانتظار اعتماد المالك)
                            </span>
                            <span className="text-[10px] bg-cyan-500/20 text-cyan-200 px-2 py-0.5 rounded font-mono">
                              لم تُرسل بعد
                            </span>
                          </div>
                          
                          <p className="text-xs text-slate-200 bg-[#07131e] p-3 rounded-xl border border-cyan-900/80 leading-relaxed">
                            {activeConvo.aiDraftReply}
                          </p>

                          <div className="flex items-center justify-end gap-2 pt-1">
                            <button 
                              onClick={() => {
                                setCustomReplyText(activeConvo.aiDraftReply);
                                showNotification('تم نسخ المسودة إلى حقل الكتابة للتعديل');
                              }}
                              className="px-3 py-1.5 bg-[#091522] hover:bg-[#0e1d2c] text-slate-300 text-xs rounded-xl border border-slate-700"
                            >
                              تعديل المسودة
                            </button>
                            <button 
                              onClick={handleApproveAiDraft}
                              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-1.5"
                            >
                              <Send className="w-3.5 h-3.5" />
                              <span>اعتماد وإرسال فوراً عبر n8n</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Meta v23.0 Approved WhatsApp Templates Toolbar */}
                    {activeConvo.platform === 'whatsapp' && (
                      <div className="px-3 py-2 bg-[#050f18] border-t border-cyan-950/80 flex items-center justify-between gap-2 overflow-x-auto text-[11px]">
                        <span className="text-slate-400 font-bold flex items-center gap-1 shrink-0 text-[10px]">
                          <span>⚡</span>
                          <span>قوالب Meta v23.0 المعتمدة:</span>
                        </span>
                        <div className="flex items-center gap-1.5 shrink-0 overflow-x-auto">
                          <button
                            type="button"
                            onClick={() => handleSendApprovedTemplate('hello_world')}
                            className="px-2.5 py-1 bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-800/60 rounded-lg text-[10px] font-mono transition-all cursor-pointer"
                            title="قالب الترحيب hello_world"
                          >
                            + hello_world (ترحيب)
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSendApprovedTemplate('confirmation_v1')}
                            className="px-2.5 py-1 bg-cyan-950/60 hover:bg-cyan-900/60 text-cyan-300 border border-cyan-800/60 rounded-lg text-[10px] font-mono transition-all cursor-pointer"
                            title="تأكيد حجز الجلسة confirmation_v1"
                          >
                            + confirmation_v1 (تأكيد حجز)
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSendApprovedTemplate('media_carousel_v1')}
                            className="px-2.5 py-1 bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 border border-purple-800/60 rounded-lg text-[10px] font-mono transition-all cursor-pointer"
                            title="كاروسيل الفروع media_carousel_v1"
                          >
                            + media_carousel_v1 (كاروسيل)
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSendApprovedTemplate('market_image_cta_v1')}
                            className="px-2.5 py-1 bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 border border-amber-800/60 rounded-lg text-[10px] font-mono transition-all cursor-pointer"
                            title="عرض الباقة وزر الحجز market_image_cta_v1"
                          >
                            + market_image_cta_v1 (عرض وبوستر)
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Chat Input Bar */}
                    <div className="p-3 border-t border-cyan-950 bg-[#061019] flex items-center gap-2">
                      <input 
                        type="text" 
                        value={customReplyText}
                        onChange={(e) => setCustomReplyText(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSendReply();
                        }}
                        placeholder={`اكتب رداً مباشراً إلى ${activeConvo.customerName} عبر ${activeConvo.platform === 'whatsapp' ? 'WhatsApp' : 'Messenger'}...`} 
                        className="flex-1 bg-[#091522] border border-cyan-900/60 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                      />
                      <button 
                        onClick={handleSendReply}
                        className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold rounded-xl flex items-center gap-1.5"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>إرسال</span>
                      </button>
                    </div>

                  </div>
                ) : (
                  <div className="flex-1 flex items-center justify-center text-xs text-slate-400">
                    اختر محادثة لعرض التفاصيل
                  </div>
                )}

              </div>
            </div>
          );
        })()}

      </main>

      {/* ======================================================== */}
      {/* THEME PALETTE MODAL (Saved in localStorage)              */}
      {/* ======================================================== */}
      {showColorModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#091522] border border-cyan-800 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-cyan-950 pb-3">
              <div className="flex items-center gap-2">
                <Palette className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-bold text-white">تخصيص ألوان التمييز (Accent Theme)</h3>
              </div>
              <button 
                onClick={() => setShowColorModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              اختر لون التمييز المفضل لك لتطبيقه على شريط التبويبات والأزرار والبطاقات. يتم حفظ اختيارك تلقائياً في التخزين المحلي (localStorage).
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button 
                onClick={() => handleAccentChange('cyan')}
                className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                  accentColor === 'cyan'
                    ? 'border-cyan-400 bg-cyan-500/20 text-white font-bold'
                    : 'border-slate-800 bg-[#061019] text-slate-300 hover:border-cyan-800'
                }`}
              >
                <span className="w-4 h-4 rounded-full bg-cyan-400 shrink-0"></span>
                <span className="text-xs">سيان بحري (افتراضي)</span>
              </button>

              <button 
                onClick={() => handleAccentChange('emerald')}
                className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                  accentColor === 'emerald'
                    ? 'border-emerald-400 bg-emerald-500/20 text-white font-bold'
                    : 'border-slate-800 bg-[#061019] text-slate-300 hover:border-emerald-800'
                }`}
              >
                <span className="w-4 h-4 rounded-full bg-emerald-400 shrink-0"></span>
                <span className="text-xs">زمردي نشط</span>
              </button>

              <button 
                onClick={() => handleAccentChange('blue')}
                className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                  accentColor === 'blue'
                    ? 'border-blue-400 bg-blue-500/20 text-white font-bold'
                    : 'border-slate-800 bg-[#061019] text-slate-300 hover:border-blue-800'
                }`}
              >
                <span className="w-4 h-4 rounded-full bg-blue-500 shrink-0"></span>
                <span className="text-xs">أزرق داكن كلاسيكي</span>
              </button>

              <button 
                onClick={() => handleAccentChange('purple')}
                className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                  accentColor === 'purple'
                    ? 'border-purple-400 bg-purple-500/20 text-white font-bold'
                    : 'border-slate-800 bg-[#061019] text-slate-300 hover:border-purple-800'
                }`}
              >
                <span className="w-4 h-4 rounded-full bg-purple-500 shrink-0"></span>
                <span className="text-xs">أرجواني ملكي</span>
              </button>
            </div>

            <div className="pt-3 border-t border-cyan-950 flex justify-end">
              <button 
                onClick={() => setShowColorModal(false)}
                className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold rounded-xl"
              >
                إغلاق وتطبيق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* N8N CONNECTION & LIVE WEBHOOK TEST MODAL                 */}
      {/* ======================================================== */}
      <N8nConnectionModal
        isOpen={showN8nModal}
        onClose={() => setShowN8nModal(false)}
        onSimulateMessage={(simulatedConvo) => {
          // Add or update simulated convo in conversations list
          setConversations(prev => {
            const existingIdx = prev.findIndex(c => c.id === simulatedConvo.id || c.customerPhoneOrId === simulatedConvo.customerPhoneOrId);
            if (existingIdx >= 0) {
              const updated = [...prev];
              updated[existingIdx] = simulatedConvo;
              return updated;
            }
            return [simulatedConvo, ...prev];
          });
          setSelectedConvoId(simulatedConvo.id);
          setActiveTab('whatsapp');
          showNotification('تم استلام الرسالة التجريبية وإدراجها في قائمة المحادثات بنجاح!');
        }}
      />

      {/* Settings Modal (Webhooks, n8n, Appearance, Notifications) */}
      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        defaultTab="webhooks"
      />

      {/* Official Publishing Receipt Modal (Meta Graph API & Safe Publisher) */}
      <PublishingReceiptModal
        isOpen={isReceiptModalOpen}
        onClose={() => setIsReceiptModalOpen(false)}
        receipt={activeReceipt}
      />

    </div>
  );
};
