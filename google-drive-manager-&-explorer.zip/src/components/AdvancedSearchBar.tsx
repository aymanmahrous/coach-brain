import React, { useState, useRef, useEffect } from 'react';
import { 
  Search, 
  SlidersHorizontal, 
  Calendar, 
  Star, 
  Bell, 
  Sparkles, 
  X, 
  RotateCcw, 
  FileText, 
  Table, 
  Presentation, 
  Image as ImageIcon, 
  Folder, 
  Check, 
  Clock,
  Receipt,
  BarChart3,
  Rocket,
  FileCheck2,
  GraduationCap,
  Palette,
  FolderGit2,
  FileDown
} from 'lucide-react';
import { 
  AdvancedSearchFilters, 
  SearchDateFilter, 
  SearchTypeFilter, 
  AICategoryKey 
} from '../types';
import { AI_CATEGORIES } from '../services/aiCategorizeService';

interface AdvancedSearchBarProps {
  filters: AdvancedSearchFilters;
  onFiltersChange: (newFilters: AdvancedSearchFilters) => void;
  onResetFilters: () => void;
  totalMatchingCount?: number;
}

const TYPE_OPTIONS: { key: SearchTypeFilter; label: string; icon: React.ReactNode; color: string }[] = [
  { key: 'all', label: 'كافة الأنواع', icon: <FolderGit2 className="w-4 h-4" />, color: 'text-slate-600' },
  { key: 'docs', label: 'مستندات Docs', icon: <FileText className="w-4 h-4" />, color: 'text-blue-600' },
  { key: 'sheets', label: 'جداول Sheets', icon: <Table className="w-4 h-4" />, color: 'text-emerald-600' },
  { key: 'slides', label: 'عروض Slides', icon: <Presentation className="w-4 h-4" />, color: 'text-amber-600' },
  { key: 'pdf', label: 'ملفات PDF', icon: <FileDown className="w-4 h-4" />, color: 'text-rose-600' },
  { key: 'images', label: 'صور ووسائط', icon: <ImageIcon className="w-4 h-4" />, color: 'text-purple-600' },
  { key: 'folders', label: 'مجلدات فقط', icon: <Folder className="w-4 h-4" />, color: 'text-indigo-600' },
];

const DATE_OPTIONS: { key: SearchDateFilter; label: string; desc: string }[] = [
  { key: 'all', label: 'أي وقت', desc: 'كافة التواريخ' },
  { key: 'today', label: 'اليوم', desc: 'آخر 24 ساعة' },
  { key: 'week', label: 'هذا الأسبوع', desc: 'آخر 7 أيام' },
  { key: 'month', label: 'هذا الشهر', desc: 'آخر 30 يوماً' },
  { key: 'year', label: 'هذا العام', desc: 'آخر 365 يوماً' },
];

const QUICK_SEARCH_PRESETS = [
  { label: '📄 مستندات هذا الأسبوع', apply: { type: 'docs' as SearchTypeFilter, dateModified: 'week' as SearchDateFilter } },
  { label: '📊 جداول الميزانية', apply: { type: 'sheets' as SearchTypeFilter, query: 'ميزانية' } },
  { label: '📑 ملفات PDF الشهرية', apply: { type: 'pdf' as SearchTypeFilter, dateModified: 'month' as SearchDateFilter } },
  { label: '⭐ المميزة بنجمة', apply: { onlyStarred: true } },
  { label: '🔔 تذكيرات هامة', apply: { onlyReminders: true } },
  { label: '🧾 عقود وفواتير (AI)', apply: { aiCategory: 'contracts' as AICategoryKey } },
];

export const AdvancedSearchBar: React.FC<AdvancedSearchBarProps> = ({
  filters,
  onFiltersChange,
  onResetFilters,
  totalMatchingCount,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Keyboard shortcuts (Escape to close)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
      if (e.key === '/' && document.activeElement !== inputRef.current && (e.target as HTMLElement).tagName !== 'INPUT' && (e.target as HTMLElement).tagName !== 'TEXTAREA') {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Calculate active filter count (excluding query)
  const activeFiltersCount = [
    filters.type !== 'all',
    filters.dateModified !== 'all',
    filters.onlyStarred,
    filters.onlyReminders,
    filters.aiCategory !== 'all',
  ].filter(Boolean).length;

  const hasActiveFiltersOrQuery = activeFiltersCount > 0 || Boolean(filters.query.trim());

  const handleQueryChange = (val: string) => {
    onFiltersChange({ ...filters, query: val });
  };

  const handleTypeSelect = (type: SearchTypeFilter) => {
    onFiltersChange({ ...filters, type });
  };

  const handleDateSelect = (dateModified: SearchDateFilter) => {
    onFiltersChange({ ...filters, dateModified });
  };

  const handleToggleStarred = () => {
    onFiltersChange({ ...filters, onlyStarred: !filters.onlyStarred });
  };

  const handleToggleReminders = () => {
    onFiltersChange({ ...filters, onlyReminders: !filters.onlyReminders });
  };

  const handleAICategorySelect = (aiCategory: AICategoryKey | 'all') => {
    onFiltersChange({ ...filters, aiCategory });
  };

  const handleApplyPreset = (preset: Partial<AdvancedSearchFilters>) => {
    onFiltersChange({
      ...filters,
      ...preset,
    });
  };

  const renderAIIcon = (key: AICategoryKey) => {
    switch (key) {
      case 'invoices': return <Receipt className="w-3.5 h-3.5" />;
      case 'reports': return <BarChart3 className="w-3.5 h-3.5" />;
      case 'projects': return <Rocket className="w-3.5 h-3.5" />;
      case 'contracts': return <FileCheck2 className="w-3.5 h-3.5" />;
      case 'education': return <GraduationCap className="w-3.5 h-3.5" />;
      case 'media': return <Palette className="w-3.5 h-3.5" />;
      default: return <Sparkles className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div className="relative w-full" ref={containerRef}>
      {/* Search Input Box */}
      <div 
        className={`relative flex items-center bg-slate-100/90 hover:bg-slate-100 border transition-all rounded-2xl ${
          isOpen ? 'bg-white border-blue-500 ring-4 ring-blue-500/10 shadow-lg' : 'border-slate-200/80'
        }`}
      >
        {/* Search Icon */}
        <div className="pr-3.5 pl-2 text-slate-400 flex items-center pointer-events-none">
          <Search className={`w-4 h-4 transition-colors ${isOpen ? 'text-blue-600' : 'text-slate-400'}`} />
        </div>

        {/* Input */}
        <input
          ref={inputRef}
          type="text"
          id="drive-advanced-search-input"
          value={filters.query}
          onChange={(e) => handleQueryChange(e.target.value)}
          onFocus={() => setIsOpen(true)}
          placeholder="ابحث بالاسم أو المحتوى، أو اضغط لتصفية متقدمة..."
          className="w-full py-2.5 text-sm bg-transparent outline-none text-slate-800 placeholder-slate-400 font-medium"
        />

        {/* Clear query button */}
        {filters.query && (
          <button
            onClick={() => handleQueryChange('')}
            className="p-1 mx-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-full transition-colors cursor-pointer"
            title="مسح نص البحث"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}

        {/* Filter Toggle Button */}
        <button
          type="button"
          id="search-filter-toggle-btn"
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center gap-1.5 px-3 py-1.5 mx-1.5 text-xs font-bold rounded-xl transition-all border cursor-pointer select-none ${
            activeFiltersCount > 0
              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
              : isOpen
                ? 'bg-blue-50 text-blue-700 border-blue-200'
                : 'bg-white text-slate-600 hover:text-slate-900 border-slate-200/90 hover:bg-slate-50'
          }`}
          title="خيارات التصفية والبحث المتقدم"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">خيارات متقدمة</span>
          {activeFiltersCount > 0 && (
            <span className="min-w-4 h-4 px-1 rounded-full text-[10px] font-black bg-white text-blue-700 flex items-center justify-center font-mono">
              {activeFiltersCount}
            </span>
          )}
        </button>
      </div>

      {/* Advanced Filter Dropdown Menu */}
      {isOpen && (
        <div 
          id="advanced-search-popover"
          className="absolute top-full mt-2 right-0 left-0 sm:left-auto sm:w-[580px] bg-white rounded-3xl border border-slate-200 shadow-2xl z-50 p-4 sm:p-5 transition-all text-right max-h-[85vh] overflow-y-auto"
          dir="rtl"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-blue-50 text-blue-600 rounded-lg">
                <SlidersHorizontal className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">تصفية البحث المتقدم</h4>
                <p className="text-[11px] text-slate-500">خصص معايير البحث للوصول السريع لملفاتك</p>
              </div>
            </div>

            {hasActiveFiltersOrQuery && (
              <button
                onClick={onResetFilters}
                className="flex items-center gap-1 text-xs font-bold text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-2.5 py-1 rounded-xl transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>إعادة ضبط</span>
              </button>
            )}
          </div>

          {/* Quick Presets / Shortcuts */}
          <div className="mb-4">
            <span className="text-[11px] font-bold text-slate-400 block mb-2">اختصارات بحث ذكية ومقترحة:</span>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_SEARCH_PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleApplyPreset(preset.apply)}
                  className="px-2.5 py-1 text-xs rounded-xl bg-slate-50 hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-200/70 hover:border-blue-200 transition-all font-medium cursor-pointer"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Filter 1: File Type */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <FolderGit2 className="w-3.5 h-3.5 text-blue-600" />
                <span>نوع الملف والمستند</span>
              </span>
              {filters.type !== 'all' && (
                <button
                  onClick={() => handleTypeSelect('all')}
                  className="text-[11px] text-slate-400 hover:text-blue-600 transition-colors"
                >
                  إلغاء التحديد
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {TYPE_OPTIONS.map((opt) => {
                const isSelected = filters.type === opt.key;
                return (
                  <button
                    key={opt.key}
                    onClick={() => handleTypeSelect(opt.key)}
                    className={`flex items-center gap-2 p-2 rounded-xl text-xs font-bold border transition-all text-right cursor-pointer ${
                      isSelected
                        ? 'bg-blue-50 text-blue-800 border-blue-300 ring-2 ring-blue-500/20 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200/80 hover:bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    <span className={opt.color}>{opt.icon}</span>
                    <span className="truncate flex-1">{opt.label}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Filter 2: Date Modified */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                <span>تاريخ آخر تعديل</span>
              </span>
              {filters.dateModified !== 'all' && (
                <button
                  onClick={() => handleDateSelect('all')}
                  className="text-[11px] text-slate-400 hover:text-emerald-600 transition-colors"
                >
                  إلغاء التحديد
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
              {DATE_OPTIONS.map((opt) => {
                const isSelected = filters.dateModified === opt.key;
                return (
                  <button
                    key={opt.key}
                    onClick={() => handleDateSelect(opt.key)}
                    className={`flex flex-col items-start p-2 rounded-xl text-right border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200/80 hover:bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-xs font-bold">{opt.label}</span>
                      {isSelected && <Check className="w-3 h-3 text-emerald-600 shrink-0" />}
                    </div>
                    <span className="text-[10px] text-slate-400 mt-0.5">{opt.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Filter 3: Quick Flags (Starred & Reminders) */}
          <div className="mb-4">
            <span className="text-xs font-bold text-slate-800 block mb-2">خصائص إضافية</span>
            <div className="grid grid-cols-2 gap-2">
              {/* Starred Flag */}
              <button
                onClick={handleToggleStarred}
                className={`flex items-center justify-between p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  filters.onlyStarred
                    ? 'bg-amber-50 text-amber-900 border-amber-300 ring-2 ring-amber-500/20'
                    : 'bg-white text-slate-700 border-slate-200/80 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Star className={`w-4 h-4 ${filters.onlyStarred ? 'text-amber-500 fill-amber-500' : 'text-slate-400'}`} />
                  <span>المميزة بنجمة فقط</span>
                </div>
                {filters.onlyStarred && <Check className="w-3.5 h-3.5 text-amber-600" />}
              </button>

              {/* Reminders Flag */}
              <button
                onClick={handleToggleReminders}
                className={`flex items-center justify-between p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  filters.onlyReminders
                    ? 'bg-orange-50 text-orange-900 border-orange-300 ring-2 ring-orange-500/20'
                    : 'bg-white text-slate-700 border-slate-200/80 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Bell className={`w-4 h-4 ${filters.onlyReminders ? 'text-orange-500' : 'text-slate-400'}`} />
                  <span>تحتوي على تذكير</span>
                </div>
                {filters.onlyReminders && <Check className="w-3.5 h-3.5 text-orange-600" />}
              </button>
            </div>
          </div>

          {/* Filter 4: AI Smart Category */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                <span>تصنيف الذكاء الاصطناعي (AI)</span>
              </span>
              {filters.aiCategory !== 'all' && (
                <button
                  onClick={() => handleAICategorySelect('all')}
                  className="text-[11px] text-slate-400 hover:text-purple-600 transition-colors"
                >
                  إلغاء التحديد
                </button>
              )}
            </div>

            <div className="flex flex-wrap gap-1.5">
              {(Object.keys(AI_CATEGORIES) as AICategoryKey[]).map((catKey) => {
                const cat = AI_CATEGORIES[catKey];
                const isSelected = filters.aiCategory === catKey;
                return (
                  <button
                    key={catKey}
                    onClick={() => handleAICategorySelect(isSelected ? 'all' : catKey)}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isSelected
                        ? `${cat.badgeBg} ${cat.badgeText} ${cat.badgeBorder} ring-2 ring-purple-500/20 shadow-xs`
                        : 'bg-slate-50 text-slate-700 border-slate-200/70 hover:bg-slate-100'
                    }`}
                  >
                    {renderAIIcon(catKey)}
                    <span>{cat.label}</span>
                    {isSelected && <Check className="w-3 h-3 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <div className="text-xs font-bold text-slate-500">
              {typeof totalMatchingCount === 'number' && (
                <span>
                  النتائج المطابقة: <strong className="text-blue-600 font-mono">{totalMatchingCount}</strong> ملف
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer"
              >
                تطبيق الفلاتر
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Active Filters Pill Row */}
      {activeFiltersCount > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 mt-2 px-1">
          <span className="text-[11px] font-bold text-slate-500">الفلاتر المطبقة:</span>

          {filters.type !== 'all' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-blue-50 text-blue-800 text-xs font-bold border border-blue-200">
              <span>النوع: {TYPE_OPTIONS.find(t => t.key === filters.type)?.label}</span>
              <button onClick={() => handleTypeSelect('all')} className="hover:text-blue-900 cursor-pointer">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.dateModified !== 'all' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200">
              <span>التاريخ: {DATE_OPTIONS.find(d => d.key === filters.dateModified)?.label}</span>
              <button onClick={() => handleDateSelect('all')} className="hover:text-emerald-900 cursor-pointer">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.onlyStarred && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200">
              <span>⭐ مميزة بنجمة</span>
              <button onClick={handleToggleStarred} className="hover:text-amber-900 cursor-pointer">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.onlyReminders && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-orange-50 text-orange-800 text-xs font-bold border border-orange-200">
              <span>🔔 لها تذكير</span>
              <button onClick={handleToggleReminders} className="hover:text-orange-900 cursor-pointer">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.aiCategory !== 'all' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-purple-50 text-purple-800 text-xs font-bold border border-purple-200">
              <span>AI: {AI_CATEGORIES[filters.aiCategory]?.label}</span>
              <button onClick={() => handleAICategorySelect('all')} className="hover:text-purple-900 cursor-pointer">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          <button
            onClick={onResetFilters}
            className="text-[11px] font-bold text-rose-600 hover:text-rose-700 hover:underline px-1 cursor-pointer"
          >
            مسح الكل
          </button>
        </div>
      )}
    </div>
  );
};
