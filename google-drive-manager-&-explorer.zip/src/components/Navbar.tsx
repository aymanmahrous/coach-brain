import React, { useState } from 'react';
import { 
  Sparkles, 
  HardDrive, 
  LogIn, 
  LogOut, 
  RefreshCw, 
  ShieldCheck, 
  LayoutGrid, 
  List,
  FolderPlus,
  Upload,
  FilePlus2,
  Key,
  Bell,
  Menu,
  PanelLeftClose,
  PanelLeftOpen,
  ScanText,
  Film,
  Palette
} from 'lucide-react';
import { DriveAbout, ViewMode, FileReminder, AdvancedSearchFilters, DEFAULT_SEARCH_FILTERS } from '../types';
import { ReminderDropdown } from './ReminderDropdown';
import { ReminderService } from '../services/reminderService';
import { AdvancedSearchBar } from './AdvancedSearchBar';
import { N8nConnectionModal } from './N8nConnectionModal';
import { SettingsModal } from './SettingsModal';
import { Radio, Sliders } from 'lucide-react';

interface NavbarProps {
  searchFilters?: AdvancedSearchFilters;
  onFiltersChange?: (filters: AdvancedSearchFilters) => void;
  onResetFilters?: () => void;
  totalMatchingCount?: number;
  searchQuery?: string;
  onSearchChange?: (q: string) => void;
  isConnected: boolean;
  aboutInfo: DriveAbout | null;
  onConnectGoogle: () => void;
  onDisconnect: () => void;
  onOpenAI: () => void;
  onOpenOCR?: () => void;
  onOpenVeo?: () => void;
  onRefresh: () => void;
  isLoading: boolean;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  onOpenUpload: () => void;
  onOpenNewFolder: () => void;
  onOpenNewDoc: () => void;
  onOpenOAuthModal: () => void;
  reminders?: FileReminder[];
  onOpenFileReminder?: (fileId: string) => void;
  onToggleCompleteReminder?: (reminderId: string) => void;
  onDeleteReminder?: (reminderId: string) => void;
  onNavigateToRemindersView?: () => void;
  isMobileSidebarOpen?: boolean;
  onToggleMobileSidebar?: () => void;
  isDesktopSidebarCollapsed?: boolean;
  onToggleDesktopSidebar?: () => void;
  onOpenThemeSettings?: () => void;
}

// Floating Tooltip Component for Navbar Operations
const NavTooltip: React.FC<{ label: string; shortcut?: string; children: React.ReactNode }> = ({ label, shortcut, children }) => (
  <div className="relative group/navtip inline-flex items-center">
    {children}
    <div className="pointer-events-none absolute top-full mt-2.5 left-1/2 -translate-x-1/2 hidden group-hover/navtip:flex items-center gap-1.5 px-2.5 py-1 bg-slate-900/95 backdrop-blur-sm text-white text-[11px] font-medium rounded-lg shadow-xl whitespace-nowrap z-50 border border-slate-700/80 transition-all">
      <span>{label}</span>
      {shortcut && (
        <kbd className="px-1 py-0.2 bg-slate-800 text-[9px] rounded font-mono border border-slate-700 text-slate-300">
          {shortcut}
        </kbd>
      )}
      <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-slate-900 border-t border-l border-slate-700/80 rotate-45" />
    </div>
  </div>
);

export const Navbar: React.FC<NavbarProps> = ({
  searchFilters = DEFAULT_SEARCH_FILTERS,
  onFiltersChange,
  onResetFilters,
  totalMatchingCount,
  searchQuery,
  onSearchChange,
  isConnected,
  aboutInfo,
  onConnectGoogle,
  onDisconnect,
  onOpenAI,
  onOpenOCR,
  onOpenVeo,
  onRefresh,
  isLoading,
  viewMode,
  onViewModeChange,
  onOpenUpload,
  onOpenNewFolder,
  onOpenNewDoc,
  onOpenOAuthModal,
  reminders = [],
  onOpenFileReminder,
  onToggleCompleteReminder,
  onDeleteReminder,
  onNavigateToRemindersView,
  isMobileSidebarOpen = false,
  onToggleMobileSidebar,
  isDesktopSidebarCollapsed = false,
  onToggleDesktopSidebar,
  onOpenThemeSettings,
}) => {
  const [isReminderDropdownOpen, setIsReminderDropdownOpen] = useState(false);
  const [isN8nModalOpen, setIsN8nModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // Fallback handler if only simple query was passed
  const handleFiltersChange = (newFilters: AdvancedSearchFilters) => {
    if (onFiltersChange) {
      onFiltersChange(newFilters);
    } else if (onSearchChange) {
      onSearchChange(newFilters.query);
    }
  };

  const handleReset = () => {
    if (onResetFilters) {
      onResetFilters();
    } else if (onSearchChange) {
      onSearchChange('');
    }
  };

  const activeFilters = searchFilters || {
    ...DEFAULT_SEARCH_FILTERS,
    query: searchQuery || '',
  };

  const activeRemindersCount = reminders.filter(r => !r.completed).length;
  const dueRemindersCount = reminders.filter(r => !r.completed && ReminderService.isDue(r)).length;
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 lg:px-6 py-3 transition-all">
      <div className="flex items-center justify-between gap-3 max-w-7xl mx-auto">
        
        {/* Brand & Logo + Mobile Sidebar Toggle */}
        <div className="flex items-center gap-2.5 min-w-fit">
          {/* Mobile Sidebar Hamburger Toggle (Visible only on small screens < lg) */}
          {onToggleMobileSidebar && (
            <NavTooltip label="فتح قائمة التنقل والأقسام">
              <button
                onClick={onToggleMobileSidebar}
                className={`p-2 rounded-xl transition-all border lg:hidden cursor-pointer ${
                  isMobileSidebarOpen
                    ? 'bg-blue-50 text-blue-700 border-blue-200'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 border-slate-200/60'
                }`}
                aria-label="قائمة التنقل"
              >
                <Menu className="w-5 h-5" />
              </button>
            </NavTooltip>
          )}

          {/* Desktop Sidebar Collapse Toggle (Visible on lg+) */}
          {onToggleDesktopSidebar && (
            <NavTooltip label={isDesktopSidebarCollapsed ? 'توسيع القائمة الجانبية' : 'طي القائمة الجانبية لتوسيع العرض'}>
              <button
                onClick={onToggleDesktopSidebar}
                className="hidden lg:flex p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors border border-slate-200/60 cursor-pointer"
              >
                {isDesktopSidebarCollapsed ? (
                  <PanelLeftOpen className="w-4 h-4" />
                ) : (
                  <PanelLeftClose className="w-4 h-4" />
                )}
              </button>
            </NavTooltip>
          )}

          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-500 flex items-center justify-center shadow-md shadow-blue-500/20 text-white shrink-0">
            <HardDrive className="w-5 h-5" />
          </div>
          <div className="hidden sm:block">
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-slate-900 tracking-tight">مستكشف Google Drive</h1>
              <span className="text-[10px] font-semibold tracking-wide uppercase px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200/60">
                {isConnected ? 'متصل ومفعّل' : 'وضع المعاينة'}
              </span>
            </div>
            <p className="text-xs text-slate-500">إدارة المستندات وتحليلها بالذكاء الاصطناعي</p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-xl mx-2">
          <AdvancedSearchBar
            filters={activeFilters}
            onFiltersChange={handleFiltersChange}
            onResetFilters={handleReset}
            totalMatchingCount={totalMatchingCount}
          />
        </div>

        {/* Action Controls & User Account */}
        <div className="flex items-center gap-2">
          {/* Reminders & Notification Bell */}
          <div className="relative">
            <NavTooltip label={activeRemindersCount > 0 ? `التنبيهات المجدولة (${activeRemindersCount})` : 'التنبيهات والتذكيرات'}>
              <button
                id="navbar-reminders-bell"
                onClick={() => setIsReminderDropdownOpen(!isReminderDropdownOpen)}
                className={`relative p-2 rounded-xl transition-all border cursor-pointer ${
                  dueRemindersCount > 0
                    ? 'bg-rose-50 text-rose-600 border-rose-200 hover:bg-rose-100 shadow-xs animate-pulse'
                    : activeRemindersCount > 0
                      ? 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 border-slate-200/60'
                }`}
              >
                <Bell className="w-4 h-4" />
                {activeRemindersCount > 0 && (
                  <span className={`absolute -top-1 -right-1 min-w-4 h-4 px-1 rounded-full text-[10px] font-black font-mono flex items-center justify-center text-white ${
                    dueRemindersCount > 0 ? 'bg-rose-600' : 'bg-amber-600'
                  }`}>
                    {activeRemindersCount}
                  </span>
                )}
              </button>
            </NavTooltip>

            <ReminderDropdown
              isOpen={isReminderDropdownOpen}
              onClose={() => setIsReminderDropdownOpen(false)}
              reminders={reminders}
              onOpenFile={(fileId) => {
                if (onOpenFileReminder) onOpenFileReminder(fileId);
              }}
              onToggleComplete={(remId) => {
                if (onToggleCompleteReminder) onToggleCompleteReminder(remId);
              }}
              onDeleteReminder={(remId) => {
                if (onDeleteReminder) onDeleteReminder(remId);
              }}
              onNavigateToRemindersView={() => {
                if (onNavigateToRemindersView) onNavigateToRemindersView();
              }}
            />
          </div>

          {/* Quick OCR Scanner Button */}
          {onOpenOCR && (
            <NavTooltip label="مسح ضوئي واستخراج النصوص (OCR) من المستندات">
              <button
                onClick={onOpenOCR}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100 border border-violet-200/80 rounded-xl transition-all shadow-xs hover:shadow cursor-pointer"
              >
                <ScanText className="w-4 h-4 text-violet-600" />
                <span className="hidden xl:inline">مسح ضوئي OCR</span>
              </button>
            </NavTooltip>
          )}

          {/* Quick Veo Video Generation Button */}
          {onOpenVeo && (
            <NavTooltip label="توليد وتحريك فيديو سينمائي عبر Google Veo">
              <button
                id="veo-video-btn"
                onClick={onOpenVeo}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-rose-700 bg-gradient-to-r from-amber-50 to-rose-50 hover:from-amber-100 hover:to-rose-100 border border-rose-200/80 rounded-xl transition-all shadow-xs hover:shadow cursor-pointer"
              >
                <Film className="w-4 h-4 text-rose-600 animate-pulse" />
                <span className="hidden lg:inline">تحريك صورة (Veo Video)</span>
              </button>
            </NavTooltip>
          )}

          {/* Quick AI Assistant Button */}
          <NavTooltip label="مساعد الذكاء الاصطناعي وتحليل الملفات">
            <button
              id="ai-assistant-btn"
              onClick={onOpenAI}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200/80 rounded-xl transition-all shadow-sm hover:shadow cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
              <span className="hidden md:inline">مساعد الذكاء الاصطناعي</span>
            </button>
          </NavTooltip>

          {/* View Toggle */}
          <div className="hidden sm:flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200/60">
            <NavTooltip label="عرض الشبكة (Grid View)">
              <button
                onClick={() => onViewModeChange('grid')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'grid' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </NavTooltip>
            <NavTooltip label="عرض القائمة (List View)">
              <button
                onClick={() => onViewModeChange('list')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'list' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <List className="w-4 h-4" />
              </button>
            </NavTooltip>
          </div>

          {/* Refresh */}
          <NavTooltip label="تحديث ومزامنة الملفات الآن">
            <button
              onClick={onRefresh}
              disabled={isLoading}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all border border-slate-200/60 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-blue-600' : ''}`} />
            </button>
          </NavTooltip>

          {/* Theme & Accent Color Settings */}
          {onOpenThemeSettings && (
            <NavTooltip label="تخصيص ألوان التمييز والمظهر">
              <button
                id="theme-settings-btn"
                onClick={onOpenThemeSettings}
                className="p-2 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all border border-slate-200/60 cursor-pointer group"
              >
                <Palette className="w-4 h-4 transition-transform group-hover:scale-110" />
              </button>
            </NavTooltip>
          )}

          {/* Settings Modal Trigger (Webhooks & System) */}
          <NavTooltip label="إعدادات Webhooks والنظام (Settings Center)">
            <button
              id="navbar-settings-modal-btn"
              onClick={() => setIsSettingsModalOpen(true)}
              className="p-2 text-slate-600 hover:text-cyan-600 hover:bg-cyan-50 rounded-xl transition-all border border-slate-200/60 cursor-pointer group"
            >
              <Sliders className="w-4 h-4 transition-transform group-hover:rotate-45" />
            </button>
          </NavTooltip>

          {/* n8n Engine & Webhook Status Indicator Button */}
          <NavTooltip label="حالة ربط n8n (واتساب وماسنجر) — انقر للاختبار">
            <button
              id="n8n-status-indicator-btn"
              onClick={() => setIsN8nModalOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100/90 border border-emerald-200/90 rounded-xl transition-all shadow-xs hover:shadow cursor-pointer"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <Radio className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
              <span className="hidden xl:inline font-mono font-bold text-[11px]">n8n نشط</span>
            </button>
          </NavTooltip>

          {/* Connection / Profile Action */}
          {isConnected ? (
            <div className="flex items-center gap-2 pl-1 border-r border-slate-200 pr-2">
              <div className="hidden lg:flex flex-col text-left">
                <span className="text-xs font-bold text-slate-800 leading-tight">
                  {aboutInfo?.user?.displayName || 'حساب Google'}
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  {aboutInfo?.user?.emailAddress || 'متصل'}
                </span>
              </div>
              <NavTooltip label="تسجيل الخروج وفصل ربط Google Drive">
                <button
                  onClick={onDisconnect}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100/80 border border-red-200/60 rounded-xl transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">فصل الحساب</span>
                </button>
              </NavTooltip>
            </div>
          ) : (
            <div className="flex items-center gap-1.5">
              <NavTooltip label="تسجيل الدخول وربط Google Drive الرسمي">
                <button
                  id="connect-google-btn"
                  onClick={onConnectGoogle}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 shadow-sm hover:shadow shadow-blue-600/20 rounded-xl transition-all"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>ربط حساب Drive</span>
                </button>
              </NavTooltip>
              
              <NavTooltip label="إعدادات وصلاحيات وتفويض OAuth">
                <button
                  onClick={onOpenOAuthModal}
                  className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-colors border border-slate-200/60"
                >
                  <Key className="w-4 h-4" />
                </button>
              </NavTooltip>
            </div>
          )}

        </div>

      </div>

      {/* n8n Status & Connection Test Modal */}
      <N8nConnectionModal
        isOpen={isN8nModalOpen}
        onClose={() => setIsN8nModalOpen(false)}
      />

      {/* Unified Settings Modal (Webhooks, Appearance, Notifications, Meta) */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        defaultTab="webhooks"
      />
    </header>
  );
};
