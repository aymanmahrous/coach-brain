import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Sparkles, 
  Bot, 
  Send, 
  FileText, 
  Check, 
  Copy, 
  Save, 
  RefreshCw, 
  MessageSquare, 
  FilePlus, 
  BrainCircuit,
  ArrowRight,
  Lightbulb
} from 'lucide-react';
import { DriveFile, ChatMessage } from '../types';
import { DriveService } from '../services/driveService';

interface AIInsightModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedFile: DriveFile | null;
  allFiles: DriveFile[];
  token: string | null;
  onSaveNewDocToDrive: (title: string, content: string) => Promise<void>;
}

type AITab = 'summary' | 'chat' | 'draft';

export const AIInsightModal: React.FC<AIInsightModalProps> = ({
  isOpen,
  onClose,
  selectedFile,
  allFiles,
  token,
  onSaveNewDocToDrive,
}) => {
  const [activeTab, setActiveTab] = useState<AITab>(selectedFile ? 'summary' : 'chat');
  const [currentFile, setCurrentFile] = useState<DriveFile | null>(selectedFile);

  // Summary State
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [summaryResult, setSummaryResult] = useState<string>('');
  const [summaryError, setSummaryError] = useState<string | null>(null);

  // Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      role: 'assistant',
      text: 'مرحباً بك! أنا مساعد Google Drive الذكي المدعوم بـ Gemini. يمكنني الإجابة عن أي استفسار يخص ملفاتك، تلخيص محتوى المستندات، واستخراج الأفكار الرئيسية، أو صياغة ملفات جديدة مباشرة.',
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [chatLoading, setChatLoading] = useState(false);

  // Draft Generator State
  const [draftTopic, setDraftTopic] = useState('');
  const [draftType, setDraftType] = useState('تقرير عمل');
  const [draftDetails, setDraftDetails] = useState('');
  const [draftContent, setDraftContent] = useState('');
  const [draftLoading, setDraftLoading] = useState(false);
  const [isSavingDraft, setIsSavingDraft] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const [copied, setCopied] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (selectedFile) {
      setCurrentFile(selectedFile);
      setActiveTab('summary');
      generateSummary(selectedFile);
    }
  }, [selectedFile]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const generateSummary = async (fileToAnalyze: DriveFile) => {
    setSummaryLoading(true);
    setSummaryError(null);
    setSummaryResult('');

    try {
      const fileText = await DriveService.fetchFileTextContent(token, fileToAnalyze);
      
      const res = await fetch('/api/ai/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: fileToAnalyze.name,
          mimeType: fileToAnalyze.mimeType,
          content: fileText,
          language: 'ar',
        })
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'تعذر الحصول على تلخيص من المساعد.');
      }

      const data = await res.json();
      setSummaryResult(data.result);
    } catch (err: any) {
      setSummaryError(err.message || 'حدث خطأ أثناء الاتصال بالذكاء الاصطناعي.');
    } finally {
      setSummaryLoading(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || chatLoading) return;

    const userText = inputMessage.trim();
    setInputMessage('');

    const newMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      fileContextName: currentFile?.name,
    };

    setMessages((prev) => [...prev, newMsg]);
    setChatLoading(true);

    try {
      let fileContextSnippet = undefined;
      if (currentFile) {
        const text = await DriveService.fetchFileTextContent(token, currentFile);
        fileContextSnippet = {
          name: currentFile.name,
          mimeType: currentFile.mimeType,
          size: currentFile.size,
          content: text.slice(0, 10000),
        };
      }

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userText,
          fileContext: fileContextSnippet,
        })
      });

      if (!res.ok) {
        throw new Error('فشلت استجابة المساعد الذكي.');
      }

      const data = await res.json();
      const botMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'system',
        text: 'عذراً، حدث خطأ في الاتصال بالمساعد الذكي. يرجى إعادة المحاولة.',
        timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setChatLoading(false);
    }
  };

  const handleGenerateDraft = async () => {
    if (!draftTopic.trim() || draftLoading) return;
    setDraftLoading(true);
    setSaveSuccess(false);

    try {
      const res = await fetch('/api/ai/generate-doc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: draftTopic,
          docType: draftType,
          details: draftDetails,
        })
      });

      if (!res.ok) {
        throw new Error('فشل إنشاء مسودة المستند.');
      }

      const data = await res.json();
      setDraftContent(data.content);
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء توليد المستند.');
    } finally {
      setDraftLoading(false);
    }
  };

  const handleSaveDraftToDrive = async () => {
    if (!draftContent || isSavingDraft) return;
    setIsSavingDraft(true);
    try {
      const title = draftTopic.trim() ? `${draftTopic}` : 'مستند ذكي جديد';
      await onSaveNewDocToDrive(title, draftContent);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (e: any) {
      alert(e.message || 'فشل حفظ المستند في Google Drive.');
    } finally {
      setIsSavingDraft(false);
    }
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-gradient-to-r from-indigo-50/70 via-white to-blue-50/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span>مساعد Google Drive الذكي</span>
                <span className="text-[10px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-bold">
                  Gemini Flash
                </span>
              </h2>
              <p className="text-xs text-slate-500">تحليل وتلخيص المستندات وتوليد المحتوى</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-200 bg-white">
          <button
            onClick={() => setActiveTab('summary')}
            className={`flex items-center gap-1.5 pb-3 px-3 text-xs font-bold transition-all border-b-2 ${
              activeTab === 'summary'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BrainCircuit className="w-4 h-4" />
            <span>تلخيص المستند</span>
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-1.5 pb-3 px-3 text-xs font-bold transition-all border-b-2 ${
              activeTab === 'chat'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>محادثة مع ملفاتك</span>
          </button>

          <button
            onClick={() => setActiveTab('draft')}
            className={`flex items-center gap-1.5 pb-3 px-3 text-xs font-bold transition-all border-b-2 ${
              activeTab === 'draft'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FilePlus className="w-4 h-4" />
            <span>توليد مستند وحفظه بـ Drive</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50">
          
          {/* TAB 1: SUMMARY & INSIGHTS */}
          {activeTab === 'summary' && (
            <div className="flex flex-col gap-4">
              {/* File Selector */}
              <div className="flex items-center justify-between gap-3 p-3 bg-white rounded-2xl border border-slate-200">
                <div className="flex items-center gap-2.5 min-w-0">
                  <FileText className="w-5 h-5 text-indigo-600 shrink-0" />
                  <div className="min-w-0">
                    <span className="text-xs text-slate-400 block font-medium">الملف المحدد للتحليل:</span>
                    <span className="text-sm font-bold text-slate-800 truncate block">
                      {currentFile?.name || 'لم يتم اختيار ملف محدد'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <select
                    className="text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 outline-none text-slate-700"
                    value={currentFile?.id || ''}
                    onChange={(e) => {
                      const f = allFiles.find((item) => item.id === e.target.value);
                      if (f) {
                        setCurrentFile(f);
                        generateSummary(f);
                      }
                    }}
                  >
                    <option value="" disabled>اختر ملفاً آخر...</option>
                    {allFiles.filter(f => f.mimeType !== 'application/vnd.google-apps.folder').map(f => (
                      <option key={f.id} value={f.id}>{f.name}</option>
                    ))}
                  </select>

                  {currentFile && (
                    <button
                      onClick={() => generateSummary(currentFile)}
                      disabled={summaryLoading}
                      className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-xl border border-indigo-200 transition-colors"
                      title="إعادة التلخيص"
                    >
                      <RefreshCw className={`w-4 h-4 ${summaryLoading ? 'animate-spin' : ''}`} />
                    </button>
                  )}
                </div>
              </div>

              {/* Summary Results View */}
              {summaryLoading ? (
                <div className="flex flex-col items-center justify-center p-12 text-center bg-white rounded-3xl border border-slate-200/80">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 animate-bounce mb-3">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-slate-800 mb-1">جاري قراءة وتحليل المستند...</h3>
                  <p className="text-xs text-slate-500">يقوم Gemini باستخراج النقاط الجوهرية والملخص التنفيذي</p>
                </div>
              ) : summaryError ? (
                <div className="p-4 bg-red-50 text-red-700 text-xs rounded-2xl border border-red-200">
                  {summaryError}
                </div>
              ) : summaryResult ? (
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-indigo-700">
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                      <span>تقرير التحليل الذكي</span>
                    </div>
                    <button
                      onClick={() => handleCopyText(summaryResult)}
                      className="flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 px-2.5 py-1 rounded-lg transition-colors"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'تم النسخ' : 'نسخ التلخيص'}</span>
                    </button>
                  </div>

                  <div className="text-sm leading-relaxed text-slate-800 whitespace-pre-wrap font-sans">
                    {summaryResult}
                  </div>
                </div>
              ) : (
                <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 text-slate-500 text-xs">
                  اختر أي ملف من القائمة بالأعلى أو انقر على "تلخيص AI" بجوار أي مستند لبدء التحليل.
                </div>
              )}
            </div>
          )}

          {/* TAB 2: CHAT WITH DRIVE */}
          {activeTab === 'chat' && (
            <div className="flex flex-col h-full">
              {/* Context Selector */}
              <div className="flex items-center justify-between gap-2 p-2.5 bg-white rounded-2xl border border-slate-200 mb-3 text-xs">
                <span className="text-slate-500 font-medium">سياق الاستفسار:</span>
                <select
                  className="font-semibold bg-slate-50 border border-slate-200 rounded-xl px-2 py-1 text-slate-700 outline-none max-w-[280px] truncate"
                  value={currentFile?.id || ''}
                  onChange={(e) => {
                    const f = allFiles.find((item) => item.id === e.target.value);
                    setCurrentFile(f || null);
                  }}
                >
                  <option value="">كل ملفات Google Drive (عام)</option>
                  {allFiles.filter(f => f.mimeType !== 'application/vnd.google-apps.folder').map(f => (
                    <option key={f.id} value={f.id}>ملف: {f.name}</option>
                  ))}
                </select>
              </div>

              {/* Chat Thread */}
              <div className="flex-1 overflow-y-auto flex flex-col gap-3 pr-1 pb-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col max-w-[85%] ${
                      msg.role === 'user' ? 'self-start items-start' : 'self-end items-end'
                    }`}
                  >
                    <div
                      className={`p-3.5 rounded-2xl text-sm leading-relaxed ${
                        msg.role === 'user'
                          ? 'bg-blue-600 text-white rounded-tr-none'
                          : msg.role === 'system'
                          ? 'bg-red-50 text-red-700 border border-red-200'
                          : 'bg-white text-slate-800 border border-slate-200 shadow-xs rounded-tl-none'
                      }`}
                    >
                      {msg.fileContextName && msg.role === 'user' && (
                        <div className="text-[10px] text-blue-100 bg-blue-700/60 px-2 py-0.5 rounded mb-1.5 inline-block">
                          حول: {msg.fileContextName}
                        </div>
                      )}
                      <p className="whitespace-pre-wrap">{msg.text}</p>
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1 px-1">{msg.timestamp}</span>
                  </div>
                ))}
                {chatLoading && (
                  <div className="self-end flex items-center gap-2 p-3 bg-white rounded-2xl border border-slate-200 text-xs text-indigo-600 font-semibold">
                    <Sparkles className="w-4 h-4 animate-spin" />
                    <span>جاري التفكير وصياغة الإجابة...</span>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Input Form */}
              <form onSubmit={handleSendMessage} className="pt-2 border-t border-slate-200 flex gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder={currentFile ? `اسأل أي شيء حول "${currentFile.name}"...` : "اسأل عن أي ملف أو اطلب تنظيم مستنداتك..."}
                  className="flex-1 px-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 text-slate-800"
                />
                <button
                  type="submit"
                  disabled={!inputMessage.trim() || chatLoading}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-bold rounded-2xl transition-all shadow-md shadow-indigo-500/20 flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}

          {/* TAB 3: DRAFT GENERATOR & SAVE TO DRIVE */}
          {activeTab === 'draft' && (
            <div className="flex flex-col gap-4">
              <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-3">
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-700">
                  <Lightbulb className="w-4 h-4 text-indigo-600" />
                  <span>توليد مستند ذكي وحفظه مباشرة في Google Drive</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">عنوان / موضوع المستند</label>
                    <input
                      type="text"
                      value={draftTopic}
                      onChange={(e) => setDraftTopic(e.target.value)}
                      placeholder="مثال: خطة إطلاق المشروع التقني 2026"
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">نوع المستند</label>
                    <select
                      value={draftType}
                      onChange={(e) => setDraftType(e.target.value)}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 focus:bg-white"
                    >
                      <option value="تقرير عمل رسمي">تقرير عمل رسمي (Official Report)</option>
                      <option value="محضر اجتماع وقرارات">محضر اجتماع وقرارات (Meeting Minutes)</option>
                      <option value="خطة استراتيجية">خطة استراتيجية (Strategy Plan)</option>
                      <option value="مقال ومحتوى تحليلي">مقال ومحتوى تحليلي (Article / Analysis)</option>
                      <option value="ملاحظات وتلخيص نقاط">ملاحظات وتلخيص نقاط (Notes)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">تفاصيل ومحاور إضافية (اختياري)</label>
                  <textarea
                    rows={2}
                    value={draftDetails}
                    onChange={(e) => setDraftDetails(e.target.value)}
                    placeholder="اكتب أي شروط أو محاور خاصة ترغب في تضمينها..."
                    className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 focus:bg-white resize-none"
                  />
                </div>

                <button
                  onClick={handleGenerateDraft}
                  disabled={!draftTopic.trim() || draftLoading}
                  className="py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-indigo-500/20 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className={`w-4 h-4 ${draftLoading ? 'animate-spin' : ''}`} />
                  <span>{draftLoading ? 'جاري الصياغة بواسطة Gemini...' : 'توليد مسودة المستند'}</span>
                </button>
              </div>

              {/* Generated Content Box & Direct Save Button */}
              {draftContent && (
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-3">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <span className="text-xs font-bold text-slate-800">محتوى المسودة المنشأة</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleCopyText(draftContent)}
                        className="flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 px-2.5 py-1 rounded-lg"
                      >
                        {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copied ? 'تم النسخ' : 'نسخ'}</span>
                      </button>

                      <button
                        onClick={handleSaveDraftToDrive}
                        disabled={isSavingDraft}
                        className="flex items-center gap-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 px-3 py-1.5 rounded-xl shadow-xs transition-colors"
                      >
                        {saveSuccess ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-white" />
                            <span>تم الحفظ في Drive!</span>
                          </>
                        ) : (
                          <>
                            <Save className={`w-3.5 h-3.5 ${isSavingDraft ? 'animate-spin' : ''}`} />
                            <span>{isSavingDraft ? 'جاري الحفظ...' : 'حفظ الملف في Google Drive'}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  <textarea
                    rows={8}
                    value={draftContent}
                    onChange={(e) => setDraftContent(e.target.value)}
                    className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-mono leading-relaxed text-slate-800 outline-none focus:bg-white resize-y"
                  />
                </div>
              )}
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
