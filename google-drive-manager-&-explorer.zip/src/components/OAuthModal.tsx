import React, { useState } from 'react';
import { X, ShieldCheck, Key, LogIn, ExternalLink, Check, Copy, HardDrive, Sparkles } from 'lucide-react';
import { DriveService } from '../services/driveService';

interface OAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  isConnected: boolean;
  onConnectGoogle: () => void;
  onSetCustomToken: (token: string) => void;
}

export const OAuthModal: React.FC<OAuthModalProps> = ({
  isOpen,
  onClose,
  isConnected,
  onConnectGoogle,
  onSetCustomToken,
}) => {
  const [manualToken, setManualToken] = useState('');
  const [copiedScope, setCopiedScope] = useState(false);

  if (!isOpen) return null;

  const scopes = [
    'https://www.googleapis.com/auth/drive.readonly',
    'https://www.googleapis.com/auth/drive.file'
  ];

  const handleApplyManualToken = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualToken.trim()) return;
    DriveService.setStoredToken(manualToken.trim());
    onSetCustomToken(manualToken.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">إعدادات مصادقة Google Drive (OAuth)</h3>
              <p className="text-xs text-slate-500">حالة الصلاحيات والربط السحابي الآمن</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex flex-col gap-5 overflow-y-auto max-h-[80vh]">
          
          {/* Status Badge */}
          <div className={`p-4 rounded-2xl border flex items-center justify-between ${
            isConnected 
              ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900' 
              : 'bg-blue-50/60 border-blue-200 text-blue-900'
          }`}>
            <div className="flex items-center gap-2.5">
              <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-emerald-500 animate-ping' : 'bg-blue-500'}`} />
              <span className="text-xs font-bold">
                {isConnected ? 'حساب Google Drive متصل بنجاح وجاهز للاستخدام' : 'جاهز للربط عبر Google Identity Services'}
              </span>
            </div>
          </div>

          {/* Quick Connect Button */}
          <div>
            <button
              onClick={() => {
                onConnectGoogle();
                onClose();
              }}
              className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs rounded-xl shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              <span>تسجيل الدخول الفوري بحساب Google Drive</span>
            </button>
          </div>

          {/* Configured Scopes */}
          <div>
            <span className="text-xs font-bold text-slate-700 block mb-2">النطاقات والصلاحيات المعتمدة (Scopes):</span>
            <div className="flex flex-col gap-1.5">
              {scopes.map((sc) => (
                <div key={sc} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-mono text-slate-700 flex items-center justify-between">
                  <span className="truncate">{sc}</span>
                  <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    مصرّح
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Manual Token Option (for advanced testing) */}
          <div className="pt-3 border-t border-slate-100">
            <label className="text-xs font-bold text-slate-700 block mb-1.5">
              إدخال رمز وصول مباشر (OAuth Access Token)
            </label>
            <p className="text-[11px] text-slate-500 mb-2">
              يمكنك لصق Access Token جاهز لتشغيل واستعراض ملفاتك الحقيقية على الفور.
            </p>

            <form onSubmit={handleApplyManualToken} className="flex gap-2">
              <input
                type="text"
                value={manualToken}
                onChange={(e) => setManualToken(e.target.value)}
                placeholder="ya29.a0AfH6SM..."
                className="flex-1 px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:bg-white"
              />
              <button
                type="submit"
                disabled={!manualToken.trim()}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 disabled:bg-slate-200 text-white font-bold text-xs rounded-xl transition-colors"
              >
                تطبيق
              </button>
            </form>
          </div>

        </div>
      </div>
    </div>
  );
};
