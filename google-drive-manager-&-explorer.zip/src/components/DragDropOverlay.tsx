import React from 'react';
import { Upload, FileUp, Sparkles, Folder } from 'lucide-react';

interface DragDropOverlayProps {
  isDragging: boolean;
  currentFolderName: string;
  isUploading?: boolean;
}

export const DragDropOverlay: React.FC<DragDropOverlayProps> = ({
  isDragging,
  currentFolderName,
  isUploading = false,
}) => {
  if (!isDragging && !isUploading) return null;

  return (
    <div
      id="drag-drop-overlay"
      className={`absolute inset-0 z-40 m-2 sm:m-4 rounded-3xl border-3 border-dashed transition-all duration-200 flex flex-col items-center justify-center p-6 text-center backdrop-blur-md select-none pointer-events-none ${
        isUploading
          ? 'bg-blue-600/10 border-blue-500 shadow-2xl'
          : 'bg-blue-500/15 border-blue-600 shadow-2xl animate-pulse'
      }`}
    >
      <div className="relative p-5 rounded-3xl bg-white/95 border border-blue-100 shadow-xl flex flex-col items-center max-w-sm w-full mx-auto">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 text-white flex items-center justify-center mb-3 shadow-lg shadow-blue-500/30">
          {isUploading ? (
            <div className="w-8 h-8 border-3 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <FileUp className="w-8 h-8 animate-bounce" />
          )}
        </div>

        <h3 className="text-base font-extrabold text-slate-900 mb-1">
          {isUploading ? 'جاري رفع الملفات إلى Drive...' : 'أفلت الملفات لرفعها مباشرة'}
        </h3>

        <div className="flex items-center gap-1.5 text-xs text-blue-700 font-semibold bg-blue-50 px-3 py-1 rounded-full mt-1 border border-blue-200/60">
          <Folder className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate max-w-[200px]">المجلد: {currentFolderName}</span>
        </div>

        <p className="text-[11px] text-slate-500 mt-3 flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
          <span>سيتم تحليل وتصنيف الملفات تلقائياً بواسطة الذكاء الاصطناعي</span>
        </p>
      </div>
    </div>
  );
};
