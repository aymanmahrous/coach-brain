import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown, 
  Check, 
  Clock, 
  FileText, 
  HardDrive, 
  SortAsc, 
  Volume2, 
  VolumeX, 
  Keyboard 
} from 'lucide-react';
import { SortField, SortDirection, SortOption } from '../types';
import { SoundEffects } from '../utils/audioChime';

interface SortControlsProps {
  sortOption: SortOption;
  onSortChange: (option: SortOption) => void;
  onOpenShortcuts: () => void;
}

const SORT_FIELD_OPTIONS: { field: SortField; label: string; icon: React.ReactNode }[] = [
  { field: 'modifiedTime', label: 'تاريخ آخر تعديل', icon: <Clock className="w-4 h-4 text-blue-600" /> },
  { field: 'name', label: 'الاسم أبجدياً', icon: <SortAsc className="w-4 h-4 text-emerald-600" /> },
  { field: 'size', label: 'حجم الملف', icon: <HardDrive className="w-4 h-4 text-amber-600" /> },
  { field: 'type', label: 'نوع الملف', icon: <FileText className="w-4 h-4 text-purple-600" /> },
];

export const SortControls: React.FC<SortControlsProps> = ({
  sortOption,
  onSortChange,
  onOpenShortcuts,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isSoundOn, setIsSoundOn] = useState(() => SoundEffects.isSoundEnabled());
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleToggleDirection = () => {
    SoundEffects.playPop();
    onSortChange({
      ...sortOption,
      direction: sortOption.direction === 'asc' ? 'desc' : 'asc',
    });
  };

  const handleSelectField = (field: SortField) => {
    SoundEffects.playPop();
    onSortChange({
      field,
      // Default to desc for date/size, asc for name
      direction: field === 'name' ? 'asc' : 'desc',
    });
    setIsOpen(false);
  };

  const toggleSound = () => {
    const next = !isSoundOn;
    setIsSoundOn(next);
    SoundEffects.setSoundEnabled(next);
    if (next) SoundEffects.playSuccess();
  };

  const currentFieldMeta = SORT_FIELD_OPTIONS.find((o) => o.field === sortOption.field) || SORT_FIELD_OPTIONS[0];

  return (
    <div className="flex items-center gap-1.5" dir="rtl">
      {/* Sort Dropdown */}
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
            isOpen
              ? 'bg-blue-50 text-blue-700 border-blue-300 shadow-xs'
              : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 shadow-2xs'
          }`}
          title="ترتيب وفرز الملفات"
        >
          <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
          <span className="hidden sm:inline">{currentFieldMeta.label}</span>
          <span className="sm:hidden">ترتيب</span>
        </button>

        {isOpen && (
          <div className="absolute left-0 mt-1.5 w-48 bg-white rounded-2xl shadow-xl border border-slate-200/90 py-1.5 z-30 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-3 py-1 text-[11px] font-extrabold text-slate-400 uppercase tracking-wider border-b border-slate-100 mb-1">
              فرز حسب
            </div>
            {SORT_FIELD_OPTIONS.map((opt) => {
              const isSelected = sortOption.field === opt.field;
              return (
                <button
                  key={opt.field}
                  onClick={() => handleSelectField(opt.field)}
                  className={`w-full flex items-center justify-between px-3 py-2 text-xs font-semibold transition-colors text-right cursor-pointer ${
                    isSelected
                      ? 'bg-blue-50 text-blue-700 font-bold'
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {opt.icon}
                    <span>{opt.label}</span>
                  </div>
                  {isSelected && <Check className="w-3.5 h-3.5 text-blue-600" />}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Direction Toggle (Asc / Desc) */}
      <button
        onClick={handleToggleDirection}
        className="p-1.5 bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200 rounded-xl shadow-2xs transition-colors cursor-pointer"
        title={sortOption.direction === 'asc' ? 'تصاعدي (انقر للتغيير لتنازلي)' : 'تنازلي (انقر للتغيير لتصاعدي)'}
      >
        {sortOption.direction === 'asc' ? (
          <ArrowUp className="w-3.5 h-3.5 text-blue-600" />
        ) : (
          <ArrowDown className="w-3.5 h-3.5 text-blue-600" />
        )}
      </button>

      {/* Sound Toggle */}
      <button
        onClick={toggleSound}
        className={`p-1.5 border rounded-xl shadow-2xs transition-colors cursor-pointer ${
          isSoundOn
            ? 'bg-white hover:bg-slate-50 text-slate-600 border-slate-200'
            : 'bg-slate-100 text-slate-400 border-slate-200'
        }`}
        title={isSoundOn ? 'كتم المؤثرات الصوتية التفاعلية' : 'تفعيل المؤثرات الصوتية'}
      >
        {isSoundOn ? (
          <Volume2 className="w-3.5 h-3.5 text-slate-600" />
        ) : (
          <VolumeX className="w-3.5 h-3.5 text-slate-400" />
        )}
      </button>

      {/* Keyboard Shortcuts Trigger */}
      <button
        onClick={onOpenShortcuts}
        className="p-1.5 bg-white hover:bg-slate-50 text-slate-600 hover:text-indigo-600 border border-slate-200 rounded-xl shadow-2xs transition-colors cursor-pointer"
        title="اختصارات لوحة المفاتيح (?)"
      >
        <Keyboard className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
