import React, { useState } from 'react';
import { 
  X, 
  Send, 
  Radio, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  ExternalLink, 
  Sparkles, 
  Copy, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  User, 
  PhoneCall, 
  Globe, 
  Zap,
  Clock
} from 'lucide-react';
import { DriveFile } from '../types';
import { formatBytes, getFileTypeMeta } from '../services/driveService';

interface SendToAutomationModalProps {
  file: DriveFile | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (result: any) => void;
}

export const SendToAutomationModal: React.FC<SendToAutomationModalProps> = ({
  file,
  isOpen,
  onClose,
  onSuccess
}) => {
  if (!isOpen || !file) return null;

  const [channel, setChannel] = useState<'whatsapp' | 'messenger'>('whatsapp');
  const [recipientOption, setRecipientOption] = useState<string>('wa_1');
  const [customPhone, setCustomPhone] = useState<string>('');
  const [customRecipientName, setCustomRecipientName] = useState<string>('');
  const [branch, setBranch] = useState<string>('أبوظبي: الكورنيش');
  const [customMessage, setCustomMessage] = useState<string>(
    `مرحباً بك! مرفق لك مستند "${file.name}" من أكاديمية كوتش أيمن للسباحة (Swim Fluent / Relax Fix UAE). نتمنى لك كل التوفيق!`
  );

  const [isSending, setIsSending] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [showPayloadPreview, setShowPayloadPreview] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Pre-configured recipient options
  const PRESET_RECIPIENTS = [
    { id: 'wa_1', name: 'أم راشد (حصة خاصة للأطفال)', phoneOrId: '+971 50 842 1920', platform: 'whatsapp', branch: 'أبوظبي: البطين' },
    { id: 'wa_2', name: 'سعيد المنصوري (باقة علاج الفوبيا)', phoneOrId: '+971 55 319 4482', platform: 'whatsapp', branch: 'أبوظبي: المشرف' },
    { id: 'msg_1', name: 'م. خالد النعيمي (استفسار تدريب كبار)', phoneOrId: 'fb_user_8829104', platform: 'messenger', branch: 'أبوظبي: الكورنيش' },
    { id: 'custom', name: 'إدخال رقم هاتف عميل مخصص...', phoneOrId: '', platform: 'any', branch: 'أبوظبي: الكورنيش' }
  ];

  const selectedPreset = PRESET_RECIPIENTS.find(r => r.id === recipientOption);
  const finalRecipientPhone = recipientOption === 'custom' ? customPhone : (selectedPreset?.phoneOrId || '+971 50 842 1920');
  const finalRecipientName = recipientOption === 'custom' ? (customRecipientName || 'عميل مخصص') : (selectedPreset?.name || 'عميل');

  const fileMeta = getFileTypeMeta(file.mimeType);

  const targetEndpointDisplay = channel === 'whatsapp'
    ? 'N8N_WHATSAPP_WEBHOOK_URL (https://n8n.your-domain.com/webhook/coach-whatsapp)'
    : 'N8N_MESSENGER_WEBHOOK_URL (https://n8n.your-domain.com/webhook/coach-messenger)';

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleDispatch = async () => {
    setIsSending(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch('/api/n8n/dispatch-file-automation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileId: file.id,
          fileName: file.name,
          mimeType: file.mimeType,
          fileSize: formatBytes(file.size),
          webViewLink: file.webViewLink || file.webContentLink || '',
          channel,
          recipientPhoneOrId: finalRecipientPhone,
          recipientName: finalRecipientName,
          customMessage,
          branch
        })
      });

      const data = await res.json();
      if (data?.success) {
        setResult(data);
        if (onSuccess) onSuccess(data);
      } else {
        setError(data?.error || 'حدث خطأ أثناء الإرسال إلى n8n');
      }
    } catch (err: any) {
      setError(err.message || 'تعذر الاتصال بخادم الأتمتة');
    } finally {
      setIsSending(false);
    }
  };

  const payloadPreviewObj = {
    event: 'file_automation_dispatch',
    source: 'CoachAyman_FileDrive',
    channel,
    file: {
      id: file.id,
      name: file.name,
      mimeType: file.mimeType,
      size: formatBytes(file.size),
      link: file.webViewLink
    },
    recipient: {
      phoneOrId: finalRecipientPhone,
      name: finalRecipientName
    },
    branch,
    message: customMessage
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
      <div className="bg-[#07131e] border-2 border-emerald-500/50 rounded-3xl max-w-xl w-full p-6 text-white shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Glow ambient background */}
        <div className="absolute -top-24 -right-24 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-60 h-60 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-cyan-950 relative z-10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-cyan-600 flex items-center justify-center shadow-lg shadow-emerald-500/25 shrink-0 text-white">
              <Zap className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white">إرسال الملف إلى الأتمتة (n8n Automation)</h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold">
                  .env.example Endpoints
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                توجيه بيانات المستند المختار آلياً إلى نقاط نهاية سير العمل في n8n المخصصة للتواصل
              </p>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="py-4 space-y-4 overflow-y-auto pr-1 flex-1">
          
          {/* Selected File Card */}
          <div className="bg-[#061019] border border-cyan-950 rounded-2xl p-3.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
                <FileText className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-white truncate" title={file.name}>
                  {file.name}
                </div>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                  <span className="bg-slate-800 px-1.5 py-0.2 rounded font-mono">{formatBytes(file.size)}</span>
                  <span>•</span>
                  <span>{fileMeta.label}</span>
                </div>
              </div>
            </div>

            {file.webViewLink && (
              <a
                href={file.webViewLink}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg flex items-center gap-1 shrink-0 transition-colors"
              >
                <span>معاينة</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>

          {/* Channel Selection (WhatsApp vs Messenger) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-200 block">
              1. اختر قناة الأتمتة ونقطة نهاية n8n:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setChannel('whatsapp')}
                className={`p-3 rounded-xl border flex items-center gap-2.5 text-xs font-bold transition-all cursor-pointer ${
                  channel === 'whatsapp'
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-500/10'
                    : 'bg-[#091522] border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <span className="text-emerald-400 text-base">💬</span>
                <div className="text-right">
                  <div>واتساب عبر n8n</div>
                  <div className="text-[9px] font-mono font-normal opacity-70">N8N_WHATSAPP_WEBHOOK_URL</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setChannel('messenger')}
                className={`p-3 rounded-xl border flex items-center gap-2.5 text-xs font-bold transition-all cursor-pointer ${
                  channel === 'messenger'
                    ? 'bg-blue-950/60 border-blue-500 text-blue-300 shadow-md shadow-blue-500/10'
                    : 'bg-[#091522] border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <span className="text-blue-400 text-base">⚡</span>
                <div className="text-right">
                  <div>مسنجر عبر n8n</div>
                  <div className="text-[9px] font-mono font-normal opacity-70">N8N_MESSENGER_WEBHOOK_URL</div>
                </div>
              </button>
            </div>
            <div className="text-[10px] text-slate-400 font-mono bg-[#050d14] px-2.5 py-1.5 rounded-lg border border-slate-800 truncate" dir="ltr">
              Target Endpoint: {targetEndpointDisplay}
            </div>
          </div>

          {/* Recipient Selection */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-200 block">
              2. المستلم المستهدف (المتدرب / ولي الأمر):
            </label>
            <select
              value={recipientOption}
              onChange={(e) => setRecipientOption(e.target.value)}
              className="w-full bg-[#061019] border border-cyan-950 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
            >
              {PRESET_RECIPIENTS.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name} {r.phoneOrId ? `(${r.phoneOrId})` : ''}
                </option>
              ))}
            </select>

            {recipientOption === 'custom' && (
              <div className="grid grid-cols-2 gap-2 pt-1">
                <input
                  type="text"
                  placeholder="اسم المستلم (مثال: أحمد الشامسي)"
                  value={customRecipientName}
                  onChange={(e) => setCustomRecipientName(e.target.value)}
                  className="bg-[#061019] border border-cyan-950 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
                <input
                  type="text"
                  placeholder="رقم الهاتف (+971 50...)"
                  value={customPhone}
                  onChange={(e) => setCustomPhone(e.target.value)}
                  className="bg-[#061019] border border-cyan-950 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                  dir="ltr"
                />
              </div>
            )}
          </div>

          {/* Branch */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-200 block">
              3. فرع الأكاديمية المرتبط بأبوظبي:
            </label>
            <select
              value={branch}
              onChange={(e) => setBranch(e.target.value)}
              className="w-full bg-[#061019] border border-cyan-950 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
            >
              <option value="أبوظبي: الكورنيش">أبوظبي: الكورنيش (مسبح أولمبي)</option>
              <option value="أبوظبي: البطين">أبوظبي: البطين (مسبح خاص للأطفال)</option>
              <option value="أبوظبي: المشرف">أبوظبي: المشرف (علاج فوبيا وتأهيل)</option>
              <option value="كافة الفروع">كافة فروع أبوظبي</option>
            </select>
          </div>

          {/* Custom Message / Caption */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-200 block">
              4. نص الرسالة المصاحبة للمستند:
            </label>
            <textarea
              rows={3}
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              className="w-full bg-[#061019] border border-cyan-950 rounded-xl p-3 text-xs text-slate-100 focus:outline-none focus:border-cyan-400 leading-relaxed"
              placeholder="اكتب الرسالة المصاحبة..."
            />
          </div>

          {/* Collapsible JSON Payload Preview */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-[#050f18]">
            <button
              type="button"
              onClick={() => setShowPayloadPreview(!showPayloadPreview)}
              className="w-full px-3 py-2 text-xs font-semibold text-slate-400 hover:text-white flex items-center justify-between transition-colors"
            >
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>معاينة حمولة البيانات لـ n8n (JSON Payload Preview)</span>
              </span>
              {showPayloadPreview ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {showPayloadPreview && (
              <pre className="p-3 text-[10px] font-mono text-cyan-300 bg-black/60 overflow-x-auto border-t border-slate-800 max-h-40" dir="ltr">
                {JSON.stringify(payloadPreviewObj, null, 2)}
              </pre>
            )}
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-700/60 text-xs text-rose-300 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Success Receipt */}
          {result && (
            <div className="p-4 rounded-2xl bg-emerald-950/50 border border-emerald-600/70 text-xs space-y-2 animate-in fade-in">
              <div className="flex items-center gap-2 text-emerald-300 font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>تم إرسال الملف إلى أتمتة n8n بنجاح!</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                <div className="p-2 rounded bg-black/40 border border-emerald-900">
                  <span className="text-slate-400 block text-[10px]">معرف التنفيذ (Execution ID):</span>
                  <span className="font-mono text-white font-bold">{result.executionId}</span>
                </div>
                <div className="p-2 rounded bg-black/40 border border-emerald-900">
                  <span className="text-slate-400 block text-[10px]">القناة:</span>
                  <span className="text-emerald-300 font-bold">{result.channel === 'whatsapp' ? 'WhatsApp Cloud' : 'Messenger'}</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed pt-1">
                ✓ {result.message}
              </p>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-cyan-950 flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            إلغاء
          </button>

          <button
            type="button"
            onClick={handleDispatch}
            disabled={isSending}
            className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-emerald-600/20 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span>{isSending ? 'جارٍ الإرسال إلى n8n...' : 'إرسال إلى الأتمتة الآن (n8n)'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
