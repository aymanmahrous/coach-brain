import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Sparkles, 
  BrainCircuit, 
  RefreshCw, 
  Copy, 
  Check, 
  Save, 
  Folder, 
  Files, 
  HardDrive, 
  PieChart, 
  Send, 
  Bot, 
  FileText, 
  Download,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  HelpCircle,
  Archive
} from 'lucide-react';
import { DriveFile, BreadcrumbItem } from '../types';
import { formatBytes, formatDate } from '../services/driveService';
import { SoundEffects } from '../utils/audioChime';

interface FolderAnalysisDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  folderName: string;
  folderId: string;
  files: DriveFile[];
  breadcrumbs: BreadcrumbItem[];
  token: string | null;
  onSaveDocToFolder?: (title: string, content: string) => Promise<void>;
  onBackupFolder?: () => void;
}

interface TypeStat {
  label: string;
  count: number;
  color: string;
}

export const FolderAnalysisDrawer: React.FC<FolderAnalysisDrawerProps> = ({
  isOpen,
  onClose,
  folderName,
  folderId,
  files,
  breadcrumbs,
  token,
  onSaveDocToFolder,
  onBackupFolder,
}) => {
  const [analysisText, setAnalysisText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  // Folder Chat State
  const [chatQuestion, setChatQuestion] = useState<string>('');
  const [chatAnswers, setChatAnswers] = useState<{ q: string; a: string; time: string }[]>([]);
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);

  const drawerRef = useRef<HTMLDivElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Calculate folder statistics
  const totalFiles = files.length;
  const folderCount = files.filter((f) => f.mimeType === 'application/vnd.google-apps.folder').length;
  const nonFolderFiles = files.filter((f) => f.mimeType !== 'application/vnd.google-apps.folder');
  const totalBytes = nonFolderFiles.reduce((acc, f) => acc + (Number(f.size) || 0), 0);
  const starredCount = files.filter((f) => f.starred).length;
  const sharedCount = files.filter((f) => f.shared).length;

  // Calculate type distribution
  const typeStats: TypeStat[] = React.useMemo(() => {
    let docs = 0, sheets = 0, slides = 0, pdfs = 0, images = 0, archives = 0, other = 0;
    nonFolderFiles.forEach((f) => {
      const mime = f.mimeType || '';
      const name = (f.name || '').toLowerCase();
      if (mime.includes('document') || mime.includes('word') || name.endsWith('.docx') || name.endsWith('.doc')) docs++;
      else if (mime.includes('spreadsheet') || mime.includes('excel') || mime.includes('sheet') || name.endsWith('.xlsx') || name.endsWith('.csv')) sheets++;
      else if (mime.includes('presentation') || mime.includes('powerpoint') || name.endsWith('.pptx')) slides++;
      else if (mime.includes('pdf') || name.endsWith('.pdf')) pdfs++;
      else if (mime.startsWith('image/') || name.endsWith('.png') || name.endsWith('.jpg') || name.endsWith('.jpeg')) images++;
      else if (mime.includes('zip') || mime.includes('rar') || mime.includes('tar') || name.endsWith('.zip')) archives++;
      else other++;
    });

    const list: TypeStat[] = [];
    if (folderCount > 0) list.push({ label: `مجلدات (${folderCount})`, count: folderCount, color: 'bg-amber-100 text-amber-800 border-amber-200' });
    if (docs > 0) list.push({ label: `مستندات (${docs})`, count: docs, color: 'bg-blue-100 text-blue-800 border-blue-200' });
    if (sheets > 0) list.push({ label: `جداول بيانات (${sheets})`, count: sheets, color: 'bg-emerald-100 text-emerald-800 border-emerald-200' });
    if (slides > 0) list.push({ label: `عروض تقديمية (${slides})`, count: slides, color: 'bg-orange-100 text-orange-800 border-orange-200' });
    if (pdfs > 0) list.push({ label: `ملفات PDF (${pdfs})`, count: pdfs, color: 'bg-rose-100 text-rose-800 border-rose-200' });
    if (images > 0) list.push({ label: `صور ووسائط (${images})`, count: images, color: 'bg-purple-100 text-purple-800 border-purple-200' });
    if (archives > 0) list.push({ label: `ملفات مضغوطة (${archives})`, count: archives, color: 'bg-slate-100 text-slate-800 border-slate-200' });
    if (other > 0) list.push({ label: `أخرى (${other})`, count: other, color: 'bg-cyan-100 text-cyan-800 border-cyan-200' });
    return list;
  }, [files, folderCount, nonFolderFiles]);

  const loadAnalysis = async () => {
    if (files.length === 0) {
      setAnalysisText('المجلد الحالي فارغ حالياً. قم برفع أو إنشاء ملفات لبدء التحليل الذكي وتلخيص المحتوى.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSaveSuccess(false);

    try {
      const response = await fetch('/api/ai/analyze-folder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          folderName,
          files,
          breadcrumbs,
        }),
      });

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || 'تعذر استلام تحليل المجلد من الخادم.');
      }

      const data = await response.json();
      setAnalysisText(data.result || '');
      SoundEffects.playSuccess();
    } catch (err: any) {
      setError(err.message || 'حدث خطأ غير متوقع أثناء معالجة تحليل المجلد.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadAnalysis();
    }
  }, [isOpen, folderId, folderName]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleCopyText = () => {
    if (!analysisText) return;
    navigator.clipboard.writeText(analysisText);
    SoundEffects.playPop();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveToDrive = async () => {
    if (!analysisText || !onSaveDocToFolder || isSaving) return;
    setIsSaving(true);
    SoundEffects.playPop();
    try {
      const title = `تقرير تحليل المجلد - ${folderName} (${new Date().toLocaleDateString('ar-EG')})`;
      const content = `# ${title}\n\n${analysisText}\n\n---\n*تم التوليد تلقائياً بواسطة مساعد Google Drive الذكي المدعوم بـ Gemini*`;
      await onSaveDocToFolder(title, content);
      setSaveSuccess(true);
      SoundEffects.playSuccess();
      setTimeout(() => setSaveSuccess(false), 3500);
    } catch (err: any) {
      alert(`تعذر حفظ التقرير في المجلد: ${err.message || 'خطأ غير معروف'}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSendChatQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatQuestion.trim() || isChatLoading) return;

    const query = chatQuestion.trim();
    setChatQuestion('');
    setIsChatLoading(true);
    SoundEffects.playPop();

    try {
      const fileListSummary = files.slice(0, 30).map((f) => `- ${f.name} (${f.mimeType}, ${f.size ? Math.round(Number(f.size) / 1024) + 'KB' : 'مجلد'})`).join('\n');
      
      const prompt = `سؤال المستخدم حول محتوى المجلد "${folderName}":
${query}

بيانات المجلد وقائمة الملفات:
${fileListSummary}

التحليل العام السابق للمجلد:
${analysisText.slice(0, 1500)}

أجب عن استفسار المستخدم بدقة وإيجاز باللغة العربية.`;

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
        }),
      });

      if (!res.ok) {
        throw new Error('فشل في إجابة المساعد الذكي.');
      }

      const data = await res.json();
      setChatAnswers((prev) => [
        ...prev,
        {
          q: query,
          a: data.reply || 'لا تتوفر إجابة.',
          time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      SoundEffects.playSuccess();
      setTimeout(() => {
        chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (err: any) {
      setChatAnswers((prev) => [
        ...prev,
        {
          q: query,
          a: 'عذراً، تعذر الإجابة على السؤال في الوقت الحالي. يرجى المحاولة لاحقاً.',
          time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" dir="rtl">
      {/* Backdrop */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity duration-300 animate-in fade-in" 
      />

      {/* Slide-out Drawer Panel */}
      <div 
        ref={drawerRef}
        className="absolute inset-y-0 left-0 max-w-full flex pl-0 sm:pl-10"
      >
        <div className="w-screen max-w-2xl bg-white shadow-2xl flex flex-col border-r border-slate-200 animate-in slide-in-from-left duration-300">
          
          {/* Header */}
          <div className="p-4 sm:p-5 bg-gradient-to-l from-indigo-900 via-indigo-800 to-slate-900 text-white flex items-center justify-between shrink-0 shadow-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-amber-300 shadow-inner">
                <BrainCircuit className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
                    تحليل محتوى المجلد بالذكاء الاصطناعي
                  </h2>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-400 text-indigo-950">
                    Gemini AI
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-indigo-200 mt-0.5">
                  <Folder className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                  <span className="font-semibold text-white truncate max-w-[260px]">{folderName || 'المجلد الحالي'}</span>
                  <span>•</span>
                  <span>{totalFiles} عناصر</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={loadAnalysis}
                disabled={isLoading}
                title="إعادة فحص وتحليل المجلد"
                className="p-2 text-indigo-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors disabled:opacity-50 cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              </button>

              <button
                onClick={onClose}
                title="إغلاق النافذة (Esc)"
                className="p-2 text-indigo-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Folder Metrics Bar */}
          <div className="bg-slate-50 border-b border-slate-200/90 p-3 sm:px-5 flex flex-wrap items-center justify-between gap-3 shrink-0">
            <div className="flex items-center flex-wrap gap-2 text-xs">
              <div className="flex items-center gap-1 px-2.5 py-1 bg-white rounded-xl border border-slate-200 shadow-2xs font-semibold text-slate-700">
                <Files className="w-3.5 h-3.5 text-blue-600" />
                <span>إجمالي الملفات: <strong className="text-slate-900">{nonFolderFiles.length}</strong></span>
              </div>

              {folderCount > 0 && (
                <div className="flex items-center gap-1 px-2.5 py-1 bg-white rounded-xl border border-slate-200 shadow-2xs font-semibold text-slate-700">
                  <Folder className="w-3.5 h-3.5 text-amber-500" />
                  <span>مجلدات فرعية: <strong className="text-slate-900">{folderCount}</strong></span>
                </div>
              )}

              <div className="flex items-center gap-1 px-2.5 py-1 bg-white rounded-xl border border-slate-200 shadow-2xs font-semibold text-slate-700">
                <HardDrive className="w-3.5 h-3.5 text-emerald-600" />
                <span>الحجم الكلي: <strong className="text-slate-900">{formatBytes(totalBytes)}</strong></span>
              </div>

              {starredCount > 0 && (
                <div className="flex items-center gap-1 px-2.5 py-1 bg-amber-50 rounded-xl border border-amber-200 text-amber-800 font-semibold">
                  <span>★ المميزة: {starredCount}</span>
                </div>
              )}
            </div>

            {/* Quick Action Buttons */}
            <div className="flex items-center gap-1.5 mr-auto">
              <button
                onClick={handleCopyText}
                disabled={!analysisText || isLoading}
                className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors shadow-2xs cursor-pointer disabled:opacity-50"
                title="نسخ التقرير التحليلي للحافظة"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
                <span>{copied ? 'تم النسخ' : 'نسخ التقرير'}</span>
              </button>

              {onBackupFolder && (
                <button
                  onClick={onBackupFolder}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-emerald-500/20 shadow-2xs transition-all cursor-pointer"
                  title="ضغط وتنزيل محتويات المجلد كملف ZIP"
                >
                  <Archive className="w-3.5 h-3.5" />
                  <span>نسخ احتياطي (ZIP)</span>
                </button>
              )}

              {onSaveDocToFolder && (
                <button
                  onClick={handleSaveToDrive}
                  disabled={!analysisText || isLoading || isSaving}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-all shadow-2xs cursor-pointer ${
                    saveSuccess
                      ? 'bg-emerald-600 text-white'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/20'
                  }`}
                  title="حفظ التقرير كمستند في هذا المجلد"
                >
                  {saveSuccess ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>تم الحفظ في Drive</span>
                    </>
                  ) : (
                    <>
                      <Save className={`w-3.5 h-3.5 ${isSaving ? 'animate-spin' : ''}`} />
                      <span>{isSaving ? 'جاري الحفظ...' : 'حفظ كتقرير'}</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Type breakdown pills */}
          {typeStats.length > 0 && (
            <div className="px-4 sm:px-5 py-2.5 bg-slate-100/60 border-b border-slate-200/70 flex items-center gap-1.5 overflow-x-auto text-[11px] shrink-0 no-scrollbar">
              <span className="font-extrabold text-slate-400 shrink-0 ml-1">توزيع الأنواع:</span>
              {typeStats.map((item, i) => (
                <span 
                  key={i} 
                  className={`px-2 py-0.5 rounded-lg border font-bold shrink-0 shadow-3xs ${item.color}`}
                >
                  {item.label}
                </span>
              ))}
            </div>
          )}

          {/* Scrollable Content Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">

            {/* Error Banner */}
            {error && (
              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-bold mb-1">{error}</p>
                  <button 
                    onClick={loadAnalysis}
                    className="text-rose-900 underline font-extrabold hover:text-rose-700"
                  >
                    إعادة محاولة التحليل
                  </button>
                </div>
              </div>
            )}

            {/* Loading State */}
            {isLoading && (
              <div className="p-8 sm:p-12 text-center flex flex-col items-center justify-center space-y-4">
                <div className="relative">
                  <div className="w-16 h-16 rounded-3xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600 shadow-sm animate-pulse">
                    <Sparkles className="w-8 h-8 animate-spin" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 animate-ping" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-800">
                    جاري فحص وتلخيص محتوى المجلد...
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm">
                    يقوم نموذج Gemini باستقراء طبيعة الملفات والمستندات واستخراج الأفكار المحورية وتقديم توصيات التنظيم.
                  </p>
                </div>
              </div>
            )}

            {/* Analysis Result Display */}
            {!isLoading && analysisText && (
              <div className="bg-slate-50/70 p-5 sm:p-6 rounded-3xl border border-slate-200/90 shadow-xs">
                <div className="prose prose-sm max-w-none text-slate-800 leading-relaxed space-y-3 font-sans whitespace-pre-wrap selection:bg-indigo-100 selection:text-indigo-900">
                  {analysisText}
                </div>
              </div>
            )}

            {/* Follow-up Interactive Q&A for this folder */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-4 sm:p-5">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-1.5 rounded-xl bg-indigo-50 text-indigo-600">
                  <HelpCircle className="w-4 h-4" />
                </div>
                <h4 className="text-xs font-extrabold text-slate-800">
                  استفسر من المساعد الذكي عن هذا المجلد
                </h4>
              </div>

              {/* Chat Thread */}
              {chatAnswers.length > 0 && (
                <div className="space-y-3 mb-4 max-h-60 overflow-y-auto pr-1">
                  {chatAnswers.map((item, idx) => (
                    <div key={idx} className="space-y-1.5 text-xs">
                      <div className="bg-indigo-50 text-indigo-950 p-2.5 rounded-2xl rounded-tr-none font-semibold">
                        <span className="text-[10px] text-indigo-500 block mb-0.5">سؤالك:</span>
                        {item.q}
                      </div>
                      <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl rounded-tl-none text-slate-800 leading-relaxed whitespace-pre-wrap">
                        <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                          <span className="flex items-center gap-1 font-bold text-indigo-600">
                            <Bot className="w-3 h-3" /> إجابة Gemini
                          </span>
                          <span>{item.time}</span>
                        </div>
                        {item.a}
                      </div>
                    </div>
                  ))}
                  <div ref={chatBottomRef} />
                </div>
              )}

              {/* Input Form */}
              <form onSubmit={handleSendChatQuestion} className="relative flex items-center gap-2">
                <input
                  type="text"
                  value={chatQuestion}
                  onChange={(e) => setChatQuestion(e.target.value)}
                  placeholder="مثال: هل توجد هنا عقود تحتاج لمراجعة؟ أو ما هو أكبر ملف حجماً؟"
                  className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all text-slate-800 placeholder:text-slate-400"
                />
                <button
                  type="submit"
                  disabled={!chatQuestion.trim() || isChatLoading}
                  className="absolute left-1.5 p-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
                  title="إرسال السؤال"
                >
                  <Send className={`w-3.5 h-3.5 ${isChatLoading ? 'animate-spin' : ''}`} />
                </button>
              </form>
            </div>

          </div>

          {/* Footer Info */}
          <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500 shrink-0">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              مدعوم بنماذج Gemini المتقدمة لتحليل المستودعات السحابية
            </span>
            <button
              onClick={onClose}
              className="px-3 py-1 bg-white hover:bg-slate-100 text-slate-700 font-bold rounded-lg border border-slate-200 cursor-pointer"
            >
              إغلاق
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
