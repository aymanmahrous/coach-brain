import React from 'react';
import { 
  CheckSquare, 
  Square, 
  Star, 
  Trash2, 
  Sparkles, 
  ExternalLink, 
  X, 
  Download,
  Share2,
  RefreshCw,
  FolderInput,
  FileEdit,
  Send
} from 'lucide-react';
import { DriveFile } from '../types';

interface BatchActionBarProps {
  selectedFiles: DriveFile[];
  totalFilesCount: number;
  onSelectAll: () => void;
  onClearSelection: () => void;
  onBatchStar: (star: boolean) => void;
  onBatchDelete: () => void;
  onBatchAIAnalyze: () => void;
  onBatchOpenLinks: () => void;
  onBatchRename?: () => void;
  onBatchSendToAutomation?: () => void;
  isTrashView?: boolean;
}

export const BatchActionBar: React.FC<BatchActionBarProps> = ({
  selectedFiles = [],
  totalFilesCount = 0,
  onSelectAll,
  onClearSelection,
  onBatchStar,
  onBatchDelete,
  onBatchAIAnalyze,
  onBatchOpenLinks,
  onBatchRename,
  onBatchSendToAutomation,
  isTrashView = false,
}) => {
  const count = selectedFiles ? selectedFiles.length : 0;
  if (count === 0) return null;

  const isAllSelected = count === totalFilesCount && totalFilesCount > 0;
  const anyUnstarred = selectedFiles.some((f) => !f.starred);

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 w-[94%] max-w-2xl animate-in slide-in-from-bottom-6 duration-200">
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 bg-slate-900/95 backdrop-blur-md text-white rounded-2xl shadow-2xl border border-slate-700/80">
        
        {/* Count & Select All */}
        <div className="flex items-center gap-3">
          <button
            onClick={isAllSelected ? onClearSelection : onSelectAll}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-200 hover:text-white px-2.5 py-1.5 rounded-xl hover:bg-slate-800 transition-colors"
          >
            {isAllSelected ? (
              <CheckSquare className="w-4 h-4 text-blue-400" />
            ) : (
              <Square className="w-4 h-4 text-slate-400" />
            )}
            <span>{isAllSelected ? 'إلغاء تحديد الكل' : 'تحديد الكل'}</span>
          </button>

          <div className="h-4 w-px bg-slate-700" />

          <span className="text-xs font-extrabold text-blue-400 bg-blue-500/10 px-2.5 py-1 rounded-lg border border-blue-500/20">
            {count} {count === 1 ? 'ملف محدد' : 'ملفات محددة'}
          </span>
        </div>

        {/* Batch Action Buttons */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* AI Batch Analysis */}
          <button
            onClick={onBatchAIAnalyze}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer"
            title="تحليل وتلخيص الملفات المحددة عبر الذكاء الاصطناعي"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>تحليل AI</span>
          </button>

          {/* Bulk Rename */}
          {!isTrashView && onBatchRename && (
            <button
              onClick={onBatchRename}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer"
              title="إعادة تسمية جماعية للملفات المحددة بنمط مخصص"
            >
              <FileEdit className="w-3.5 h-3.5 text-blue-200" />
              <span>تسمية جماعية</span>
            </button>
          )}

          {/* Send to Automation */}
          {!isTrashView && onBatchSendToAutomation && (
            <button
              onClick={onBatchSendToAutomation}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer"
              title="إرسال بيانات الملف المختار إلى نقاط نهاية n8n المحددة في .env.example (WhatsApp / Messenger)"
            >
              <Send className="w-3.5 h-3.5 text-emerald-200" />
              <span>إرسال للأتمتة</span>
            </button>
          )}

          {/* Batch Star / Unstar */}
          {!isTrashView && (
            <button
              onClick={() => onBatchStar(anyUnstarred)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
              title={anyUnstarred ? 'تمييز بنجمة لكافة المحددة' : 'إزالة النجمة من كافة المحددة'}
            >
              <Star className={`w-3.5 h-3.5 ${anyUnstarred ? 'text-amber-400' : 'text-amber-400 fill-amber-400'}`} />
              <span>{anyUnstarred ? 'نجمة' : 'إزالة النجمة'}</span>
            </button>
          )}

          {/* Batch Open Web Links */}
          <button
            onClick={onBatchOpenLinks}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
            title="فتح روابط الملفات المحددة في تبويبات جديدة"
          >
            <ExternalLink className="w-3.5 h-3.5 text-blue-400" />
            <span>فتح الروابط</span>
          </button>

          {/* Batch Delete / Trash */}
          <button
            onClick={onBatchDelete}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600/90 hover:bg-rose-600 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
            title={isTrashView ? 'حذف نهائي لكافة الملفات المحددة' : 'نقل الملفات المحددة لسلة المهملات'}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{isTrashView ? 'حذف نهائي' : 'حذف'}</span>
          </button>

          {/* Close Selection */}
          <button
            onClick={onClearSelection}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors ml-1"
            title="إلغاء التحديد (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
