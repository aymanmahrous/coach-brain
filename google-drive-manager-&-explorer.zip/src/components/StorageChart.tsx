import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Cloud, HardDrive, Info } from 'lucide-react';
import { formatBytes } from '../services/driveService';

interface StorageChartProps {
  usageBytes: number;
  limitBytes: number;
  usagePercent: number;
}

export const StorageChart: React.FC<StorageChartProps> = ({
  usageBytes,
  limitBytes,
  usagePercent,
}) => {
  const freeBytes = Math.max(0, limitBytes - usageBytes);

  const data = [
    { name: 'مساحة مستخدمة', value: usageBytes, color: usagePercent > 90 ? '#ef4444' : usagePercent > 75 ? '#f59e0b' : '#3b82f6' },
    { name: 'مساحة متوفرة', value: freeBytes, color: '#e2e8f0' },
  ];

  const chartColor = usagePercent > 90 ? 'text-red-600' : usagePercent > 75 ? 'text-amber-600' : 'text-blue-600';

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const item = payload[0];
      return (
        <div className="bg-slate-900 text-white text-xs px-2.5 py-1.5 rounded-lg shadow-lg border border-slate-700 pointer-events-none z-50">
          <p className="font-bold">{item.name}</p>
          <p className="text-slate-300">{formatBytes(item.value)}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div id="storage-chart-container" className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20 border border-slate-200/80 shadow-xs">
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
          <Cloud className="w-3.5 h-3.5 text-blue-600" />
          <span>مساحة التخزين (Drive)</span>
        </div>
        <span className={`text-xs font-black font-mono px-2 py-0.5 rounded-md bg-white border border-slate-200/80 shadow-2xs ${chartColor}`}>
          {usagePercent}%
        </span>
      </div>

      {/* Donut Chart with Centered Percent */}
      <div className="relative w-full h-32 my-1 flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Tooltip content={<CustomTooltip />} />
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={36}
              outerRadius={52}
              startAngle={90}
              endAngle={-270}
              paddingAngle={2}
              dataKey="value"
              stroke="none"
              animationDuration={800}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>

        {/* Center label inside Donut */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className={`text-sm font-black font-mono leading-none ${chartColor}`}>
            {usagePercent}%
          </span>
          <span className="text-[10px] text-slate-500 font-medium mt-0.5">
            مستخدم
          </span>
        </div>
      </div>

      {/* Details & Legend */}
      <div className="flex flex-col gap-1.5 pt-2 border-t border-slate-200/70 text-[11px]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-slate-600 font-medium">
            <span 
              className="w-2 h-2 rounded-full shrink-0" 
              style={{ backgroundColor: data[0].color }} 
            />
            <span>المستخدم:</span>
          </div>
          <span className="font-bold font-mono text-slate-900">
            {formatBytes(usageBytes)}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-slate-500 font-medium">
            <span className="w-2 h-2 rounded-full bg-slate-300 shrink-0" />
            <span>المتبقي:</span>
          </div>
          <span className="font-semibold font-mono text-slate-600">
            {formatBytes(freeBytes)}
          </span>
        </div>

        <div className="flex items-center justify-between pt-1 border-t border-dashed border-slate-200 text-slate-400">
          <span>السعة الإجمالية:</span>
          <span className="font-medium font-mono text-slate-500">
            {formatBytes(limitBytes)}
          </span>
        </div>
      </div>
    </div>
  );
};
