import React from 'react';
import { ChevronLeft, HardDrive, Folder } from 'lucide-react';
import { BreadcrumbItem } from '../types';

interface BreadcrumbsProps {
  breadcrumbs: BreadcrumbItem[];
  onNavigate: (index: number) => void;
  currentTitle: string;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({
  breadcrumbs,
  onNavigate,
  currentTitle,
}) => {
  return (
    <nav className="flex items-center flex-wrap gap-1.5 text-sm py-2 px-1 text-slate-600">
      <button
        onClick={() => onNavigate(-1)}
        className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg hover:bg-slate-200/70 text-slate-700 font-bold transition-colors"
      >
        <HardDrive className="w-4 h-4 text-blue-600" />
        <span>ملفاتي الرئيسية</span>
      </button>

      {breadcrumbs.map((crumb, idx) => (
        <React.Fragment key={crumb.id}>
          <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-0 ltr:rotate-180" />
          <button
            onClick={() => onNavigate(idx)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg hover:bg-slate-200/70 transition-colors ${
              idx === breadcrumbs.length - 1 ? 'font-bold text-blue-700 bg-blue-50/80' : 'text-slate-600'
            }`}
          >
            <Folder className="w-3.5 h-3.5 text-amber-500" />
            <span className="max-w-[150px] truncate">{crumb.name}</span>
          </button>
        </React.Fragment>
      ))}

      {currentTitle && breadcrumbs.length === 0 && (
        <>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
          <span className="font-bold text-slate-900 px-2 py-1 bg-slate-100 rounded-lg text-xs">
            {currentTitle}
          </span>
        </>
      )}
    </nav>
  );
};
