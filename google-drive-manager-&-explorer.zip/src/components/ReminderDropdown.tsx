import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Clock, 
  Check, 
  Trash2, 
  ExternalLink, 
  AlertCircle, 
  Calendar,
  CheckCircle2,
  Filter,
  Plus,
  Monitor,
  Sparkles,
  Volume2
} from 'lucide-react';
import { FileReminder } from '../types';
import { ReminderService } from '../services/reminderService';
import { NotificationService, WebNotificationPermission } from '../services/notificationService';

interface ReminderDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  reminders: FileReminder[];
  onOpenFile: (fileId: string) => void;
  onToggleComplete: (reminderId: string) => void;
  onDeleteReminder: (reminderId: string) => void;
  onNavigateToRemindersView: () => void;
}

export const ReminderDropdown: React.FC<ReminderDropdownProps> = ({
  isOpen,
  onClose,
  reminders,
  onOpenFile,
  onToggleComplete,
  onDeleteReminder,
  onNavigateToRemindersView,
}) => {
  const [notificationPermission, setNotificationPermission] = useState<WebNotificationPermission>('default');
  const [testNotificationFeedback, setTestNotificationFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setNotificationPermission(NotificationService.getPermission());
    }
  }, [isOpen]);

  const handleRequestPermission = async () => {
    const result = await NotificationService.requestPermission();
    setNotificationPermission(result);
    if (result === 'granted') {
      await NotificationService.sendTestNotification();
      setTestNotificationFeedback('تم إرسال إشعار تجريبي إلى سطح المكتب بنجاح! 🔔');
      setTimeout(() => setTestNotificationFeedback(null), 4000);
    }
  };

  const handleSendTestNotification = async () => {
    const sent = await NotificationService.sendTestNotification();
    if (sent) {
      setTestNotificationFeedback('تم إرسال إشعار تجريبي إلى سطح المكتب! تفقد شاشتك 🔔');
    } else {
      setTestNotificationFeedback('تعذر إرسال الإشعار. تأكد من تفعيل الإشعارات في المتصفح.');
    }
    setTimeout(() => setTestNotificationFeedback(null), 4000);
  };

  if (!isOpen) return null;

  const dueReminders = reminders.filter(r => !r.completed && ReminderService.isDue(r));
  const upcomingReminders = reminders.filter(r => !r.completed && !ReminderService.isDue(r));
  const completedReminders = reminders.filter(r => r.completed);

  return (
    <>
      <div 
        className="fixed inset-0 z-40"
        onClick={onClose}
      />
      <div
        id="reminders-bell-dropdown"
        className="absolute left-0 top-12 z-50 w-80 sm:w-96 bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150 text-right"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-50 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-600 border border-amber-200/60">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-900">تنبيهات وتذكيرات الملفات</h3>
              <span className="text-[10px] text-slate-500">
                {reminders.filter(r => !r.completed).length} تذكير نشط
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              onClose();
              onNavigateToRemindersView();
            }}
            className="text-[11px] font-bold text-blue-600 hover:text-blue-700 bg-blue-50 px-2.5 py-1 rounded-xl transition-colors"
          >
            عرض الكل
          </button>
        </div>

        {/* Web Notifications API Desktop Status Bar */}
        <div className="px-3 py-2 bg-gradient-to-r from-slate-900 to-blue-950 text-white text-[11px] border-b border-slate-800 flex flex-col gap-1.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 min-w-0">
              <Monitor className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="font-bold text-slate-200 text-[11px] truncate">
                إشعارات سطح المكتب (Web Notifications):
              </span>
            </div>

            {notificationPermission === 'granted' ? (
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                مفعلة
              </span>
            ) : notificationPermission === 'denied' ? (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 shrink-0">
                محظورة
              </span>
            ) : (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 shrink-0">
                غير مفعلة
              </span>
            )}
          </div>

          {/* Action Row */}
          <div className="flex items-center justify-between gap-2 pt-0.5">
            <span className="text-[10px] text-slate-400">
              تنبيهات فورية عند اقتراب المهام خارج المتصفح
            </span>

            {notificationPermission === 'granted' ? (
              <button
                onClick={handleSendTestNotification}
                className="text-[10px] font-bold text-cyan-300 hover:text-cyan-200 bg-cyan-950/60 hover:bg-cyan-900/60 px-2 py-0.5 rounded-lg border border-cyan-800 transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                title="إرسال إشعار تجريبي فوري للتأكد من وصوله لسطح المكتب"
              >
                <Sparkles className="w-2.5 h-2.5 text-cyan-400" />
                تجربة إشعار
              </button>
            ) : notificationPermission === 'denied' ? (
              <span className="text-[9px] text-rose-300 bg-rose-950/40 px-2 py-0.5 rounded border border-rose-800/40">
                يرجى السماح بها من المتصفح
              </span>
            ) : (
              <button
                onClick={handleRequestPermission}
                className="text-[10px] font-black text-slate-900 bg-cyan-400 hover:bg-cyan-300 px-2.5 py-0.5 rounded-lg shadow-xs transition-colors flex items-center gap-1 cursor-pointer shrink-0"
              >
                <Bell className="w-2.5 h-2.5" />
                تفعيل الإشعارات
              </button>
            )}
          </div>

          {testNotificationFeedback && (
            <div className="text-[10px] text-emerald-300 bg-emerald-950/70 border border-emerald-800/60 rounded-lg px-2 py-1 mt-0.5 animate-in fade-in duration-200">
              {testNotificationFeedback}
            </div>
          )}
        </div>

        {/* List Body */}
        <div className="max-h-80 overflow-y-auto p-2 flex flex-col gap-1.5">
          {reminders.length === 0 ? (
            <div className="py-8 px-4 text-center text-slate-400">
              <Clock className="w-8 h-8 mx-auto mb-2 text-slate-300 stroke-1" />
              <p className="text-xs font-bold text-slate-600">لا توجد أي تذكيرات مجدولة حالياً</p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                يمكنك إضافة تذكير لأي ملف من خلال قائمة الإجراءات بالملف.
              </p>
            </div>
          ) : (
            <>
              {/* Due / Overdue section */}
              {dueReminders.length > 0 && (
                <div className="mb-1">
                  <div className="flex items-center gap-1.5 px-2 py-1 text-[11px] font-black text-rose-600">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                    <span>مستحقة الآن ({dueReminders.length})</span>
                  </div>
                  {dueReminders.map((item) => (
                    <div
                      key={item.id}
                      className="p-2.5 rounded-2xl bg-rose-50/60 hover:bg-rose-50 border border-rose-200/70 transition-all flex flex-col gap-1.5 mb-1.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <p 
                            onClick={() => {
                              onClose();
                              onOpenFile(item.fileId);
                            }}
                            className="text-xs font-bold text-slate-900 truncate hover:text-blue-600 cursor-pointer"
                            title={item.fileName}
                          >
                            {item.fileName}
                          </p>
                          {item.note && (
                            <p className="text-[11px] text-slate-600 line-clamp-1 mt-0.5">
                              {item.note}
                            </p>
                          )}
                          <span className="text-[10px] text-rose-600 font-bold font-mono">
                            {ReminderService.formatReminderDate(item.remindAt)}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => onToggleComplete(item.id)}
                            className="p-1 text-emerald-600 hover:bg-emerald-100 rounded-lg transition-colors"
                            title="تحديد كمكتمل"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteReminder(item.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-100 rounded-lg transition-colors"
                            title="حذف التذكير"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Upcoming Section */}
              {upcomingReminders.length > 0 && (
                <div>
                  <div className="px-2 py-1 text-[11px] font-bold text-slate-500">
                    <span>قادمة قريباً ({upcomingReminders.length})</span>
                  </div>
                  {upcomingReminders.map((item) => (
                    <div
                      key={item.id}
                      className="p-2.5 rounded-2xl bg-slate-50 hover:bg-blue-50/50 border border-slate-200/80 transition-all flex flex-col gap-1.5 mb-1"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <p 
                            onClick={() => {
                              onClose();
                              onOpenFile(item.fileId);
                            }}
                            className="text-xs font-bold text-slate-800 truncate hover:text-blue-600 cursor-pointer"
                            title={item.fileName}
                          >
                            {item.fileName}
                          </p>
                          {item.note && (
                            <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {item.note}
                            </p>
                          )}
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                              <Clock className="w-3 h-3 text-slate-400" />
                              {ReminderService.formatReminderDate(item.remindAt)}
                            </span>
                            {item.priority === 'high' && (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-100 text-rose-700">
                                هام
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => onToggleComplete(item.id)}
                            className="p-1 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                            title="تحديد كمكتمل"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteReminder(item.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="حذف التذكير"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Completed section */}
              {completedReminders.length > 0 && (
                <div className="mt-1 pt-1 border-t border-slate-100">
                  <div className="px-2 py-1 text-[11px] font-semibold text-slate-400">
                    <span>مكتملة ({completedReminders.length})</span>
                  </div>
                  {completedReminders.map((item) => (
                    <div
                      key={item.id}
                      className="p-2 rounded-xl bg-slate-50/50 opacity-60 hover:opacity-100 transition-opacity flex items-center justify-between gap-2 mb-1"
                    >
                      <div className="min-w-0 flex-1 flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span className="text-xs line-through text-slate-500 truncate">
                          {item.fileName}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => onToggleComplete(item.id)}
                          className="text-[10px] text-blue-600 hover:underline px-1"
                        >
                          تراجع
                        </button>
                        <button
                          onClick={() => onDeleteReminder(item.id)}
                          className="p-1 text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};
