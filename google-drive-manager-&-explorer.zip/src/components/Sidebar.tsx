import React from 'react';
import { 
  Folder, 
  FileText, 
  Table, 
  Presentation, 
  FileCheck, 
  Star, 
  Trash2, 
  HardDrive, 
  Upload, 
  FolderPlus, 
  Sparkles,
  Cloud,
  Image as ImageIcon,
  Receipt,
  BarChart3,
  Rocket,
  FileCheck2,
  GraduationCap,
  Palette,
  FolderGit2,
  RefreshCw,
  Bell,
  X,
  PanelLeftClose,
  PanelLeftOpen,
  ChevronLeft,
  ChevronRight,
  Layers,
  Menu
} from 'lucide-react';
import { DriveAbout, DriveCategoryFilter, AICategoryKey, AICategoryClassification } from '../types';
import { formatBytes } from '../services/driveService';
import { AI_CATEGORIES } from '../services/aiCategorizeService';
import { StorageChart } from './StorageChart';
import { SoundEffects } from '../utils/audioChime';

interface SidebarProps {
  currentCategory: DriveCategoryFilter;
  onSelectCategory: (cat: DriveCategoryFilter) => void;
  aboutInfo: DriveAbout | null;
  onOpenUpload: () => void;
  onOpenNewFolder: () => void;
  onOpenNewDoc: () => void;
  onOpenAI: () => void;
  totalFilesCount: number;
  aiClassifications?: Record<string, AICategoryClassification>;
  isCategorizing?: boolean;
  onTriggerAICategorize?: () => void;
  remindersCount?: number;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
  isDesktopCollapsed?: boolean;
  onToggleDesktopCollapse?: () => void;
  onOpenThemeSettings?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentCategory,
  onSelectCategory,
  aboutInfo,
  onOpenUpload,
  onOpenNewFolder,
  onOpenNewDoc,
  onOpenAI,
  totalFilesCount,
  aiClassifications = {},
  isCategorizing = false,
  onTriggerAICategorize,
  remindersCount = 0,
  isMobileOpen = false,
  onCloseMobile,
  isDesktopCollapsed = false,
  onToggleDesktopCollapse,
  onOpenThemeSettings,
}) => {
  const categories = [
    { id: 'all' as DriveCategoryFilter, label: 'كل ملفاتي', icon: HardDrive, count: totalFilesCount },
    { id: 'folders' as DriveCategoryFilter, label: 'المجلدات', icon: Folder },
    { id: 'docs' as DriveCategoryFilter, label: 'مستندات Docs', icon: FileText, color: 'text-blue-600' },
    { id: 'sheets' as DriveCategoryFilter, label: 'جداول Sheets', icon: Table, color: 'text-emerald-600' },
    { id: 'slides' as DriveCategoryFilter, label: 'عروض Slides', icon: Presentation, color: 'text-amber-600' },
    { id: 'pdf' as DriveCategoryFilter, label: 'ملفات PDF', icon: FileCheck, color: 'text-rose-600' },
    { id: 'images' as DriveCategoryFilter, label: 'الصور والوسائط', icon: ImageIcon, color: 'text-purple-600' },
    { id: 'starred' as DriveCategoryFilter, label: 'المميزة بنجمة', icon: Star, color: 'text-amber-500' },
    { id: 'reminders' as DriveCategoryFilter, label: 'المجدولة والتذكيرات', icon: Bell, color: 'text-amber-600', count: remindersCount },
    { id: 'trash' as DriveCategoryFilter, label: 'سلة المهملات', icon: Trash2, color: 'text-slate-500' },
  ];

  // Calculate AI category counts
  const aiCounts: Record<AICategoryKey, number> = {
    invoices: 0,
    reports: 0,
    projects: 0,
    contracts: 0,
    education: 0,
    media: 0,
    general: 0,
  };

  Object.values(aiClassifications).forEach((item: AICategoryClassification) => {
    if (item && item.category && aiCounts[item.category] !== undefined) {
      aiCounts[item.category] += 1;
    }
  });

  const aiFilterList: Array<{
    id: DriveCategoryFilter;
    key: AICategoryKey;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    color: string;
    bgColor: string;
  }> = [
    { id: 'ai_invoices', key: 'invoices', label: 'فواتير وسندات', icon: Receipt, color: 'text-emerald-600', bgColor: 'bg-emerald-50 hover:bg-emerald-100/70' },
    { id: 'ai_reports', key: 'reports', label: 'تقارير وتحليلات', icon: BarChart3, color: 'text-blue-600', bgColor: 'bg-blue-50 hover:bg-blue-100/70' },
    { id: 'ai_projects', key: 'projects', label: 'مشاريع وخطط', icon: Rocket, color: 'text-amber-600', bgColor: 'bg-amber-50 hover:bg-amber-100/70' },
    { id: 'ai_contracts', key: 'contracts', label: 'عقود ومستندات', icon: FileCheck2, color: 'text-purple-600', bgColor: 'bg-purple-50 hover:bg-purple-100/70' },
    { id: 'ai_education', key: 'education', label: 'تعليم ومذكرات', icon: GraduationCap, color: 'text-cyan-600', bgColor: 'bg-cyan-50 hover:bg-cyan-100/70' },
    { id: 'ai_media', key: 'media', label: 'تصاميم ووسائط', icon: Palette, color: 'text-rose-600', bgColor: 'bg-rose-50 hover:bg-rose-100/70' },
    { id: 'ai_general', key: 'general', label: 'عام ومتنوع', icon: FolderGit2, color: 'text-slate-600', bgColor: 'bg-slate-100 hover:bg-slate-200/70' },
  ];

  // Calculate storage usage percentage
  const usageBytes = Number(aboutInfo?.storageQuota?.usage || '4500000000');
  const limitBytes = Number(aboutInfo?.storageQuota?.limit || '16106127360');
  const usagePercent = Math.min(100, Math.round((usageBytes / (limitBytes || 1)) * 100));

  const handleSelect = (cat: DriveCategoryFilter) => {
    SoundEffects.playPop();
    onSelectCategory(cat);
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  // Content shared between Desktop & Mobile
  const renderSidebarContent = (isCompact = false) => (
    <div className="flex flex-col gap-4 flex-1">
      {/* Primary Action Buttons */}
      <div className="flex flex-col gap-2 shrink-0">
        <button
          id="sidebar-upload-btn"
          onClick={() => {
            SoundEffects.playPop();
            onOpenUpload();
            if (onCloseMobile) onCloseMobile();
          }}
          className={`flex items-center justify-center gap-2 w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-sm rounded-xl shadow-md shadow-blue-500/20 transition-all cursor-pointer ${
            isCompact ? 'px-2' : ''
          }`}
          title="رفع ملف جديد"
        >
          <Upload className="w-4 h-4 shrink-0" />
          {!isCompact && <span>رفع ملف جديد</span>}
        </button>

        {!isCompact && (
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                SoundEffects.playPop();
                onOpenNewFolder();
                if (onCloseMobile) onCloseMobile();
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200/60 transition-colors cursor-pointer"
            >
              <FolderPlus className="w-3.5 h-3.5 text-amber-500 shrink-0" />
              <span>مجلد جديد</span>
            </button>
            <button
              onClick={() => {
                SoundEffects.playPop();
                onOpenNewDoc();
                if (onCloseMobile) onCloseMobile();
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold rounded-xl border border-indigo-200/60 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span>مستند ذكي AI</span>
            </button>
          </div>
        )}
      </div>

      {/* Navigation Links - Standard Categories */}
      <nav className="flex flex-col gap-1">
        {!isCompact && (
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-3 py-1">
            المكتبة والملفات
          </span>
        )}
        {categories.map((item) => {
          const Icon = item.icon;
          const isActive = currentCategory === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleSelect(item.id)}
              title={isCompact ? item.label : undefined}
              className={`flex items-center ${isCompact ? 'justify-center px-2 py-2.5' : 'justify-between px-3.5 py-2'} rounded-xl text-sm font-medium transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-50 text-blue-700 font-bold border border-blue-200/60 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon className={`w-4 h-4 shrink-0 ${item.color || (isActive ? 'text-blue-600' : 'text-slate-500')}`} />
                {!isCompact && <span>{item.label}</span>}
              </div>
              {!isCompact && item.count !== undefined && item.count > 0 && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 font-mono">
                  {item.count}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* AI Smart Classifications Section */}
      <div className={`flex flex-col gap-1 pt-2 border-t border-slate-200/80 ${isCompact ? 'items-center' : ''}`}>
        {!isCompact ? (
          <div className="flex items-center justify-between px-3 py-1">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-900">
                التصنيف الذكي بالـ AI
              </span>
            </div>
            {onTriggerAICategorize && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  SoundEffects.playPop();
                  onTriggerAICategorize();
                }}
                disabled={isCategorizing}
                title="إعادة فحص وتصنيف كل الملفات بالذكاء الاصطناعي"
                className="p-1 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3 h-3 ${isCategorizing ? 'animate-spin text-indigo-700' : ''}`} />
              </button>
            )}
          </div>
        ) : (
          <div className="py-1" title="تصنيفات الذكاء الاصطناعي">
            <Sparkles className="w-4 h-4 text-indigo-600" />
          </div>
        )}

        {aiFilterList.map((item) => {
          const Icon = item.icon;
          const isActive = currentCategory === item.id;
          const count = aiCounts[item.key] || 0;

          return (
            <button
              key={item.id}
              onClick={() => handleSelect(item.id)}
              title={isCompact ? `${item.label} (${count})` : undefined}
              className={`flex items-center ${isCompact ? 'justify-center px-2 py-2' : 'justify-between px-3 py-1.5'} rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-indigo-600 text-white font-bold shadow-xs'
                  : 'text-slate-700 hover:bg-slate-100/90 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2">
                <div className={`w-5 h-5 rounded-lg flex items-center justify-center shrink-0 ${isActive ? 'bg-white/20 text-white' : `${item.bgColor} ${item.color}`}`}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                {!isCompact && <span>{item.label}</span>}
              </div>
              
              {!isCompact && (
                <span className={`text-[11px] font-mono px-2 py-0.5 rounded-full ${
                  isActive 
                    ? 'bg-white/25 text-white font-bold' 
                    : count > 0 
                      ? 'bg-slate-100 text-slate-600' 
                      : 'text-slate-400'
                }`}>
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Theme Settings & Storage Quota */}
      <div className="mt-auto pt-3 border-t border-slate-200/80 space-y-3">
        {onOpenThemeSettings && (
          <button
            onClick={() => {
              SoundEffects.playPop();
              onOpenThemeSettings();
            }}
            title={isCompact ? 'تخصيص ألوان التمييز والمظهر' : undefined}
            className={`w-full flex items-center ${
              isCompact ? 'justify-center p-2' : 'gap-2.5 px-3 py-2'
            } rounded-xl text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-indigo-50/80 hover:text-indigo-700 border border-slate-200/70 hover:border-indigo-200 transition-all cursor-pointer group shadow-2xs`}
          >
            <div className="w-6 h-6 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-indigo-600 group-hover:scale-110 transition-transform shadow-2xs">
              <Palette className="w-3.5 h-3.5" />
            </div>
            {!isCompact && (
              <div className="text-right flex-1">
                <span className="font-bold block text-slate-900 group-hover:text-indigo-900">
                  تخصيص المظهر والألوان
                </span>
                <span className="text-[10px] text-slate-400 block font-normal">
                  تغيير لون التمييز والحواف
                </span>
              </div>
            )}
          </button>
        )}

        {!isCompact && (
          <StorageChart
            usageBytes={usageBytes}
            limitBytes={limitBytes}
            usagePercent={usagePercent}
          />
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* 1. Mobile Drawer Overlay (Shown only on small screens when isMobileOpen is true) */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden overflow-hidden" dir="rtl">
          {/* Backdrop */}
          <div 
            onClick={onCloseMobile}
            className="absolute inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity duration-300 animate-in fade-in" 
          />

          {/* Slide-out Drawer Panel from right in RTL */}
          <div className="absolute inset-y-0 right-0 max-w-full flex">
            <aside className="w-80 max-w-[85vw] bg-white shadow-2xl flex flex-col border-l border-slate-200 p-4 overflow-y-auto animate-in slide-in-from-right duration-300">
              {/* Drawer Header with Title & Close Button */}
              <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-200/60">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900">قائمة التنقل</h3>
                    <p className="text-[11px] text-slate-400">التصنيفات والمجلدات</p>
                  </div>
                </div>

                <button
                  onClick={onCloseMobile}
                  className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                  title="إغلاق القائمة"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {renderSidebarContent(false)}
            </aside>
          </div>
        </div>
      )}

      {/* 2. Desktop Permanent Sidebar (Hidden on small screens lg:hidden to save maximum space for files) */}
      <aside 
        className={`hidden lg:flex flex-col gap-4 p-4 bg-white/70 backdrop-blur-md border-l border-slate-200/80 shrink-0 overflow-y-auto max-h-[calc(100vh-65px)] transition-all duration-300 ${
          isDesktopCollapsed ? 'w-20' : 'w-64'
        }`}
      >
        {/* Desktop Collapse / Expand Header Button */}
        {onToggleDesktopCollapse && (
          <div className={`flex items-center ${isDesktopCollapsed ? 'justify-center' : 'justify-between'} pb-1 border-b border-slate-100 text-slate-400`}>
            {!isDesktopCollapsed && (
              <span className="text-[11px] font-bold text-slate-400">التنقل</span>
            )}
            <button
              onClick={onToggleDesktopCollapse}
              className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title={isDesktopCollapsed ? 'توسيع القائمة الجانبية' : 'طي القائمة الجانبية'}
            >
              {isDesktopCollapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
            </button>
          </div>
        )}

        {renderSidebarContent(isDesktopCollapsed)}
      </aside>
    </>
  );
};
