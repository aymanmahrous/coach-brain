import React, { useState, useMemo } from 'react';
import { 
  X, 
  FileEdit, 
  Search, 
  Replace, 
  ListOrdered, 
  PlusCircle, 
  Sparkles, 
  ArrowLeft, 
  Check, 
  AlertCircle, 
  Calendar,
  CheckCircle2,
  RefreshCw,
  SlidersHorizontal,
  Info
} from 'lucide-react';
import { DriveFile } from '../types';
import { SoundEffects } from '../utils/audioChime';

export type RenameMode = 'replace' | 'prefix_suffix' | 'numbering' | 'cleanup';

interface BulkRenameModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedFiles: DriveFile[];
  onApplyRename: (renames: { fileId: string; newName: string }[]) => Promise<void>;
}

// Split filename and extension safely
function splitFileName(fullName: string, isFolder: boolean) {
  if (isFolder) return { base: fullName, ext: '' };
  const lastDot = fullName.lastIndexOf('.');
  if (lastDot <= 0) return { base: fullName, ext: '' };
  return {
    base: fullName.substring(0, lastDot),
    ext: fullName.substring(lastDot), // includes the dot e.g. ".pdf"
  };
}

export const BulkRenameModal: React.FC<BulkRenameModalProps> = ({
  isOpen,
  onClose,
  selectedFiles,
  onApplyRename,
}) => {
  const [mode, setMode] = useState<RenameMode>('prefix_suffix');

  // Prefix & Suffix State
  const [prefix, setPrefix] = useState<string>('');
  const [suffix, setSuffix] = useState<string>('');

  // Find & Replace State
  const [findText, setFindText] = useState<string>('');
  const [replaceText, setReplaceText] = useState<string>('');
  const [matchCase, setMatchCase] = useState<boolean>(false);
  const [useRegex, setUseRegex] = useState<boolean>(false);

  // Numbering State
  const [numberingBaseName, setNumberingBaseName] = useState<string>('');
  const [keepOriginalName, setKeepOriginalName] = useState<boolean>(true);
  const [numberPosition, setNumberPosition] = useState<'after' | 'before'>('after');
  const [startNumber, setStartNumber] = useState<number>(1);
  const [padDigits, setPadDigits] = useState<number>(2); // 01, 02...
  const [separator, setSeparator] = useState<string>(' - ');

  // Clean-up & Formatting State
  const [caseFormat, setCaseFormat] = useState<'none' | 'lowercase' | 'uppercase' | 'capitalize'>('none');
  const [spacesHandling, setSpacesHandling] = useState<'none' | 'to_underscore' | 'to_hyphen' | 'trim_extra'>('none');
  const [addDateStamp, setAddDateStamp] = useState<boolean>(false);
  const [dateFormat, setDateFormat] = useState<'YYYY-MM-DD' | 'YYYYMMDD'>('YYYY-MM-DD');

  // General Options
  const [preserveExtension, setPreserveExtension] = useState<boolean>(true);

  // Progress & Execution State
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progress, setProgress] = useState<{ current: number; total: number }>({ current: 0, total: 0 });
  const [error, setError] = useState<string | null>(null);

  // Compute New File Names in Real-Time
  const computedRenames = useMemo(() => {
    return selectedFiles.map((file, index) => {
      const isFolder = file.mimeType === 'application/vnd.google-apps.folder';
      const { base: rawBase, ext } = preserveExtension
        ? splitFileName(file.name, isFolder)
        : { base: file.name, ext: '' };

      let newBase = rawBase;

      if (mode === 'prefix_suffix') {
        newBase = `${prefix}${newBase}${suffix}`;
      } else if (mode === 'replace') {
        if (findText) {
          try {
            if (useRegex) {
              const regex = new RegExp(findText, matchCase ? 'g' : 'gi');
              newBase = newBase.replace(regex, replaceText);
            } else {
              if (matchCase) {
                newBase = newBase.replaceAll(findText, replaceText);
              } else {
                // Case insensitive replace all
                const escaped = findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                const regex = new RegExp(escaped, 'gi');
                newBase = newBase.replace(regex, replaceText);
              }
            }
          } catch {
            // Invalid regex
          }
        }
      } else if (mode === 'numbering') {
        const numVal = startNumber + index;
        const formattedNum = String(numVal).padStart(padDigits, '0');
        const customName = keepOriginalName ? rawBase : numberingBaseName.trim() || 'ملف';

        if (numberPosition === 'before') {
          newBase = `${formattedNum}${separator}${customName}`;
        } else {
          newBase = `${customName}${separator}${formattedNum}`;
        }
      } else if (mode === 'cleanup') {
        // Casing
        if (caseFormat === 'lowercase') {
          newBase = newBase.toLowerCase();
        } else if (caseFormat === 'uppercase') {
          newBase = newBase.toUpperCase();
        } else if (caseFormat === 'capitalize') {
          newBase = newBase.replace(/\b\w/g, (c) => c.toUpperCase());
        }

        // Spaces
        if (spacesHandling === 'to_underscore') {
          newBase = newBase.replace(/[\s-]+/g, '_');
        } else if (spacesHandling === 'to_hyphen') {
          newBase = newBase.replace(/[\s_]+/g, '-');
        } else if (spacesHandling === 'trim_extra') {
          newBase = newBase.replace(/\s+/g, ' ').trim();
        }

        // Date stamp
        if (addDateStamp) {
          const now = new Date();
          const y = now.getFullYear();
          const m = String(now.getMonth() + 1).padStart(2, '0');
          const d = String(now.getDate()).padStart(2, '0');
          const dateStr = dateFormat === 'YYYY-MM-DD' ? `${y}-${m}-${d}` : `${y}${m}${d}`;
          newBase = `${newBase}_${dateStr}`;
        }
      }

      // Reattach extension
      const finalName = `${newBase.trim()}${ext}`;

      return {
        file,
        fileId: file.id,
        originalName: file.name,
        newName: finalName || file.name,
        isChanged: finalName !== file.name && finalName.trim().length > 0,
        isValid: finalName.trim().length > 0,
      };
    });
  }, [
    selectedFiles,
    mode,
    prefix,
    suffix,
    findText,
    replaceText,
    matchCase,
    useRegex,
    numberingBaseName,
    keepOriginalName,
    numberPosition,
    startNumber,
    padDigits,
    separator,
    caseFormat,
    spacesHandling,
    addDateStamp,
    dateFormat,
    preserveExtension,
  ]);

  const changedCount = computedRenames.filter((r) => r.isChanged && r.isValid).length;

  const handleApply = async () => {
    const validRenames = computedRenames
      .filter((r) => r.isChanged && r.isValid)
      .map((r) => ({ fileId: r.fileId, newName: r.newName }));

    if (validRenames.length === 0) return;

    setIsProcessing(true);
    setError(null);
    setProgress({ current: 0, total: validRenames.length });
    SoundEffects.playPop();

    try {
      await onApplyRename(validRenames);
      SoundEffects.playSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء تطبيق إعادة التسمية الجماعية.');
      setIsProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4" dir="rtl">
      <div className="w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-700 via-indigo-700 to-indigo-800 text-white flex items-center justify-between shrink-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-blue-200 shadow-inner">
              <FileEdit className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
                  إعادة التسمية الجماعية للملفات
                </h2>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-blue-500/30 border border-blue-400/30 text-white">
                  {selectedFiles.length} عناصر
                </span>
              </div>
              <p className="text-xs text-blue-100 mt-0.5">
                تعديل أسماء الملفات المختارة دفعة واحدة بأنماط وقواعد مرنة مع معاينة فورية
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            disabled={isProcessing}
            className="p-2 text-blue-100 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer disabled:opacity-50"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Navigation Tabs */}
        <div className="flex items-center gap-1.5 p-2 sm:px-5 bg-slate-50 border-b border-slate-200 overflow-x-auto no-scrollbar shrink-0">
          <button
            onClick={() => setMode('prefix_suffix')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer shrink-0 ${
              mode === 'prefix_suffix'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
            }`}
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>إضافة بادئة ولاحقة</span>
          </button>

          <button
            onClick={() => setMode('replace')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer shrink-0 ${
              mode === 'replace'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
            }`}
          >
            <Replace className="w-3.5 h-3.5" />
            <span>بحث واستبدال النص</span>
          </button>

          <button
            onClick={() => setMode('numbering')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer shrink-0 ${
              mode === 'numbering'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
            }`}
          >
            <ListOrdered className="w-3.5 h-3.5" />
            <span>ترقيم تسلسلي</span>
          </button>

          <button
            onClick={() => setMode('cleanup')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer shrink-0 ${
              mode === 'cleanup'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>تنسيق وإضافة التاريخ</span>
          </button>
        </div>

        {/* Controls Form & Configuration Body */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-white shrink-0">

          {/* Mode 1: Prefix & Suffix */}
          {mode === 'prefix_suffix' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  البادئة (تضاف في أول الاسم):
                </label>
                <input
                  type="text"
                  value={prefix}
                  onChange={(e) => setPrefix(e.target.value)}
                  placeholder="مثال: 2026_ أو [معتمد]_"
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  اللاحقة (تضاف قبل الامتداد):
                </label>
                <input
                  type="text"
                  value={suffix}
                  onChange={(e) => setSuffix(e.target.value)}
                  placeholder="مثال: _نسخة_نهائية أو _v2"
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none transition-all"
                />
              </div>
            </div>
          )}

          {/* Mode 2: Find & Replace */}
          {mode === 'replace' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    البحث عن نص:
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={findText}
                      onChange={(e) => setFindText(e.target.value)}
                      placeholder="النص المراد استبداله..."
                      className="w-full pl-9 pr-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none transition-all"
                    />
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    استبدال بـ:
                  </label>
                  <input
                    type="text"
                    value={replaceText}
                    onChange={(e) => setReplaceText(e.target.value)}
                    placeholder="النص البديل الجديد (اتركه فارغاً للحذف)..."
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none transition-all"
                  />
                </div>
              </div>

              <div className="flex items-center gap-4 text-xs text-slate-600 pt-1">
                <label className="flex items-center gap-1.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={matchCase}
                    onChange={(e) => setMatchCase(e.target.checked)}
                    className="w-3.5 h-3.5 rounded text-blue-600 focus:ring-0"
                  />
                  <span>مطابقة حالة الأحرف (Case sensitive)</span>
                </label>

                <label className="flex items-center gap-1.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={useRegex}
                    onChange={(e) => setUseRegex(e.target.checked)}
                    className="w-3.5 h-3.5 rounded text-blue-600 focus:ring-0"
                  />
                  <span>استخدام التعابير النمطية (RegEx)</span>
                </label>
              </div>
            </div>
          )}

          {/* Mode 3: Sequential Numbering */}
          {mode === 'numbering' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-1">
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    الاسم الأساسي:
                  </label>
                  <input
                    type="text"
                    value={numberingBaseName}
                    disabled={keepOriginalName}
                    onChange={(e) => setNumberingBaseName(e.target.value)}
                    placeholder="مثال: فاتورة أو تقرير"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none disabled:opacity-50 disabled:bg-slate-100 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    البداية من الرقم:
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={startNumber}
                    onChange={(e) => setStartNumber(parseInt(e.target.value) || 1)}
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    تنسيق الأصفار (الخانات):
                  </label>
                  <select
                    value={padDigits}
                    onChange={(e) => setPadDigits(parseInt(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none cursor-pointer"
                  >
                    <option value={1}>1, 2, 3... (خانة واحدة)</option>
                    <option value={2}>01, 02, 03... (خانتان)</option>
                    <option value={3}>001, 002, 003... (3 خانات)</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600 pt-1">
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-1.5 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={keepOriginalName}
                      onChange={(e) => setKeepOriginalName(e.target.checked)}
                      className="w-3.5 h-3.5 rounded text-blue-600"
                    />
                    <span>الاحتفاظ بالاسم الأصلي وإضافة الرقم</span>
                  </label>

                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-700">موضع الرقم:</span>
                    <select
                      value={numberPosition}
                      onChange={(e) => setNumberPosition(e.target.value as any)}
                      className="px-2.5 py-1 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none cursor-pointer"
                    >
                      <option value="after">في النهاية (اسم - 01)</option>
                      <option value="before">في البداية (01 - اسم)</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-700">الفاصل:</span>
                  <select
                    value={separator}
                    onChange={(e) => setSeparator(e.target.value)}
                    className="px-2.5 py-1 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none cursor-pointer"
                  >
                    <option value=" - ">شرطة ومسافة ( - )</option>
                    <option value="_">شرطة سفلية (_)</option>
                    <option value=" ">مسافة واحدة ( )</option>
                    <option value=".">نقطة (.)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Mode 4: Cleanup & Formatting */}
          {mode === 'cleanup' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  حالة الأحرف الإنجليزية:
                </label>
                <select
                  value={caseFormat}
                  onChange={(e) => setCaseFormat(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none cursor-pointer"
                >
                  <option value="none">بدون تغيير</option>
                  <option value="lowercase">أحرف صغيرة (lowercase)</option>
                  <option value="uppercase">أحرف كبيرة (UPPERCASE)</option>
                  <option value="capitalize">بداية الكلمات كبيرة (Title Case)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  المسافات والرموز:
                </label>
                <select
                  value={spacesHandling}
                  onChange={(e) => setSpacesHandling(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none cursor-pointer"
                >
                  <option value="none">بدون تغيير</option>
                  <option value="to_underscore">استبدال المسافات بـ (_) شرطة سفلية</option>
                  <option value="to_hyphen">استبدال المسافات بـ (-) شرطة</option>
                  <option value="trim_extra">إزالة المسافات الزائدة والمزدوجة</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  إلحاق تاريخ اليوم:
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-1.5 cursor-pointer select-none text-xs text-slate-700">
                    <input
                      type="checkbox"
                      checked={addDateStamp}
                      onChange={(e) => setAddDateStamp(e.target.checked)}
                      className="w-3.5 h-3.5 rounded text-blue-600"
                    />
                    <span>إضافة التاريخ</span>
                  </label>
                  {addDateStamp && (
                    <select
                      value={dateFormat}
                      onChange={(e) => setDateFormat(e.target.value as any)}
                      className="px-2 py-1 text-[11px] bg-slate-50 border border-slate-200 rounded-lg outline-none cursor-pointer"
                    >
                      <option value="YYYY-MM-DD">2026-09-01</option>
                      <option value="YYYYMMDD">20260901</option>
                    </select>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Extension Preservation Checkbox */}
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <label className="flex items-center gap-2 cursor-pointer select-none font-medium text-slate-700">
              <input
                type="checkbox"
                checked={preserveExtension}
                onChange={(e) => setPreserveExtension(e.target.checked)}
                className="w-3.5 h-3.5 rounded text-blue-600"
              />
              <span>الحفاظ تلقائياً على امتداد الملفات الأصلية (مثل .pdf, .docx, .png)</span>
            </label>

            <div className="flex items-center gap-1.5 text-slate-600 font-bold">
              <span>التغييرات:</span>
              <span className={`px-2 py-0.5 rounded-full text-xs ${changedCount > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>
                {changedCount} من {selectedFiles.length} سيتغير
              </span>
            </div>
          </div>
        </div>

        {/* Live Preview Table */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 bg-slate-50/70">
          <div className="flex items-center justify-between mb-2.5">
            <h3 className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5">
              <span>معاينة فورية قبل الحفظ:</span>
            </h3>
            <span className="text-[11px] text-slate-400">
              تأكد من الأسماء الجديدة قبل اعتماد التعديل
            </span>
          </div>

          <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-2xs">
            <div className="max-h-64 overflow-y-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-100/90 text-slate-600 border-b border-slate-200 sticky top-0 font-bold z-10">
                  <tr>
                    <th className="py-2.5 px-3.5 w-12 text-center">#</th>
                    <th className="py-2.5 px-3.5">الاسم الحالي</th>
                    <th className="py-2.5 px-2 w-8 text-center"></th>
                    <th className="py-2.5 px-3.5">الاسم الجديد المقترح</th>
                    <th className="py-2.5 px-3.5 w-24 text-center">الحالة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {computedRenames.map((item, idx) => (
                    <tr 
                      key={item.fileId} 
                      className={`transition-colors ${item.isChanged ? 'bg-blue-50/40 hover:bg-blue-50/70' : 'hover:bg-slate-50'}`}
                    >
                      <td className="py-2 px-3.5 text-center text-slate-400 font-mono text-[11px]">
                        {idx + 1}
                      </td>

                      <td className="py-2 px-3.5 font-medium text-slate-700 truncate max-w-[200px]" title={item.originalName}>
                        {item.originalName}
                      </td>

                      <td className="py-2 px-2 text-center text-slate-400">
                        <ArrowLeft className="w-3.5 h-3.5 mx-auto" />
                      </td>

                      <td className="py-2 px-3.5 font-bold truncate max-w-[240px]" title={item.newName}>
                        <span className={item.isChanged ? 'text-blue-700' : 'text-slate-500'}>
                          {item.newName}
                        </span>
                      </td>

                      <td className="py-2 px-3.5 text-center">
                        {item.isChanged ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <Check className="w-3 h-3" />
                            <span>سيتغير</span>
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400">
                            بدون تغيير
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mx-4 sm:mx-5 mt-2 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2 shrink-0">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span className="font-bold">{error}</span>
          </div>
        )}

        {/* Footer Actions */}
        <div className="p-4 sm:px-5 bg-white border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500">
            {changedCount > 0 ? (
              <span>سيتم تطبيق التعديل على <strong>{changedCount}</strong> ملفاً</span>
            ) : (
              <span>لم يتم إجراء أي تعديل على الأسماء الحالية</span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              disabled={isProcessing}
              className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors cursor-pointer disabled:opacity-50"
            >
              إلغاء
            </button>

            <button
              onClick={handleApply}
              disabled={changedCount === 0 || isProcessing}
              className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:bg-slate-300 rounded-xl shadow-sm transition-all cursor-pointer"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>جاري إعادة التسمية...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>تطبيق على {changedCount} ملفات</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
