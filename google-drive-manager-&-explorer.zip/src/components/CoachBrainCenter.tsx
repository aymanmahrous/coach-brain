import React, { useState, useEffect } from 'react';
import {
  Brain,
  Sparkles,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Send,
  Calendar,
  Layers,
  ArrowRight,
  ShieldCheck,
  Zap,
  Activity,
  Sliders,
  Award,
  Clock,
  Compass,
  FileText,
  RefreshCw,
  Search,
  ExternalLink,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { SoundEffects } from '../utils/audioChime';

export interface CoachBrainCenterProps {
  onTransferIdeaToFactory: (idea: string, platform?: string) => void;
  onBatchSchedulePosts?: (newPosts: any[]) => void;
  onShowNotification: (msg: string) => void;
  onOpenSettingsModal?: () => void;
  onOpenN8nModal?: () => void;
  waConnected?: boolean;
  msgConnected?: boolean;
}

export const CoachBrainCenter: React.FC<CoachBrainCenterProps> = ({
  onTransferIdeaToFactory,
  onBatchSchedulePosts,
  onShowNotification,
  onOpenSettingsModal,
  onOpenN8nModal,
  waConnected = false,
  msgConnected = false
}) => {
  // Navigation inside Coach Brain
  const [activeSubSection, setActiveSubSection] = useState<'prompt' | 'audit' | 'methods' | 'schedule' | 'sync' | 'ask'>('prompt');

  // Sub-states: 1. Image & Prompt Generator
  const [imageTopic, setImageTopic] = useState<'freestyle_kids' | 'phobia_relax_fix' | 'freestyle_technique'>('freestyle_kids');
  const [promptData, setPromptData] = useState<any>(null);
  const [loadingPrompt, setLoadingPrompt] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Sub-states: 2. System Audit
  const [auditData, setAuditData] = useState<any>(null);
  const [loadingAudit, setLoadingAudit] = useState(false);

  // Sub-states: 3. Swimming Masterclass Methods
  const [methodTopic, setMethodTopic] = useState<'kids_fearless' | 'phobia_relax_fix' | 'freestyle_streamline'>('kids_fearless');
  const [methodData, setMethodData] = useState<any>(null);
  const [loadingMethod, setLoadingMethod] = useState(false);

  // Sub-states: 4. Schedule 10-30 Days
  const [selectedDays, setSelectedDays] = useState<number>(10);
  const [scheduleData, setScheduleData] = useState<any>(null);
  const [loadingSchedule, setLoadingSchedule] = useState(false);
  const [schedulePushed, setSchedulePushed] = useState(false);

  // Sub-states: 5. Sync Projects (New Coach vs Command)
  const [syncData, setSyncData] = useState<any>(null);
  const [loadingSync, setLoadingSync] = useState(false);
  const [syncActivated, setSyncActivated] = useState(true);

  // Sub-states: 6. Ask Coach Brian
  const [userQuestion, setUserQuestion] = useState('');
  const [askReply, setAskReply] = useState<string | null>(null);
  const [loadingAsk, setLoadingAsk] = useState(false);

  // Load initial prompt and audit
  useEffect(() => {
    fetchPromptData('freestyle_kids');
    fetchAuditData();
    fetchMethodData('kids_fearless');
    fetchSchedulePlan(10);
    fetchSyncData();
  }, []);

  // Helper copy function
  const copyText = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    SoundEffects.playPop();
    onShowNotification(`تم نسخ ${fieldName} إلى الحافظة بنجاح!`);
    setTimeout(() => setCopiedField(null), 2500);
  };

  // API Call: Fetch Prompt
  const fetchPromptData = async (topic: string) => {
    setLoadingPrompt(true);
    try {
      const res = await fetch('/api/coach-brain/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'prompt_image', subType: topic })
      });
      const data = await res.json();
      if (data.success) {
        setPromptData(data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingPrompt(false);
    }
  };

  // API Call: Audit
  const fetchAuditData = async () => {
    setLoadingAudit(true);
    try {
      const res = await fetch('/api/coach-brain/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'audit_system' })
      });
      const data = await res.json();
      if (data.success) {
        setAuditData(data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAudit(false);
    }
  };

  // API Call: Swim Methods
  const fetchMethodData = async (methodKey: string) => {
    setLoadingMethod(true);
    try {
      const res = await fetch('/api/coach-brain/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'swim_method', subType: methodKey })
      });
      const data = await res.json();
      if (data.success) {
        setMethodData(data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingMethod(false);
    }
  };

  // API Call: Schedule Plan
  const fetchSchedulePlan = async (days: number) => {
    setLoadingSchedule(true);
    setSchedulePushed(false);
    try {
      const res = await fetch('/api/coach-brain/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'schedule_plan', daysCount: days })
      });
      const data = await res.json();
      if (data.success) {
        setScheduleData(data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingSchedule(false);
    }
  };

  // API Call: Sync Projects
  const fetchSyncData = async () => {
    setLoadingSync(true);
    try {
      const res = await fetch('/api/coach-brain/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'sync_projects' })
      });
      const data = await res.json();
      if (data.success) {
        setSyncData(data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingSync(false);
    }
  };

  // API Call: Ask Coach Brian
  const handleAskQuestion = async (qText?: string) => {
    const query = qText !== undefined ? qText : userQuestion;
    if (!query.trim()) return;
    setLoadingAsk(true);
    setAskReply(null);
    try {
      const res = await fetch('/api/coach-brain/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'ask_question', question: query })
      });
      const data = await res.json();
      if (data.success && data.data) {
        setAskReply(data.data.answer);
        SoundEffects.playSuccess();
      }
    } catch (err: any) {
      setAskReply('تعذر الاتصال بكوتش براين حالياً. يرجى إعادة المحاولة.');
    } finally {
      setLoadingAsk(false);
    }
  };

  // Push batch to factory
  const handlePushAllToFactory = () => {
    if (!scheduleData?.items || !onBatchSchedulePosts) {
      onShowNotification('تم نسخ الخطة بنجاح');
      return;
    }
    const formatted = scheduleData.items.map((item: any) => ({
      id: `sch-${item.id}-${Date.now()}`,
      title: item.title,
      platform: item.platform || 'Instagram',
      aspectRatio: item.format.includes('9:16') ? '9:16' : item.format.includes('4:5') ? '4:5' : '1:1',
      templateType: item.templateType,
      scheduledTime: item.scheduledTime,
      hookCaption: item.hookCaption,
      brief: `محتوى تلقائي مصمم عبر كوتش براين لتغطية ${item.category} في ${item.branch}.`,
      status: 'scheduled',
      showPoster: false,
      branch: item.branch
    }));

    onBatchSchedulePosts(formatted);
    setSchedulePushed(true);
    SoundEffects.playSuccess();
    onShowNotification(`🚀 تم ترحيل ${formatted.length} منشوراً مجدولاً بالكامل إلى مصنع المحتوى بنجاح!`);
  };

  return (
    <div className="space-y-6">
      {/* Top Brain Header & Brand Info */}
      <div className="bg-gradient-to-r from-[#07131e] via-[#091b2e] to-[#07131e] border border-cyan-500/30 rounded-2xl p-5 shadow-2xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-600 to-emerald-500 p-0.5 shadow-lg shadow-cyan-950/80 shrink-0 flex items-center justify-center">
              <div className="w-full h-full bg-[#05111d] rounded-[14px] flex items-center justify-center">
                <Brain className="w-6 h-6 text-cyan-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-bold text-white tracking-wide">
                  كوتش براين — العقل الاستراتيجي والمدرب التنفيذي
                </h2>
                <span className="text-[11px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  جاهز وفوري
                </span>
                <span className="text-[11px] bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded-full font-medium">
                  Swim Fluent UAE • أبوظبي
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                كل ما تحتاجه لإدارة الأكاديمية وصناعة المحتوى بنقرة واحدة بدون حشو أو إطالة: برومبتات جاهزة، فحص فوري للتطبيق، أساليب السباحة الأكاديمية، جدولة 10-30 يوماً، والتعديل الذهبي لنظامك.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
            {onOpenSettingsModal && (
              <button
                onClick={onOpenSettingsModal}
                className="px-3 py-1.5 bg-[#0e2135] hover:bg-[#152e49] text-cyan-300 border border-cyan-800/60 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>إعدادات Webhooks</span>
              </button>
            )}
            {onOpenN8nModal && (
              <button
                onClick={onOpenN8nModal}
                className="px-3 py-1.5 bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-700/60 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>فحص n8n</span>
              </button>
            )}
          </div>
        </div>

        {/* 6 Core Functional Modules Navigation */}
        <div className="mt-5 pt-4 border-t border-cyan-900/40 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          <button
            onClick={() => { setActiveSubSection('prompt'); SoundEffects.playPop(); }}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSubSection === 'prompt'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-950/80 border border-cyan-400/50'
                : 'bg-[#091726] text-slate-300 hover:text-white hover:bg-[#0f2338] border border-cyan-950'
            }`}
          >
            <ImageIcon className="w-4 h-4 text-cyan-400" />
            <span>🎨 برومبت وتصميم</span>
          </button>

          <button
            onClick={() => { setActiveSubSection('audit'); SoundEffects.playPop(); }}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSubSection === 'audit'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-950/80 border border-cyan-400/50'
                : 'bg-[#091726] text-slate-300 hover:text-white hover:bg-[#0f2338] border border-cyan-950'
            }`}
          >
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>🔍 فحص التطبيق</span>
          </button>

          <button
            onClick={() => { setActiveSubSection('methods'); SoundEffects.playPop(); }}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSubSection === 'methods'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-950/80 border border-cyan-400/50'
                : 'bg-[#091726] text-slate-300 hover:text-white hover:bg-[#0f2338] border border-cyan-950'
            }`}
          >
            <Award className="w-4 h-4 text-amber-400" />
            <span>🏊‍♂️ أساليب السباحة</span>
          </button>

          <button
            onClick={() => { setActiveSubSection('schedule'); SoundEffects.playPop(); }}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSubSection === 'schedule'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-950/80 border border-cyan-400/50'
                : 'bg-[#091726] text-slate-300 hover:text-white hover:bg-[#0f2338] border border-cyan-950'
            }`}
          >
            <Calendar className="w-4 h-4 text-purple-400" />
            <span>📅 جدولة 10-30 يوماً</span>
          </button>

          <button
            onClick={() => { setActiveSubSection('sync'); SoundEffects.playPop(); }}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSubSection === 'sync'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-950/80 border border-cyan-400/50'
                : 'bg-[#091726] text-slate-300 hover:text-white hover:bg-[#0f2338] border border-cyan-950'
            }`}
          >
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>⚡ المفاضلة والضبط</span>
          </button>

          <button
            onClick={() => { setActiveSubSection('ask'); SoundEffects.playPop(); }}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSubSection === 'ask'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-950/80 border border-cyan-400/50'
                : 'bg-[#091726] text-slate-300 hover:text-white hover:bg-[#0f2338] border border-cyan-950'
            }`}
          >
            <Send className="w-4 h-4 text-cyan-300" />
            <span>💬 اسأل كوتش براين</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. IMAGE & PROMPT GENERATOR                                               */}
      {/* ========================================================================= */}
      {activeSubSection === 'prompt' && (
        <div className="bg-[#081523] border border-cyan-950 rounded-2xl p-5 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-cyan-950 pb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>🎨</span>
                <span>توليد برومبت احترافي وتصميم جاهز للنشر (Image & AI Prompt Engine)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                برومبتات مدققة بالعربية والإنجليزية متوافقة مع Canva و Midjourney و Gemini لتوليد بوسترات السباحة بأبعاد دقيقة.
              </p>
            </div>

            {/* Quick Topic Selector */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => { setImageTopic('freestyle_kids'); fetchPromptData('freestyle_kids'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  imageTopic === 'freestyle_kids'
                    ? 'bg-cyan-500 text-black shadow-md'
                    : 'bg-[#0c1f33] text-cyan-300 hover:bg-[#122b46]'
                }`}
              >
                👶 تدريب أطفال وكسر الخوف
              </button>
              <button
                onClick={() => { setImageTopic('phobia_relax_fix'); fetchPromptData('phobia_relax_fix'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  imageTopic === 'phobia_relax_fix'
                    ? 'bg-cyan-500 text-black shadow-md'
                    : 'bg-[#0c1f33] text-cyan-300 hover:bg-[#122b46]'
                }`}
              >
                💧 علاج فوبيا الماء Relax Fix
              </button>
              <button
                onClick={() => { setImageTopic('freestyle_technique'); fetchPromptData('freestyle_technique'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  imageTopic === 'freestyle_technique'
                    ? 'bg-cyan-500 text-black shadow-md'
                    : 'bg-[#0c1f33] text-cyan-300 hover:bg-[#122b46]'
                }`}
              >
                ⚡ تكنيك السباحة الحرة والكوع العالي
              </button>
            </div>
          </div>

          {loadingPrompt ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
              <p className="text-xs text-slate-400">جاري صياغة البرومبت الهندسي والأبعاد البصرية...</p>
            </div>
          ) : promptData ? (
            <div className="space-y-4">
              {/* Card Meta */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-[#0b1a2a] border border-cyan-900/40 rounded-xl p-3">
                  <span className="text-[11px] text-slate-400 block mb-1">🎯 العنوان والخطاف على الصورة:</span>
                  <span className="text-xs font-bold text-cyan-300">{promptData.headline}</span>
                </div>
                <div className="bg-[#0b1a2a] border border-cyan-900/40 rounded-xl p-3">
                  <span className="text-[11px] text-slate-400 block mb-1">📐 الأبعاد ونسبة العرض:</span>
                  <span className="text-xs font-bold text-emerald-300">{promptData.dimensions}</span>
                </div>
                <div className="bg-[#0b1a2a] border border-cyan-900/40 rounded-xl p-3">
                  <span className="text-[11px] text-slate-400 block mb-1">💬 نص الهوك المكتوب على البوستر:</span>
                  <span className="text-xs font-bold text-amber-300">{promptData.hookOnImage}</span>
                </div>
              </div>

              {/* Prompts Display */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* English Prompt */}
                <div className="bg-[#06111d] border border-cyan-900/60 rounded-xl p-4 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                      <span>🇬🇧</span> البرومبت الهندسي الدقيق (AI Image Generator Prompt)
                    </span>
                    <button
                      onClick={() => copyText(promptData.promptEn, 'البرومبت الإنجليزي')}
                      className="px-2.5 py-1 bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 text-[11px] rounded-lg border border-cyan-800 flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      {copiedField === 'البرومبت الإنجليزي' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === 'البرومبت الإنجليزي' ? 'تم النسخ' : 'نسخ البرومبت'}</span>
                    </button>
                  </div>
                  <p className="text-xs text-slate-300 font-mono leading-relaxed bg-[#040b13] p-3 rounded-lg border border-slate-800 dir-ltr text-left">
                    {promptData.promptEn}
                  </p>
                </div>

                {/* Arabic Prompt */}
                <div className="bg-[#06111d] border border-cyan-900/60 rounded-xl p-4 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                      <span>🇦🇪</span> التوجيه البصري بالعربية (للمصمم أو محرك المحتوى)
                    </span>
                    <button
                      onClick={() => copyText(promptData.promptAr, 'التوجيه العربي')}
                      className="px-2.5 py-1 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 text-[11px] rounded-lg border border-emerald-800 flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      {copiedField === 'التوجيه العربي' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === 'التوجيه العربي' ? 'تم النسخ' : 'نسخ التوجيه'}</span>
                    </button>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed bg-[#040b13] p-3 rounded-lg border border-slate-800">
                    {promptData.promptAr}
                  </p>
                </div>
              </div>

              {/* Visual Elements & Palette */}
              <div className="bg-[#0b1a2a] border border-cyan-950 rounded-xl p-4 space-y-2">
                <span className="text-xs font-bold text-slate-300 block">✨ العناصر البصرية وألوان الهوية البحرية:</span>
                <div className="flex flex-wrap gap-2">
                  {promptData.visualElements?.map((elem: string, idx: number) => (
                    <span key={idx} className="text-xs bg-[#06121f] text-cyan-200 border border-cyan-900/50 px-2.5 py-1 rounded-lg">
                      • {elem}
                    </span>
                  ))}
                  {promptData.colorPalette?.map((color: string, idx: number) => (
                    <span key={idx} className="text-xs bg-[#06121f] text-slate-300 border border-slate-800 px-2.5 py-1 rounded-lg font-mono">
                      🎨 {color}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action: Send Directly to Content Factory */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => {
                    const ideaText = `${promptData.headline}\n\n${promptData.hookOnImage}\n\n📍 برومبت التصميم: ${promptData.promptAr}`;
                    onTransferIdeaToFactory(ideaText, 'Instagram');
                    onShowNotification('🚀 تم تحويل البرومبت فوراً إلى مصنع المحتوى!');
                  }}
                  className="px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-black text-xs font-bold rounded-xl flex items-center gap-2 shadow-lg shadow-cyan-950 cursor-pointer transition-all"
                >
                  <Sparkles className="w-4 h-4 text-black" />
                  <span>تحويل التصميم إلى منشور في مصنع المحتوى فوراً</span>
                  <ArrowRight className="w-4 h-4 rotate-180" />
                </button>
              </div>
            </div>
          ) : null}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. SYSTEM & PIPELINE HEALTH CHECK                                         */}
      {/* ========================================================================= */}
      {activeSubSection === 'audit' && (
        <div className="bg-[#081523] border border-cyan-950 rounded-2xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-cyan-950 pb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>🔍</span>
                <span>فحص التطبيق والجاهزية التشغيلية (App Health & Diagnostic)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                تشخيص سريع ومباشر في 3 نقاط محددة لمعرفة ماذا يعمل وما يحتاج انتباه المالك دون إسهاب.
              </p>
            </div>
            <button
              onClick={() => { fetchAuditData(); SoundEffects.playPop(); }}
              disabled={loadingAudit}
              className="px-3 py-1.5 bg-[#0e2135] hover:bg-[#152e49] text-cyan-300 border border-cyan-800/60 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingAudit ? 'animate-spin' : ''}`} />
              <span>فحص فوري الآن</span>
            </button>
          </div>

          {loadingAudit ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
              <p className="text-xs text-slate-400">جاري فحص الويبهوكات والمسارات والجدولة...</p>
            </div>
          ) : auditData ? (
            <div className="space-y-4">
              {/* Score & General State */}
              <div className="bg-[#0b1a2a] border border-cyan-900/60 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg ${
                    auditData.overallStatus === 'healthy' 
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' 
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                  }`}>
                    {auditData.score}%
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">
                      الحالة العامة للمنظومة: {auditData.overallStatus === 'healthy' ? '🟢 جاهزة ومستقرة' : '🟡 تعمل مع توصية بسيطة'}
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      تم فحص سلامة الربط، تدفق الرسائل عبر n8n، ومسار نشر المحتوى.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2.5 py-1 rounded-lg border font-semibold flex items-center gap-1.5 ${
                    waConnected ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                  }`}>
                    <span className={`w-2 h-2 rounded-full ${waConnected ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                    واتساب: {waConnected ? 'متصل' : 'بانتظار الرابط'}
                  </span>
                  <span className={`text-xs px-2.5 py-1 rounded-lg border font-semibold flex items-center gap-1.5 ${
                    msgConnected ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                  }`}>
                    <span className={`w-2 h-2 rounded-full ${msgConnected ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                    ماسنجر: {msgConnected ? 'متصل' : 'بانتظار الرابط'}
                  </span>
                </div>
              </div>

              {/* 3 Diagnostics Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {auditData.diagnostics?.map((diag: any, idx: number) => (
                  <div key={idx} className="bg-[#06111d] border border-cyan-950 rounded-xl p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{diag.item}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        diag.status === 'نشط' || diag.status === 'محمية ومؤمنة' || diag.status === 'جاهز للتشغيل'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        {diag.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {diag.detail}
                    </p>
                  </div>
                ))}
              </div>

              {/* Recommended Action */}
              <div className="bg-[#0d2238] border border-cyan-700/60 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-cyan-300 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    الإجراء الفوري المقترح من كوتش براين:
                  </span>
                  <p className="text-xs text-slate-200 font-medium">
                    {auditData.recommendedAction}
                  </p>
                </div>
                {onOpenSettingsModal && (
                  <button
                    onClick={onOpenSettingsModal}
                    className="px-3.5 py-2 bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold rounded-xl shrink-0 cursor-pointer transition-colors"
                  >
                    فتح إعدادات الويبهوك
                  </button>
                )}
              </div>
            </div>
          ) : null}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. SWIMMING METHODS & ACADEMY MASTERCLASS                                  */}
      {/* ========================================================================= */}
      {activeSubSection === 'methods' && (
        <div className="bg-[#081523] border border-cyan-950 rounded-2xl p-5 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-cyan-950 pb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>🏊‍♂️</span>
                <span>أفضل الطرق والأساليب لتعليم السباحة (Swimming Expertise & Methods)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                الخلاصة التكتيكية من خبرة كوتش أيمن لتطبيقها فوراً في التدريب أو تحويلها إلى سيناريو فيديو تسويقي.
              </p>
            </div>

            {/* Methods Selector */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => { setMethodTopic('kids_fearless'); fetchMethodData('kids_fearless'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  methodTopic === 'kids_fearless'
                    ? 'bg-cyan-500 text-black shadow-md'
                    : 'bg-[#0c1f33] text-cyan-300 hover:bg-[#122b46]'
                }`}
              >
                👶 تعليم الأطفال (15 دقيقة)
              </button>
              <button
                onClick={() => { setMethodTopic('phobia_relax_fix'); fetchMethodData('phobia_relax_fix'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  methodTopic === 'phobia_relax_fix'
                    ? 'bg-cyan-500 text-black shadow-md'
                    : 'bg-[#0c1f33] text-cyan-300 hover:bg-[#122b46]'
                }`}
              >
                💧 فوبيا الماء Relax Fix
              </button>
              <button
                onClick={() => { setMethodTopic('freestyle_streamline'); fetchMethodData('freestyle_streamline'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  methodTopic === 'freestyle_streamline'
                    ? 'bg-cyan-500 text-black shadow-md'
                    : 'bg-[#0c1f33] text-cyan-300 hover:bg-[#122b46]'
                }`}
              >
                ⚡ السباحة الحرة والكوع العالي
              </button>
            </div>
          </div>

          {loadingMethod ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
              <p className="text-xs text-slate-400">جاري استرجاع الأسلوب التدريبي والمناهج...</p>
            </div>
          ) : methodData ? (
            <div className="space-y-4">
              {/* Title & Golden Rule */}
              <div className="bg-[#0b1a2a] border border-cyan-900/60 rounded-xl p-4 space-y-2">
                <span className="text-xs font-bold text-amber-400 block">⭐ القاعدة الذهبية لـ كوتش أيمن:</span>
                <p className="text-sm font-semibold text-white leading-relaxed">
                  «{methodData.goldenRule}»
                </p>
              </div>

              {/* 4 Practical Bullets */}
              <div className="bg-[#06111d] border border-cyan-950 rounded-xl p-4 space-y-2.5">
                <span className="text-xs font-bold text-cyan-400 block">📌 خطوات التطبيق العملي للتدريب:</span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {methodData.bullets?.map((b: string, idx: number) => (
                    <div key={idx} className="bg-[#040c16] border border-slate-800 rounded-lg p-3 text-xs text-slate-200 leading-relaxed">
                      {b}
                    </div>
                  ))}
                </div>
              </div>

              {/* Marketing Angle & Hook */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-[#06111d] border border-cyan-950 rounded-xl p-3.5 space-y-1.5">
                  <span className="text-[11px] font-bold text-emerald-400 block">🎯 زاوية الإقناع التسويقي للعملاء:</span>
                  <p className="text-xs text-slate-300 leading-relaxed">{methodData.marketingAngle}</p>
                </div>
                <div className="bg-[#06111d] border border-cyan-950 rounded-xl p-3.5 space-y-1.5">
                  <span className="text-[11px] font-bold text-cyan-400 block">📢 هوك مقترح للفيديو أو البوست:</span>
                  <p className="text-xs text-slate-300 leading-relaxed font-medium">«{methodData.sampleHook}»</p>
                </div>
              </div>

              {/* Push to Factory Action */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => {
                    const postContent = `🏊‍♂️ ${methodData.title}\n\n${methodData.sampleHook}\n\n${methodData.goldenRule}\n\n📍 احجز جلستك الآن في فروع أبوظبي: الكورنيش، البطين، المشرف.`;
                    onTransferIdeaToFactory(postContent, 'Instagram');
                    onShowNotification('🚀 تم تحويل الأسلوب التدريبي إلى مصنع المحتوى!');
                  }}
                  className="px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-black text-xs font-bold rounded-xl flex items-center gap-2 shadow-lg shadow-cyan-950 cursor-pointer transition-all"
                >
                  <Sparkles className="w-4 h-4 text-black" />
                  <span>تحويل هذا الأسلوب إلى سيناريو منشور في المصنع فوراً</span>
                  <ArrowRight className="w-4 h-4 rotate-180" />
                </button>
              </div>
            </div>
          ) : null}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. SMART SCHEDULE 10 - 30 DAYS                                            */}
      {/* ========================================================================= */}
      {activeSubSection === 'schedule' && (
        <div className="bg-[#081523] border border-cyan-950 rounded-2xl p-5 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-cyan-950 pb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>📅</span>
                <span>المخطط الذكي وجدولة 10 إلى 30 يوماً مع التنوع الكامل</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                توزيع استراتيجي متوازن: 30% تكنيك • 25% قصص نجاح • 20% عروض • 15% ريلز • 10% أسئلة شائعة.
              </p>
            </div>

            {/* Days Selector */}
            <div className="flex items-center gap-1.5 bg-[#05101a] p-1 rounded-xl border border-cyan-950">
              {[10, 15, 20, 30].map((d) => (
                <button
                  key={d}
                  onClick={() => { setSelectedDays(d); fetchSchedulePlan(d); }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    selectedDays === d
                      ? 'bg-cyan-500 text-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {d} يوماً
                </button>
              ))}
            </div>
          </div>

          {loadingSchedule ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
              <p className="text-xs text-slate-400">جاري بناء وتوزيع خطة الـ {selectedDays} يوماً المتنوعة...</p>
            </div>
          ) : scheduleData ? (
            <div className="space-y-4">
              {/* Summary Bar & Batch Push Button */}
              <div className="bg-[#0b1a2a] border border-cyan-900/60 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-cyan-400" />
                    خطة الـ {selectedDays} يوماً جاهزة وموزعة بدقة:
                  </span>
                  <p className="text-[11px] text-slate-300">
                    {scheduleData.diversitySummary}
                  </p>
                </div>

                <button
                  onClick={handlePushAllToFactory}
                  disabled={schedulePushed}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
                    schedulePushed
                      ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/50'
                      : 'bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-black'
                  }`}
                >
                  {schedulePushed ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Sparkles className="w-4 h-4 text-black" />}
                  <span>{schedulePushed ? 'تم ترحيل الخطة كاملة إلى مصنع المحتوى!' : `ترحيل الخطة (${selectedDays} منشوراً) للمصنع والجدولة فوراً`}</span>
                </button>
              </div>

              {/* Items Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[480px] overflow-y-auto p-1 pr-2 scrollbar-thin">
                {scheduleData.items?.map((item: any) => (
                  <div key={item.id} className="bg-[#06111d] border border-cyan-950/80 rounded-xl p-3.5 space-y-2 hover:border-cyan-800 transition-colors">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded-md border border-cyan-900/60">
                        اليوم {item.day}
                      </span>
                      <span className="text-[10px] text-slate-400 font-semibold">{item.platform} • {item.format}</span>
                    </div>

                    <h5 className="text-xs font-bold text-white line-clamp-1">{item.title}</h5>
                    <p className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">{item.hookCaption}</p>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                      <span className="text-[10px] text-slate-400">📍 {item.branch}</span>
                      <button
                        onClick={() => {
                          onTransferIdeaToFactory(item.hookCaption, item.platform);
                          onShowNotification(`تم نقل منشور اليوم ${item.day} إلى المصنع!`);
                        }}
                        className="text-[10px] text-cyan-300 hover:text-cyan-200 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <span>فتح في المصنع</span>
                        <ArrowRight className="w-3 h-3 rotate-180" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. SYNC PROJECTS (NEW COACH VS COMMAND CENTER)                            */}
      {/* ========================================================================= */}
      {activeSubSection === 'sync' && (
        <div className="bg-[#081523] border border-cyan-950 rounded-2xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-cyan-950 pb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>⚡</span>
                <span>المفاضلة والضبط الذهبي بين مشروع «نيو كوتش» ومشروع «كوماند»</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                الدمج الأفضل لتفعيل أقوى المزايا من المشروعين دون أي تكرار أو تعارض في الوظائف.
              </p>
            </div>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-3 py-1 rounded-full font-bold">
              ✓ تم التوفيق بنجاح
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* New Coach */}
            <div className="bg-[#06111d] border border-cyan-900/40 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
                <h4 className="text-xs font-bold text-white">نقاط القوة في «مشروع نيو كوتش»:</h4>
              </div>
              <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                <li>الردود التلقائية المباشرة عبر واتساب مع سرعة استجابة فائقة.</li>
                <li>بوابة الاستلام البشري الفوري لمنع إرسال أي رد غير معتمد.</li>
                <li>قوالب الرد الذكي المخصصة لأسعار ومواعيد أكاديمية السباحة.</li>
              </ul>
            </div>

            {/* Command Center */}
            <div className="bg-[#06111d] border border-emerald-900/40 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                <h4 className="text-xs font-bold text-white">نقاط القوة في «مشروع كوماند سنتر»:</h4>
              </div>
              <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                <li>غرفة القيادة المركزية ومراقبة المنصات (إنستغرام، تيك توك، فيسبوك).</li>
                <li>مصنع المحتوى المتكامل مع مخطط الـ 30 يوماً وتوليد الريلز.</li>
                <li>مكتبة الوسائط، الأرشيف السحابي، وإدارة فروع أبوظبي الثلاثة.</li>
              </ul>
            </div>
          </div>

          {/* Golden Tweak Card */}
          <div className="bg-gradient-to-r from-[#0d2238] to-[#0a1a2c] border border-cyan-500/50 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400 animate-bounce" />
                <span className="text-xs font-bold text-white">التعديل الذهبي الموصى به من كوتش براين:</span>
              </div>
              <span className="text-[11px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                مفعل حالياً
              </span>
            </div>

            <p className="text-xs text-slate-200 leading-relaxed font-medium">
              «دمج بوابة الاستلام البشري المباشر وقوالب الرد الفوري من نيو كوتش، وربطها مباشرة بمصنع الـ 30 يوماً وغرفة القيادة في كوماند سنتر، بحيث ينقل المالك أي خطة أو رد أو فكرة بنقرة زر واحدة.»
            </p>

            <div className="flex items-center justify-between pt-2 border-t border-cyan-900/40">
              <span className="text-[11px] text-slate-400">
                الحالة: النظام يعمل بالهيكل الموحد المعتمد بدون Sidebar ثانية أو تشتت.
              </span>
              <button
                onClick={() => {
                  SoundEffects.playSuccess();
                  onShowNotification('✨ تم تطبيق وحفظ التعديل الذهبي بنجاح!');
                }}
                className="px-3.5 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold rounded-xl transition-all cursor-pointer shadow"
              >
                تأكيد تفعيل التعديل الذهبي
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. ASK COACH BRIAN (EXECUTIVE & CONCISE)                                  */}
      {/* ========================================================================= */}
      {activeSubSection === 'ask' && (
        <div className="bg-[#081523] border border-cyan-950 rounded-2xl p-5 space-y-5">
          <div className="border-b border-cyan-950 pb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <span>💬</span>
              <span>اسأل كوتش براين — المستشار التنفيذي الذكي</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              إجابات تكتيكية ومباشرة في نقاط محددة ("مش نشرة أخبار"). اسأل في السباحة، التصميم، الدعاية، أو الإغلاق.
            </p>
          </div>

          {/* Quick Prompts */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-400 block">⚡ اختر سؤالاً سريعاً أو اكتب سؤالك:</span>
            <div className="flex flex-wrap gap-2">
              {[
                'أفضل نصيحة لزيادة تسجيلات فرع الكورنيش هذا الأسبوع؟',
                'كيف أتعامل مع طفل يبكي بشدة في أول 5 دقائق بالمسبح؟',
                'عايز فكرة ريلز فيروسي 9:16 للتنفس الجانبي في السباحة الحرة؟',
                'ما هو الرد المثالي لعميل يرى سعر باقة الـ 1,400 درهم مرتفعاً؟'
              ].map((qp, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setUserQuestion(qp);
                    handleAskQuestion(qp);
                  }}
                  className="px-3 py-1.5 bg-[#0b1b2d] hover:bg-cyan-950/80 text-cyan-300 border border-cyan-900/60 rounded-xl text-xs transition-colors cursor-pointer text-right"
                >
                  💡 {qp}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Question Input */}
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={userQuestion}
              onChange={(e) => setUserQuestion(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAskQuestion()}
              placeholder="اكتب سؤالك هنا لكوتش براين (مثال: أفضل طريقة لعلاج فوبيا الكبار، أو برومبت صورة لفرع البطين)..."
              className="flex-1 bg-[#050f1a] border border-cyan-900/60 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none"
            />
            <button
              onClick={() => handleAskQuestion()}
              disabled={loadingAsk || !userQuestion.trim()}
              className="px-4 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-black text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
            >
              {loadingAsk ? <RefreshCw className="w-4 h-4 animate-spin text-black" /> : <Send className="w-4 h-4 text-black" />}
              <span>{loadingAsk ? 'جاري التفكير...' : 'إرسال'}</span>
            </button>
          </div>

          {/* Executive Answer Card */}
          {askReply && (
            <div className="bg-[#06111d] border border-cyan-500/40 rounded-xl p-4 space-y-3 animate-fadeIn">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                  <Brain className="w-4 h-4 text-cyan-400" />
                  خلاصة كوتش براين التنفيذية:
                </span>
                <button
                  onClick={() => copyText(askReply, 'إجابة كوتش براين')}
                  className="text-[11px] text-slate-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
                >
                  <Copy className="w-3 h-3" />
                  <span>نسخ الإجابة</span>
                </button>
              </div>

              <div className="text-xs text-slate-200 leading-relaxed whitespace-pre-line font-medium">
                {askReply}
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-end">
                <button
                  onClick={() => {
                    onTransferIdeaToFactory(askReply, 'Instagram');
                    onShowNotification('🚀 تم نقل إجابة كوتش براين إلى مصنع المحتوى!');
                  }}
                  className="px-3 py-1.5 bg-[#0e2237] hover:bg-[#142e49] text-cyan-300 text-xs font-bold rounded-lg border border-cyan-800/60 flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>تحويل الإجابة لمنشور في المصنع</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
