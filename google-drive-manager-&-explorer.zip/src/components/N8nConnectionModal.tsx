import React, { useState, useEffect } from 'react';
import { 
  Radio, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  ExternalLink, 
  Zap, 
  Send, 
  Copy, 
  Check, 
  HelpCircle,
  Clock,
  Sparkles,
  Sliders,
  Save,
  Globe,
  ShieldAlert,
  SlidersHorizontal,
  Info
} from 'lucide-react';

interface N8nStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSimulateMessage?: (simulatedConvo: any) => void;
}

export const N8nConnectionModal: React.FC<N8nStatusModalProps> = ({
  isOpen,
  onClose,
  onSimulateMessage
}) => {
  // Tabs: 'meta_guide' (Meta Webhook Setup & Fix) vs 'settings' (n8n Webhook Configuration) vs 'test' (Ping & Simulator)
  const [modalTab, setModalTab] = useState<'meta_guide' | 'settings' | 'test'>('meta_guide');

  // Meta Webhook Handshake & Verification state
  const [isTestingHandshake, setIsTestingHandshake] = useState(false);
  const [handshakeTestStatus, setHandshakeTestStatus] = useState<any>(null);

  const metaCallbackUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}/api/webhook`
    : 'https://ais-dev-kxzeb5wx2a4facw43ozvpb-306115047061.europe-west2.run.app/api/webhook';

  const metaVerifyToken = 'coach_ayman_webhook_verify_2026';

  const handleTestMetaHandshake = async () => {
    setIsTestingHandshake(true);
    setHandshakeTestStatus(null);
    try {
      const challengeTest = `VERIFY_CHALLENGE_${Date.now()}`;
      const res = await fetch(`/api/webhook?hub.mode=subscribe&hub.verify_token=${metaVerifyToken}&hub.challenge=${challengeTest}`);
      const text = await res.text();
      if (res.ok && text.includes('VERIFY_CHALLENGE')) {
        setHandshakeTestStatus({
          success: true,
          message: '✓ نجح اختبار مصافحة التحقق بنسبة 100%! الخادم استجاب فوراً برمز التحدي (hub.challenge) المقبول لدى Meta.',
          response: text
        });
      } else {
        setHandshakeTestStatus({
          success: false,
          message: `استجاب الخادم برمز: ${res.status} (${text})`
        });
      }
    } catch (err: any) {
      setHandshakeTestStatus({
        success: false,
        message: `تعذر الاتصال بالخادم: ${err.message}`
      });
    } finally {
      setIsTestingHandshake(false);
    }
  };

  // Input states for custom n8n URLs
  const [waUrlInput, setWaUrlInput] = useState<string>('');
  const [msgUrlInput, setMsgUrlInput] = useState<string>('');
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  // Connection states for each platform
  const [whatsappConnected, setWhatsappConnected] = useState<boolean>(false);
  const [messengerConnected, setMessengerConnected] = useState<boolean>(false);

  // Ping test state
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  // Simulation test message states
  const [simChannel, setSimChannel] = useState<'whatsapp' | 'messenger'>('whatsapp');
  const [simCustomerName, setSimCustomerName] = useState('أحمد الشامسي (تجربة حية)');
  const [simCustomerPhone, setSimCustomerPhone] = useState('+971 50 123 4567');
  const [simText, setSimText] = useState('السلام عليكم كوتش، هل تدريب السباحة للكبار متاح هذا الأسبوع في فرع الكورنيش؟');
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationResult, setSimulationResult] = useState<any>(null);

  // Webhook URLs on this app to receive data from n8n
  const appWebhookUrlWhatsApp = typeof window !== 'undefined' 
    ? `${window.location.origin}/api/n8n/webhook/incoming?channel=whatsapp`
    : '/api/n8n/webhook/incoming?channel=whatsapp';
  
  const appWebhookUrlMessenger = typeof window !== 'undefined' 
    ? `${window.location.origin}/api/n8n/webhook/incoming?channel=messenger`
    : '/api/n8n/webhook/incoming?channel=messenger';

  // Load existing settings on mount / open
  useEffect(() => {
    if (isOpen) {
      loadWebhookSettings();
    }
  }, [isOpen]);

  const loadWebhookSettings = async () => {
    try {
      // 1. Check localStorage first for instant hydration
      const localWa = localStorage.getItem('n8n_whatsapp_webhook_url') || '';
      const localMsg = localStorage.getItem('n8n_messenger_webhook_url') || '';
      if (localWa) setWaUrlInput(localWa);
      if (localMsg) setMsgUrlInput(localMsg);
      setWhatsappConnected(Boolean(localWa && localWa.trim().startsWith('http')));
      setMessengerConnected(Boolean(localMsg && localMsg.trim().startsWith('http')));

      // 2. Fetch from backend API
      const res = await fetch('/api/n8n/webhook-settings');
      const data = await res.json();
      if (data?.settings) {
        if (!localWa && data.settings.whatsappWebhookUrl) {
          setWaUrlInput(data.settings.whatsappWebhookUrl);
          setWhatsappConnected(data.settings.whatsappConnected);
        }
        if (!localMsg && data.settings.messengerWebhookUrl) {
          setMsgUrlInput(data.settings.messengerWebhookUrl);
          setMessengerConnected(data.settings.messengerConnected);
        }
      }
    } catch {
      // Fallback to local storage values
    }
  };

  const handleSaveSettings = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSavingSettings(true);
    setSaveFeedback(null);

    const waValid = Boolean(waUrlInput.trim().startsWith('http'));
    const msgValid = Boolean(msgUrlInput.trim().startsWith('http'));

    // Save locally
    localStorage.setItem('n8n_whatsapp_webhook_url', waUrlInput.trim());
    localStorage.setItem('n8n_messenger_webhook_url', msgUrlInput.trim());
    setWhatsappConnected(waValid);
    setMessengerConnected(msgValid);

    try {
      await fetch('/api/n8n/webhook-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          whatsappWebhookUrl: waUrlInput.trim(),
          messengerWebhookUrl: msgUrlInput.trim()
        })
      });
      setSaveFeedback('تم حفظ عناوين الويبهوك بنجاح وتحديث حالة المنصات!');
    } catch {
      setSaveFeedback('تم الحفظ محلياً في المتصفح!');
    } finally {
      setIsSavingSettings(false);
      setTimeout(() => setSaveFeedback(null), 4000);
    }
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/n8n/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetUrl: 'internal' })
      });
      const data = await res.json();
      setTestResult(data);
    } catch (err: any) {
      setTestResult({
        success: false,
        status: 'error',
        error: err.message || 'تعذر الاتصال بـ n8n'
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUrl(label);
    setTimeout(() => setCopiedUrl(null), 2500);
  };

  const handleSimulateIncoming = async () => {
    if (!simText.trim()) return;
    setIsSimulating(true);
    setSimulationResult(null);
    try {
      const res = await fetch('/api/n8n/simulate-incoming', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform: simChannel,
          customerName: simCustomerName,
          customerPhoneOrId: simCustomerPhone,
          messageText: simText,
          branch: 'أبوظبي: الكورنيش'
        })
      });
      const data = await res.json();
      setSimulationResult(data);
      if (onSimulateMessage && data.conversation) {
        onSimulateMessage(data.conversation);
      }
    } catch (err: any) {
      setSimulationResult({ error: err.message || 'فشل إرسال رسالة المحاكاة' });
    } finally {
      setIsSimulating(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto" dir="rtl">
      <div className="bg-[#091522] border border-cyan-800/80 rounded-2xl max-w-2xl w-full p-5 sm:p-6 space-y-5 shadow-2xl text-slate-200 animate-in fade-in zoom-in-95 duration-150 my-auto">
        
        {/* Header with Close Button */}
        <div className="flex items-center justify-between border-b border-cyan-950 pb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-cyan-600 flex items-center justify-center shadow-md shadow-emerald-600/20 text-white shrink-0">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>إعدادات الويبهوك (Webhooks Settings) وربط n8n</span>
              </h3>
              <p className="text-xs text-slate-400">
                تهيئة عناوين URL لمنصتي WhatsApp و Messenger وحالة الاتصال (Connected / Disconnected)
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation: Meta Setup Guide vs n8n URLs vs Test & Simulator */}
        <div className="flex items-center gap-2 bg-[#061019] p-1 rounded-xl border border-cyan-950">
          <button
            onClick={() => setModalTab('meta_guide')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              modalTab === 'meta_guide'
                ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-cyan-300" />
            <span>حل خطأ Meta Webhooks وتفعيل الاشتراك</span>
          </button>

          <button
            onClick={() => setModalTab('settings')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              modalTab === 'settings'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>عناوين n8n المسجلة (URLs)</span>
          </button>

          <button
            onClick={() => {
              setModalTab('test');
              if (!testResult) handleTestConnection();
            }}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              modalTab === 'test'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>اختبار النبض والمحاكاة</span>
          </button>
        </div>

        {/* ======================================================== */}
        {/* TAB 0: META WEBHOOK SETUP & ERROR FIX (حل مشكلة رسالة Meta) */}
        {/* ======================================================== */}
        {modalTab === 'meta_guide' && (
          <div className="space-y-4">
            
            {/* The Error Breakdown Box */}
            <div className="bg-rose-950/30 border border-rose-800/50 rounded-2xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-rose-300 font-bold text-xs">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>الخطأ الذي ظهر لك في لوحة تحكم Meta (#N/A:WBxP--1950270422-4123496798):</span>
              </div>
              <p className="text-[11px] text-slate-300 font-mono bg-black/40 p-2.5 rounded-xl border border-rose-900/40 leading-relaxed" dir="rtl">
                «تعذر التحقق من صحة عنوان URL الاستدعاء أو رمز التحقق. يرجى التحقق من المعلومات المقدمة أو إعادة المحاولة لاحقًا.»
              </p>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                💡 <strong>السبب والحل:</strong> خادم Meta يرسل طلباً خفياً لفحص الرابط والتأكد من استجابته. تم إعداد وتفعيل مسار الويبهوك على خادمنا ليرد فوراً برمز التحدي المقبول لميتا. اتبع البيانات والخطوات أدناه.
              </p>
            </div>

            {/* Quick Copy Inputs */}
            <div className="bg-[#061019] border border-cyan-950 rounded-2xl p-4 space-y-3">
              <div className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>البيانات الجاهزة للصق في خانات Meta Dashboard:</span>
              </div>

              {/* 1. Callback URL */}
              <div className="space-y-1">
                <label className="text-[11px] text-slate-300 font-bold block">
                  1. عنوان URL للاستدعاء (Callback URL):
                </label>
                <div className="flex items-center justify-between bg-[#081522] border border-cyan-900/60 rounded-xl px-3 py-2 text-xs font-mono text-cyan-200">
                  <span className="truncate" dir="ltr">{metaCallbackUrl}</span>
                  <button
                    onClick={() => handleCopy(metaCallbackUrl, 'meta-url')}
                    className="mr-2 text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 shrink-0 font-sans cursor-pointer"
                  >
                    {copiedUrl === 'meta-url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedUrl === 'meta-url' ? 'تم النسخ' : 'نسخ الرابط'}</span>
                  </button>
                </div>
              </div>

              {/* 2. Verify Token */}
              <div className="space-y-1">
                <label className="text-[11px] text-slate-300 font-bold block">
                  2. رمز التحقق (Verify Token):
                </label>
                <div className="flex items-center justify-between bg-[#081522] border border-cyan-900/60 rounded-xl px-3 py-2 text-xs font-mono text-emerald-300">
                  <span className="truncate" dir="ltr">{metaVerifyToken}</span>
                  <button
                    onClick={() => handleCopy(metaVerifyToken, 'meta-token')}
                    className="mr-2 text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 shrink-0 font-sans cursor-pointer"
                  >
                    {copiedUrl === 'meta-token' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedUrl === 'meta-token' ? 'تم النسخ' : 'نسخ الرمز'}</span>
                  </button>
                </div>
              </div>

              {/* Live Handshake Button */}
              <div className="pt-2 border-t border-cyan-950 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span className="text-[10px] text-slate-400">
                  يمكنك اختبار استجابة السيرفر فوراً للتأكد قبل الضغط على حفظ:
                </span>
                <button
                  type="button"
                  onClick={handleTestMetaHandshake}
                  disabled={isTestingHandshake}
                  className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl shadow flex items-center justify-center gap-1.5 transition-all shrink-0 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTestingHandshake ? 'animate-spin' : ''}`} />
                  <span>{isTestingHandshake ? 'جارٍ الفحص...' : 'فحص استجابة السيرفر الآن'}</span>
                </button>
              </div>

              {handshakeTestStatus && (
                <div className={`p-3 rounded-xl border text-xs leading-relaxed ${
                  handshakeTestStatus.success 
                    ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-300' 
                    : 'bg-rose-950/40 border-rose-700/60 text-rose-300'
                }`}>
                  {handshakeTestStatus.message}
                </div>
              )}
            </div>

            {/* 5-Step Guide */}
            <div className="bg-[#0b1724] border border-cyan-900/60 rounded-2xl p-4 space-y-2.5 text-xs text-slate-300">
              <div className="font-bold text-white text-xs flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>الخطوات الإجرائية داخل لوحة Meta App Dashboard:</span>
              </div>
              <ol className="space-y-2 text-[11px] list-decimal list-inside pr-1 text-slate-300 leading-relaxed">
                <li>افتح تبويب <strong>Meta App Dashboard</strong> في متصفحك.</li>
                <li>انتقل إلى <strong>Use cases &gt; Customize</strong> ثم اختر <strong>Webhooks</strong>.</li>
                <li>الصق <strong>عنوان URL للاستدعاء</strong> و<strong>رمز التحقق</strong> الموضحين بالأعلى.</li>
                <li>اضغط على زر <strong>«التحقق والحفظ» (Verify and Save)</strong> — سيتم قبول الرابط فوراً دون أي خطأ ✓.</li>
                <li>
                  في جدول الحقول (Webhook Fields)، اضغط على زر <strong>Subscribe (اشتراك)</strong> بجانب الحقلين التاليين:
                  <div className="flex items-center gap-2 mt-1.5 font-mono text-[10px]">
                    <span className="bg-emerald-950/80 border border-emerald-700 text-emerald-300 px-2 py-0.5 rounded font-bold">✓ messages</span>
                    <span className="bg-emerald-950/80 border border-emerald-700 text-emerald-300 px-2 py-0.5 rounded font-bold">✓ messages_statuses</span>
                  </div>
                </li>
              </ol>
            </div>

          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 1: WEBHOOK SETTINGS PAGE (صفحة الإعدادات المطلوبة)     */}
        {/* ======================================================== */}
        {modalTab === 'settings' && (
          <div className="space-y-4">
            
            {/* Live Connection Badges for WhatsApp & Messenger */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* WhatsApp Card */}
              <div className={`p-3.5 rounded-xl border transition-all ${
                whatsappConnected 
                  ? 'bg-emerald-950/30 border-emerald-500/50' 
                  : 'bg-slate-900/60 border-slate-800'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs flex items-center gap-1.5 text-white">
                    <span>💬</span> WhatsApp Cloud API
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                    whatsappConnected 
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${whatsappConnected ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`}></span>
                    <span>{whatsappConnected ? 'Connected (متصل)' : 'Disconnected (غير متصل)'}</span>
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1.5">
                  {whatsappConnected 
                    ? 'تم تعيين عنوان Webhook صالح للإرسال والتوجيه.' 
                    : 'أدخل رابط الويبهوك الخاص بمسار n8n أدناه لتفعيل الربط.'}
                </p>
              </div>

              {/* Messenger Card */}
              <div className={`p-3.5 rounded-xl border transition-all ${
                messengerConnected 
                  ? 'bg-blue-950/30 border-blue-500/50' 
                  : 'bg-slate-900/60 border-slate-800'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs flex items-center gap-1.5 text-white">
                    <span>⚡</span> Facebook Messenger
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                    messengerConnected 
                      ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40' 
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${messengerConnected ? 'bg-blue-400 animate-pulse' : 'bg-rose-400'}`}></span>
                    <span>{messengerConnected ? 'Connected (متصل)' : 'Disconnected (غير متصل)'}</span>
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1.5">
                  {messengerConnected 
                    ? 'تم تعيين عنوان Webhook صالح لرسائل صفحة فيسبوك.' 
                    : 'أدخل رابط الويبهوك الخاص بمسار n8n أدناه لتفعيل الربط.'}
                </p>
              </div>
            </div>

            {/* Form to enter Webhook URLs */}
            <form onSubmit={handleSaveSettings} className="bg-[#061019] border border-cyan-950 rounded-xl p-4 space-y-4">
              <div className="space-y-3">
                {/* 1. WhatsApp Webhook URL Input */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                      <span>💬</span>
                      <span>عنوان URL لـ n8n Webhook الخاص بـ WhatsApp:</span>
                    </label>
                    <span className="text-[10px] text-slate-400 font-mono">POST Endpoint</span>
                  </div>
                  <input
                    type="url"
                    value={waUrlInput}
                    onChange={(e) => setWaUrlInput(e.target.value)}
                    placeholder="https://n8n.your-domain.com/webhook/whatsapp-inbound"
                    className="w-full bg-[#091522] border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 font-mono text-left focus:outline-none transition-all"
                    dir="ltr"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    أدخل الرابط الناتج من عقدة (Webhook Node) في n8n المخصصة لاستقبال وتدفق رسائل الواتساب.
                  </p>
                </div>

                {/* 2. Messenger Webhook URL Input */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                      <span>⚡</span>
                      <span>عنوان URL لـ n8n Webhook الخاص بـ Facebook Messenger:</span>
                    </label>
                    <span className="text-[10px] text-slate-400 font-mono">POST Endpoint</span>
                  </div>
                  <input
                    type="url"
                    value={msgUrlInput}
                    onChange={(e) => setMsgUrlInput(e.target.value)}
                    placeholder="https://n8n.your-domain.com/webhook/messenger-inbound"
                    className="w-full bg-[#091522] border border-slate-700 focus:border-blue-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 font-mono text-left focus:outline-none transition-all"
                    dir="ltr"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    أدخل الرابط الناتج من عقدة (Webhook Node) في n8n المخصصة لرسائل صفحة فيسبوك ومسنجر.
                  </p>
                </div>
              </div>

              {/* Save Feedback message */}
              {saveFeedback && (
                <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-700/60 text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{saveFeedback}</span>
                </div>
              )}

              {/* Form Actions */}
              <div className="flex items-center justify-between pt-2 border-t border-cyan-950">
                <button
                  type="button"
                  onClick={() => {
                    setWaUrlInput(appWebhookUrlWhatsApp);
                    setMsgUrlInput(appWebhookUrlMessenger);
                  }}
                  className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
                >
                  استخدام العناوين الداخلية لهذا التطبيق كافتراضية
                </button>

                <button
                  type="submit"
                  disabled={isSavingSettings}
                  className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{isSavingSettings ? 'جارٍ الحفظ...' : 'حفظ الإعدادات وتحديث الاتصال'}</span>
                </button>
              </div>
            </form>

            {/* Clear Technical Explanation regarding Meta Publishing & Space */}
            <div className="bg-[#0b1724] border border-cyan-900/60 rounded-xl p-3.5 text-xs text-slate-300 space-y-2">
              <div className="flex items-center gap-2 font-bold text-cyan-300">
                <Info className="w-4 h-4 text-cyan-400" />
                <span>توضيح هام للمالك حول نشر فيسبوك وميتا والـ Subspace:</span>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-300">
                • النشر التلقائي عبر ميتا (Meta Graph API) لصفحة فيسبوك وحساب إنستغرام للأعمال يعتمد على أذونات الوصول والـ Access Tokens المربوطة بتطبيق Meta المعتمد لديك.
              </p>
              <p className="text-[11px] leading-relaxed text-slate-300">
                • عندما ترفع التطبيق على <strong>GitHub</strong> ثم تربطه بـ <strong>Vercel</strong> مع دومينك الخاص، ستعمل جميع الروابط الحالية وعناوين الويبهوك المسجلة هنا بشكل دائم وموثوق بدون أي انقطاع.
              </p>
            </div>

          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: TEST CONNECTION & SIMULATOR (فحص النبض والمحاكاة) */}
        {/* ======================================================== */}
        {modalTab === 'test' && (
          <div className="space-y-4">
            {/* Live Ping Test Box */}
            <div className="bg-[#061019] border border-cyan-900/60 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                  </span>
                  <span className="text-xs font-bold text-white">فحص سرعة استجابة محرك n8n:</span>
                  {testResult?.latency && (
                    <span className="text-[11px] bg-slate-800 text-emerald-400 px-2 py-0.5 rounded font-mono font-bold">
                      {testResult.latency}
                    </span>
                  )}
                </div>
                <button
                  onClick={handleTestConnection}
                  disabled={isTesting}
                  className="px-3 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                  <span>{isTesting ? 'جارٍ الفحص...' : 'اختبار النبض الآن (Ping Test)'}</span>
                </button>
              </div>

              {testResult && (
                <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-800/40 text-xs text-emerald-300 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{testResult.message}</span>
                </div>
              )}
            </div>

            {/* Webhook URLs to copy */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>عناوين الويبهوك الحالية لهذا السيرفر (لاستخدامها في n8n):</span>
              </h4>

              <div className="space-y-2">
                <div className="p-2.5 bg-[#061019] border border-cyan-950 rounded-xl flex items-center justify-between gap-2">
                  <div className="overflow-hidden">
                    <div className="text-[10px] font-semibold text-emerald-400">مسار واتساب (WhatsApp Webhook):</div>
                    <code className="text-[11px] text-slate-300 font-mono truncate block text-left" dir="ltr">
                      {appWebhookUrlWhatsApp}
                    </code>
                  </div>
                  <button 
                    onClick={() => handleCopy(appWebhookUrlWhatsApp, 'wa')}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                  >
                    {copiedUrl === 'wa' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedUrl === 'wa' ? 'تم النسخ' : 'نسخ'}</span>
                  </button>
                </div>

                <div className="p-2.5 bg-[#061019] border border-cyan-950 rounded-xl flex items-center justify-between gap-2">
                  <div className="overflow-hidden">
                    <div className="text-[10px] font-semibold text-blue-400">مسار مسنجر (Messenger Webhook):</div>
                    <code className="text-[11px] text-slate-300 font-mono truncate block text-left" dir="ltr">
                      {appWebhookUrlMessenger}
                    </code>
                  </div>
                  <button 
                    onClick={() => handleCopy(appWebhookUrlMessenger, 'msg')}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                  >
                    {copiedUrl === 'msg' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedUrl === 'msg' ? 'تم النسخ' : 'نسخ'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Inbound Simulator */}
            <div className="p-3 bg-[#061019] border border-slate-800 rounded-xl space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>محاكاة وصول رسالة عميل حية لفحص رد كوتش براين:</span>
                </span>
                <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800 text-xs">
                  <button
                    type="button"
                    onClick={() => setSimChannel('whatsapp')}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                      simChannel === 'whatsapp' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    WhatsApp
                  </button>
                  <button
                    type="button"
                    onClick={() => setSimChannel('messenger')}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                      simChannel === 'messenger' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Messenger
                  </button>
                </div>
              </div>

              <div>
                <textarea
                  value={simText}
                  onChange={(e) => setSimText(e.target.value)}
                  rows={2}
                  className="w-full bg-[#091522] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 resize-none"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[10px] text-slate-400">
                  تولد رد الذكاء الاصطناعي وتنقله إلى تبويب المحادثات فوراً
                </span>
                <button
                  type="button"
                  onClick={handleSimulateIncoming}
                  disabled={isSimulating || !simText.trim()}
                  className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white text-xs font-bold rounded-xl shadow flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSimulating ? 'جارٍ الإرسال...' : 'إرسال المحاكاة الآن'}</span>
                </button>
              </div>

              {simulationResult && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-700/60 rounded-xl text-xs space-y-1.5">
                  <div className="flex items-center gap-1.5 text-emerald-300 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>تم استقبال الرسالة بنجاح عبر مسار الويبهوك!</span>
                  </div>
                  <div className="text-[11px] text-slate-300">
                    <strong className="text-white">رد كوتش براين المقترح:</strong> {simulationResult.aiDraftReply}
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-cyan-950 pt-3">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>جاهز للتكامل والرفع المباشر على Vercel و GitHub</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
