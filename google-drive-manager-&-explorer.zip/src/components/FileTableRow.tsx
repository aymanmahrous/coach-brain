import React, { useState } from 'react';
import { 
  Folder, 
  FileText, 
  Table, 
  Presentation, 
  FileCheck, 
  File, 
  Image as ImageIcon, 
  Video, 
  Music, 
  Star, 
  MoreVertical, 
  ExternalLink, 
  Sparkles, 
  Trash2, 
  Edit3, 
  RotateCcw,
  Eye,
  Receipt,
  BarChart3,
  Rocket,
  FileCheck2,
  GraduationCap,
  Palette,
  FolderGit2,
  Bell,
  Clock,
  CheckCircle2,
  Share2,
  ScanText,
  Film,
  Archive,
  Send
} from 'lucide-react';
import { DriveFile, AICategoryClassification, AICategoryKey, FileReminder } from '../types';
import { formatBytes, formatDate, getFileTypeMeta } from '../services/driveService';
import { AI_CATEGORIES } from '../services/aiCategorizeService';
import { ReminderService } from '../services/reminderService';
import { OCRService } from '../services/ocrService';
import { VeoService } from '../services/veoService';

interface FileTableRowProps {
  file: DriveFile;
  onOpen: (file: DriveFile) => void;
  onQuickLook: (file: DriveFile) => void;
  onStarToggle: (file: DriveFile) => void;
  onDelete: (file: DriveFile) => void;
  onRestore?: (file: DriveFile) => void;
  onRename: (file: DriveFile) => void;
  onAIAnalyze: (file: DriveFile) => void;
  onShare?: (file: DriveFile) => void;
  onOCR?: (file: DriveFile) => void;
  onVeoAnimate?: (file: DriveFile) => void;
  onBackupFolder?: (folder: DriveFile) => void;
  onSendToAutomation?: (file: DriveFile) => void;
  isTrashView?: boolean;
  aiClassification?: AICategoryClassification;
  onSelectAICategory?: (catKey: AICategoryKey) => void;
  reminder?: FileReminder;
  onSetReminder?: (file: DriveFile) => void;
  isSelected?: boolean;
  onToggleSelect?: (file: DriveFile) => void;
  selectionActive?: boolean;
}

export const FileTableRow: React.FC<FileTableRowProps> = ({
  file,
  onOpen,
  onQuickLook,
  onStarToggle,
  onDelete,
  onRestore,
  onRename,
  onAIAnalyze,
  onShare,
  onOCR,
  onVeoAnimate,
  onBackupFolder,
  onSendToAutomation,
  isTrashView = false,
  aiClassification,
  onSelectAICategory,
  reminder,
  onSetReminder,
  isSelected = false,
  onToggleSelect,
  selectionActive = false,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const isFolder = file.mimeType === 'application/vnd.google-apps.folder';
  const meta = getFileTypeMeta(file.mimeType);

  const categoryMeta = aiClassification?.category ? AI_CATEGORIES[aiClassification.category] : null;

  const renderIcon = () => {
    if (isFolder) return <Folder className="w-5 h-5 text-amber-500 fill-amber-500/20" />;
    if (meta.type === 'doc') return <FileText className="w-5 h-5 text-blue-600" />;
    if (meta.type === 'sheet') return <Table className="w-5 h-5 text-emerald-600" />;
    if (meta.type === 'slide') return <Presentation className="w-5 h-5 text-amber-600" />;
    if (meta.type === 'pdf') return <FileCheck className="w-5 h-5 text-rose-600" />;
    if (meta.type === 'image') return <ImageIcon className="w-5 h-5 text-purple-600" />;
    if (meta.type === 'video') return <Video className="w-5 h-5 text-indigo-600" />;
    if (meta.type === 'audio') return <Music className="w-5 h-5 text-pink-600" />;
    return <File className="w-5 h-5 text-slate-500" />;
  };

  const getAIIcon = (key: AICategoryKey) => {
    switch (key) {
      case 'invoices': return <Receipt className="w-3 h-3 text-emerald-600" />;
      case 'reports': return <BarChart3 className="w-3 h-3 text-blue-600" />;
      case 'projects': return <Rocket className="w-3 h-3 text-amber-600" />;
      case 'contracts': return <FileCheck2 className="w-3 h-3 text-purple-600" />;
      case 'education': return <GraduationCap className="w-3 h-3 text-cyan-600" />;
      case 'media': return <Palette className="w-3 h-3 text-rose-600" />;
      default: return <FolderGit2 className="w-3 h-3 text-slate-600" />;
    }
  };

  return (
    <tr 
      onClick={() => onOpen(file)}
      className={`group transition-colors border-b border-slate-100 cursor-pointer text-sm ${
        isSelected
          ? 'bg-blue-50/80 hover:bg-blue-50'
          : 'hover:bg-blue-50/40'
      }`}
    >
      {/* File Name & Icon & AI Pill */}
      <td className="py-3 px-4">
        <div className="flex items-center gap-2.5">
          {onToggleSelect && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleSelect(file);
              }}
              className={`w-4.5 h-4.5 rounded border flex items-center justify-center transition-all shrink-0 ${
                isSelected
                  ? 'bg-blue-600 border-blue-600 text-white'
                  : selectionActive
                  ? 'bg-white border-slate-300 hover:border-blue-500'
                  : 'bg-white border-slate-300 opacity-0 group-hover:opacity-100 hover:border-blue-500'
              }`}
              title={isSelected ? 'إلغاء التحديد' : 'تحديد'}
            >
              {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
            </button>
          )}

          <div className="shrink-0 p-1.5 bg-slate-50 rounded-lg group-hover:bg-white transition-colors">
            {renderIcon()}
          </div>
          <div className="min-w-0 flex flex-col">
            <span className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate block">
              {file.name}
            </span>

            {/* Badges container: AI Category & Reminder */}
            <div className="flex flex-wrap items-center gap-1.5 mt-0.5" onClick={(e) => e.stopPropagation()}>
              {/* AI Category Pill if available */}
              {!isFolder && categoryMeta && (
                <button
                  onClick={() => onSelectAICategory && aiClassification && onSelectAICategory(aiClassification.category)}
                  className={`inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.2 rounded border transition-colors cursor-pointer ${categoryMeta.badgeBg} ${categoryMeta.badgeText} ${categoryMeta.badgeBorder}`}
                  title={`تصنيف AI: ${categoryMeta.label} - انقر للفلترة`}
                >
                  {getAIIcon(aiClassification.category)}
                  <span>{categoryMeta.label}</span>
                </button>
              )}

              {/* Reminder Badge */}
              {reminder && (
                <button
                  onClick={() => onSetReminder && onSetReminder(file)}
                  className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.2 rounded-md border transition-colors cursor-pointer ${
                    reminder.completed
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : ReminderService.isDue(reminder)
                        ? 'bg-rose-50 text-rose-700 border-rose-300 animate-pulse'
                        : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                  }`}
                  title="انقر لإدارة التذكير"
                >
                  {reminder.completed ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                  ) : (
                    <Bell className={`w-3 h-3 shrink-0 ${ReminderService.isDue(reminder) ? 'text-rose-600 animate-bounce' : 'text-amber-600'}`} />
                  )}
                  <span>
                    {reminder.completed 
                      ? 'تذكير منجز'
                      : ReminderService.isDue(reminder)
                        ? 'مستحق الآن!'
                        : ReminderService.formatReminderDate(reminder.remindAt)}
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      </td>

      {/* File Type */}
      <td className="py-3 px-4 hidden sm:table-cell text-slate-500">
        <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${meta.color}`}>
          {meta.label}
        </span>
      </td>

      {/* Owner */}
      <td className="py-3 px-4 hidden md:table-cell text-slate-600 text-xs">
        {file.owners?.[0]?.displayName || 'أنا'}
      </td>

      {/* Modified Date */}
      <td className="py-3 px-4 text-slate-500 text-xs whitespace-nowrap">
        {formatDate(file.modifiedTime)}
      </td>

      {/* Size */}
      <td className="py-3 px-4 text-slate-500 text-xs font-mono">
        {isFolder ? '—' : formatBytes(file.size)}
      </td>

      {/* Actions */}
      <td className="py-3 px-4 text-left whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-end gap-1">
          
          {/* Dedicated Quick Look Eye Button */}
          <button
            onClick={() => onQuickLook(file)}
            className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-100/70 rounded-lg transition-all"
            title="معاينة سريعة (Quick Look)"
          >
            <Eye className="w-4 h-4" />
          </button>

          {!isTrashView && (
            <button
              onClick={() => onStarToggle(file)}
              className={`p-1.5 rounded-lg transition-colors ${
                file.starred ? 'text-amber-500 hover:text-amber-600' : 'text-slate-300 hover:text-amber-400 opacity-0 group-hover:opacity-100'
              }`}
              title={file.starred ? 'إزالة من المفضلة' : 'تمييز بنجمة'}
            >
              <Star className={`w-4 h-4 ${file.starred ? 'fill-amber-400' : ''}`} />
            </button>
          )}

          {!isFolder && !isTrashView && (
            <button
              onClick={() => onAIAnalyze(file)}
              className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
              title="تحليل ذكي وتلخيص"
            >
              <Sparkles className="w-4 h-4" />
            </button>
          )}

          {isFolder && !isTrashView && onBackupFolder && (
            <button
              onClick={() => onBackupFolder(file)}
              className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
              title="نسخ احتياطي وضغط المجلد كملف ZIP"
            >
              <Archive className="w-4 h-4" />
            </button>
          )}

          {!isFolder && !isTrashView && onOCR && OCRService.isOCRSupported(file) && (
            <button
              onClick={() => onOCR(file)}
              className="p-1.5 text-violet-600 hover:bg-violet-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
              title="استخراج النصوص عبر التعرف الضوئي (OCR)"
            >
              <ScanText className="w-4 h-4" />
            </button>
          )}

          {!isFolder && !isTrashView && onVeoAnimate && VeoService.isVeoSupported(file) && (
            <button
              onClick={() => onVeoAnimate(file)}
              className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
              title="تحريك الصورة لفيديو سينمائي عبر Veo"
            >
              <Film className="w-4 h-4" />
            </button>
          )}

          {!isTrashView && onShare && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onShare(file);
              }}
              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
              title="مشاركة الملف وتحديد الصلاحيات"
            >
              <Share2 className="w-4 h-4" />
            </button>
          )}

          <div className="relative">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {menuOpen && (
              <>
                <div
                  className="fixed inset-0 z-20"
                  onClick={() => setMenuOpen(false)}
                />
                <div className="absolute left-0 top-8 z-30 w-44 py-1 bg-white rounded-xl shadow-xl border border-slate-200 text-xs text-slate-700">
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onQuickLook(file);
                    }}
                    className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-blue-50 text-blue-700 font-bold"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>معاينة سريعة (Quick Look)</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onOpen(file);
                    }}
                    className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-slate-50"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>نافذة التفاصيل الكاملة</span>
                  </button>

                  {isFolder && !isTrashView && onBackupFolder && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onBackupFolder(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-emerald-50 text-emerald-700 font-bold"
                    >
                      <Archive className="w-3.5 h-3.5 text-emerald-600" />
                      <span>نسخ احتياطي للمجلد (ZIP)</span>
                    </button>
                  )}

                  {!isFolder && !isTrashView && onSendToAutomation && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onSendToAutomation(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-emerald-50 text-emerald-700 font-bold"
                    >
                      <Send className="w-3.5 h-3.5 text-emerald-600" />
                      <span>إرسال إلى الأتمتة (n8n / WhatsApp)</span>
                    </button>
                  )}

                  {!isFolder && !isTrashView && onOCR && OCRService.isOCRSupported(file) && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onOCR(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-violet-50 text-violet-700 font-bold"
                    >
                      <ScanText className="w-3.5 h-3.5 text-violet-600" />
                      <span>استخراج النصوص (OCR)</span>
                    </button>
                  )}

                  {!isFolder && !isTrashView && onVeoAnimate && VeoService.isVeoSupported(file) && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onVeoAnimate(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-rose-50 text-rose-700 font-bold"
                    >
                      <Film className="w-3.5 h-3.5 text-rose-600" />
                      <span>تحريك الصورة لفيديو (Veo)</span>
                    </button>
                  )}

                  {!isTrashView && onShare && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onShare(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-blue-50 text-blue-700 font-semibold"
                    >
                      <Share2 className="w-3.5 h-3.5 text-blue-600" />
                      <span>مشاركة الصلاحيات (Share)</span>
                    </button>
                  )}

                  {!isTrashView && onSetReminder && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onSetReminder(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-amber-50 text-amber-800 font-medium"
                    >
                      <Bell className="w-3.5 h-3.5 text-amber-600" />
                      <span>{reminder ? 'تعديل التذكير' : 'إضافة تذكير'}</span>
                    </button>
                  )}

                  {!isTrashView && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onRename(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-slate-50"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>إعادة تسمية</span>
                    </button>
                  )}

                  {file.webViewLink && (
                    <a
                      href={file.webViewLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-slate-50 text-blue-600"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>فتح في Google Drive</span>
                    </a>
                  )}

                  {isTrashView && onRestore && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onRestore(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-emerald-50 text-emerald-700"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>استعادة</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onDelete(file);
                    }}
                    className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-red-50 text-red-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isTrashView ? 'حذف نهائي' : 'حذف'}</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </td>
    </tr>
  );
};
