import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Sparkles,
  Film,
  Play,
  Pause,
  Download,
  Upload,
  RefreshCw,
  HardDrive,
  CheckCircle2,
  AlertCircle,
  Clapperboard,
  ZoomIn,
  Wind,
  MoveHorizontal,
  SunMedium,
  RotateCcw,
  Maximize2,
  Video,
  ImageIcon,
  Sliders,
  Check,
  ExternalLink,
  ChevronRight,
  Layers,
  ArrowRight
} from 'lucide-react';
import { DriveFile } from '../types';
import { VeoService, VEO_MOTION_PRESETS, VeoMotionPreset, VeoGenerationResult } from '../services/veoService';
import { SoundEffects } from '../utils/audioChime';

interface VeoVideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  file?: DriveFile | null;
  token?: string | null;
  customBase64?: string;
  onSaveVideoToDrive?: (fileName: string, videoBlob: Blob) => Promise<DriveFile>;
}

export const VeoVideoModal: React.FC<VeoVideoModalProps> = ({
  isOpen,
  onClose,
  file,
  token,
  customBase64,
  onSaveVideoToDrive
}) => {
  // Image Source State
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string>('image/png');
  const [imageName, setImageName] = useState<string>('photo.png');

  // Generation Config State
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [resolution, setResolution] = useState<'720p' | '1080p'>('720p');
  const [selectedPreset, setSelectedPreset] = useState<string>('cinematic');
  const [customPrompt, setCustomPrompt] = useState<string>(VEO_MOTION_PRESETS[0].prompt);
  const [customPromptEnabled, setCustomPromptEnabled] = useState<boolean>(false);

  // Status & Progress State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [progressMessage, setProgressMessage] = useState<string>('');
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);

  // Result State
  const [generationResult, setGenerationResult] = useState<VeoGenerationResult | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const [isSavingToDrive, setIsSavingToDrive] = useState<boolean>(false);
  const [savedDriveFile, setSavedDriveFile] = useState<DriveFile | null>(null);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Video Element Ref
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize image on open or props change
  useEffect(() => {
    if (!isOpen) return;

    setError(null);
    setGenerationResult(null);
    setSavedDriveFile(null);
    setSaveSuccessMsg(null);
    setIsGenerating(false);

    if (customBase64) {
      setImagePreview(customBase64);
      setImageName(file?.name || 'uploaded-photo.png');
      setImageMimeType('image/png');
    } else if (file) {
      setImageName(file.name);
      setImageMimeType(file.mimeType || 'image/png');

      // Fetch or use thumbnail / media
      if (file.thumbnailLink) {
        // High-res thumbnail version
        const highRes = file.thumbnailLink.replace(/=s\d+/, '=s1200');
        setImagePreview(highRes);
      } else if (token) {
        // Direct media URL
        setImagePreview(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`);
      }
    } else {
      // Default demo image
      setImagePreview('https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1000&auto=format&fit=crop&q=80');
      setImageName('landscape-scenery.jpg');
      setImageMimeType('image/jpeg');
    }
  }, [isOpen, file, customBase64, token]);

  // Handle preset selection
  const handleSelectPreset = (preset: VeoMotionPreset) => {
    setSelectedPreset(preset.id);
    if (!customPromptEnabled) {
      setCustomPrompt(preset.prompt);
    }
    SoundEffects.playPop();
  };

  // Handle local file upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files?.[0];
    if (!uploaded) return;

    try {
      const base64 = await VeoService.fileToBase64(uploaded);
      setImagePreview(base64);
      setImageName(uploaded.name);
      setImageMimeType(uploaded.type || 'image/png');
      setGenerationResult(null);
      setError(null);
      SoundEffects.playPop();
    } catch (err: any) {
      setError('فشل في قراءة ملف الصورة. يرجى اختيار صورة أخرى.');
    }
  };

  // Start timer when generating
  useEffect(() => {
    if (isGenerating) {
      setElapsedSeconds(0);
      timerIntervalRef.current = setInterval(() => {
        setElapsedSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    }

    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    };
  }, [isGenerating]);

  // Trigger Video Generation
  const handleStartGeneration = async () => {
    if (!imagePreview) {
      setError('يرجى اختيار أو رفع صورة أولاً.');
      return;
    }

    setIsGenerating(true);
    setProgressPercent(5);
    setProgressMessage('جاري تهيئة نموذج Veo لتحريك الصورة...');
    setError(null);
    setGenerationResult(null);
    setSavedDriveFile(null);
    setSaveSuccessMsg(null);
    SoundEffects.playPop();

    try {
      // If we have customBase64 or dataURL:
      let rawBase64 = imagePreview;

      // If image is a remote URL (like unsplash), convert to base64
      if (imagePreview.startsWith('http')) {
        try {
          const fetchRes = await fetch(imagePreview);
          const blob = await fetchRes.blob();
          rawBase64 = await VeoService.fileToBase64(new File([blob], imageName, { type: blob.type }));
        } catch (fetchErr) {
          console.warn('Could not fetch image directly as blob, proceeding with fileId if available:', fetchErr);
        }
      }

      const result = await VeoService.generateVideo({
        imageData: rawBase64.startsWith('data:') || !file ? rawBase64 : undefined,
        fileId: file ? file.id : undefined,
        token: token || undefined,
        prompt: customPrompt,
        aspectRatio,
        resolution,
        mimeType: imageMimeType,
        onProgress: (msg, percent) => {
          setProgressMessage(msg);
          setProgressPercent(percent);
        }
      });

      setGenerationResult(result);
      setIsGenerating(false);
      SoundEffects.playSuccess();

    } catch (err: any) {
      console.error('Video Generation Error:', err);
      setIsGenerating(false);
      setError(err.message || 'حدث خطأ أثناء توليد الفيديو بواسطة Veo. يرجى التأكد من مفتاح API والمحاولة مجدداً.');
    }
  };

  // Video Controls
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleDownloadVideo = () => {
    if (!generationResult) return;
    const a = document.createElement('a');
    a.href = generationResult.videoUrl;
    const cleanName = imageName.replace(/\.[^/.]+$/, '');
    a.download = `veo-animated-${cleanName}-${aspectRatio === '9:16' ? 'portrait' : 'landscape'}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    SoundEffects.playSuccess();
  };

  const handleSaveToDrive = async () => {
    if (!generationResult || !onSaveVideoToDrive) return;

    try {
      setIsSavingToDrive(true);
      const cleanName = imageName.replace(/\.[^/.]+$/, '');
      const videoFileName = `فيديو متحرك - ${cleanName}.mp4`;
      
      const saved = await onSaveVideoToDrive(videoFileName, generationResult.videoBlob);
      setSavedDriveFile(saved);
      setSaveSuccessMsg(`تم حفظ الفيديو بنجاح في Google Drive: "${saved.name}"`);
      SoundEffects.playSuccess();
    } catch (err: any) {
      setError(err.message || 'فشل في حفظ الفيديو في Google Drive.');
    } finally {
      setIsSavingToDrive(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-md overflow-y-auto animate-fade-in" dir="rtl">
      <div className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[92vh] overflow-hidden my-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-indigo-500/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-rose-500/20">
              <Film className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-800 text-lg">تحريك الصور إلى فيديو سينمائي</h3>
                <span className="px-2 py-0.5 text-[10px] font-bold tracking-wide uppercase bg-gradient-to-r from-amber-600 to-rose-600 text-white rounded-full shadow-xs">
                  Veo 3.1 AI
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                توليد فيديو حيوي وديناميكي فائق الدقة بدعم نموذج Google Veo (16:9 أو 9:16)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            title="إغلاق النافذة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          
          {/* Top Error Alert */}
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-rose-800 text-sm">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-bold">تنبيه أثناء المعالجة</p>
                <p className="text-xs text-rose-700 mt-1 leading-relaxed">{error}</p>
              </div>
              <button
                onClick={() => setError(null)}
                className="text-rose-500 hover:text-rose-700 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Success Drive Save Alert */}
          {saveSuccessMsg && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between gap-3 text-emerald-800 text-sm">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span className="font-medium">{saveSuccessMsg}</span>
              </div>
              {savedDriveFile?.webViewLink && (
                <a
                  href={savedDriveFile.webViewLink}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-xs font-bold text-emerald-700 hover:underline bg-emerald-100 px-3 py-1.5 rounded-lg"
                >
                  <span>عرض في Drive</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          )}

          {/* Main Grid: Preview & Controls */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left/Main Column: Visual Media Display (6 cols) */}
            <div className="lg:col-span-6 flex flex-col gap-4">
              
              {/* Media Container */}
              <div className="relative w-full rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-xl flex items-center justify-center min-h-[320px] max-h-[460px]">
                
                {/* Result Video View */}
                {generationResult ? (
                  <div className="relative w-full h-full flex items-center justify-center bg-black">
                    <video
                      ref={videoRef}
                      src={generationResult.videoUrl}
                      className={`w-full max-h-[440px] object-contain rounded-xl ${
                        aspectRatio === '9:16' ? 'max-w-[280px]' : 'w-full'
                      }`}
                      playsInline
                      autoPlay
                      loop={isLooping}
                      onPlay={() => setIsPlaying(true)}
                      onPause={() => setIsPlaying(false)}
                      onClick={togglePlay}
                    />

                    {/* Floating Controls Overlay */}
                    <div className="absolute bottom-3 inset-x-3 bg-slate-900/80 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/10 flex items-center justify-between text-white text-xs">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={togglePlay}
                          className="p-1.5 bg-white/20 hover:bg-white/30 rounded-lg transition-colors cursor-pointer"
                          title={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
                        >
                          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </button>

                        <button
                          onClick={() => {
                            if (videoRef.current) {
                              videoRef.current.currentTime = 0;
                              videoRef.current.play();
                              setIsPlaying(true);
                            }
                          }}
                          className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg transition-colors cursor-pointer"
                          title="إعادة من البداية"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => setIsLooping(!isLooping)}
                          className={`px-2 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer ${
                            isLooping ? 'bg-indigo-600 text-white' : 'bg-white/10 text-white/70'
                          }`}
                        >
                          تكرار تلقائي
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-slate-300 font-mono">
                          {aspectRatio === '16:9' ? '16:9 Landscape' : '9:16 Portrait'}
                        </span>
                        <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded text-[10px] font-bold">
                          HD Video
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Image Source Preview */
                  <div className="relative w-full h-full flex items-center justify-center p-2">
                    {imagePreview ? (
                      <div className="relative w-full h-full flex items-center justify-center">
                        <img
                          src={imagePreview}
                          alt="Source for Veo"
                          className={`max-h-[420px] object-contain rounded-xl transition-all ${
                            isGenerating ? 'brightness-75 scale-95' : 'brightness-100'
                          }`}
                        />

                        {/* Aspect Ratio Box Guide Overlay */}
                        <div
                          className={`absolute pointer-events-none border-2 border-dashed border-amber-400/60 rounded-xl transition-all ${
                            aspectRatio === '16:9' ? 'w-full aspect-[16/9] max-h-full' : 'h-full aspect-[9/16] max-w-full'
                          }`}
                        />
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center text-slate-500 p-8 text-center">
                        <ImageIcon className="w-12 h-12 stroke-[1.5] mb-2 text-slate-600" />
                        <p className="text-sm font-bold text-slate-400">لم يتم اختيار أي صورة بعد</p>
                        <p className="text-xs text-slate-600 mt-1">ارفع صورة من جهازك أو اختر صورة من Drive</p>
                      </div>
                    )}

                    {/* Active Scanning Wave during generation */}
                    {isGenerating && (
                      <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center text-white">
                        <div className="relative w-16 h-16 mb-4">
                          <div className="absolute inset-0 rounded-full border-4 border-amber-500/30 animate-ping" />
                          <div className="relative w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-rose-500/30 animate-spin">
                            <Film className="w-7 h-7 text-white" />
                          </div>
                        </div>

                        <h4 className="text-base font-bold mb-1 bg-gradient-to-r from-amber-300 via-rose-300 to-indigo-300 bg-clip-text text-transparent">
                          جاري توليد الفيديو عبر Google Veo...
                        </h4>
                        
                        <p className="text-xs text-slate-300 max-w-sm leading-relaxed mb-4">
                          {progressMessage}
                        </p>

                        {/* Progress Bar */}
                        <div className="w-full max-w-xs bg-white/10 rounded-full h-2.5 overflow-hidden mb-2 p-0.5 border border-white/20">
                          <div
                            className="bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-500 h-full rounded-full transition-all duration-500 ease-out"
                            style={{ width: `${progressPercent}%` }}
                          />
                        </div>

                        <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                          <span>{progressPercent}%</span>
                          <span>•</span>
                          <span>الوقت المنقضي: {elapsedSeconds} ثانية</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Image Source Action Bar */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs">
                <div className="flex items-center gap-2 truncate max-w-[240px]">
                  <ImageIcon className="w-4 h-4 text-slate-500 shrink-0" />
                  <span className="font-semibold text-slate-700 truncate" title={imageName}>
                    {imageName}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isGenerating}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl font-medium transition-all shadow-xs cursor-pointer disabled:opacity-50"
                  >
                    <Upload className="w-3.5 h-3.5 text-slate-500" />
                    <span>تغيير الصورة</span>
                  </button>

                  {generationResult && (
                    <button
                      onClick={() => setGenerationResult(null)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-medium transition-all cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>الصورة الأصلية</span>
                    </button>
                  )}
                </div>
              </div>

            </div>

            {/* Right Column: Generation Settings & Presets (6 cols) */}
            <div className="lg:col-span-6 space-y-5">
              
              {/* 1. Aspect Ratio Selection (Mandatory 16:9 or 9:16) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2.5">
                  1. نسبة العرض إلى الارتفاع (Aspect Ratio):
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setAspectRatio('16:9');
                      SoundEffects.playPop();
                    }}
                    className={`flex items-center gap-3 p-3 rounded-2xl border-2 transition-all cursor-pointer text-right ${
                      aspectRatio === '16:9'
                        ? 'border-indigo-600 bg-indigo-50/50 shadow-md shadow-indigo-500/10'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className={`w-9 h-6 rounded-md border-2 flex items-center justify-center font-mono text-[9px] font-bold ${
                      aspectRatio === '16:9' ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-400 text-slate-600'
                    }`}>
                      16:9
                    </div>
                    <div>
                      <p className={`font-bold text-xs ${aspectRatio === '16:9' ? 'text-indigo-900' : 'text-slate-800'}`}>
                        شاشة عريضة (16:9)
                      </p>
                      <p className="text-[10px] text-slate-500">لشاشات الحاسوب، يوتيوب والتلفاز</p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAspectRatio('9:16');
                      SoundEffects.playPop();
                    }}
                    className={`flex items-center gap-3 p-3 rounded-2xl border-2 transition-all cursor-pointer text-right ${
                      aspectRatio === '9:16'
                        ? 'border-indigo-600 bg-indigo-50/50 shadow-md shadow-indigo-500/10'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className={`w-6 h-9 rounded-md border-2 flex items-center justify-center font-mono text-[9px] font-bold ${
                      aspectRatio === '9:16' ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-400 text-slate-600'
                    }`}>
                      9:16
                    </div>
                    <div>
                      <p className={`font-bold text-xs ${aspectRatio === '9:16' ? 'text-indigo-900' : 'text-slate-800'}`}>
                        طولي عمودي (9:16)
                      </p>
                      <p className="text-[10px] text-slate-500">للهاتف، Stories، Reels وShorts</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* 2. Motion Presets */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-slate-700">
                    2. أسلوب وحركة الكاميرا (Motion Preset):
                  </label>
                  <span className="text-[11px] text-indigo-600 font-semibold">
                    جاهزة للتحريك الفوري
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {VEO_MOTION_PRESETS.map((preset) => {
                    const isSelected = selectedPreset === preset.id;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => handleSelectPreset(preset)}
                        className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'border-indigo-600 bg-gradient-to-br from-indigo-50 to-rose-50/30 shadow-xs'
                            : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/50'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className={`font-bold text-xs ${isSelected ? 'text-indigo-950' : 'text-slate-800'}`}>
                            {preset.title}
                          </span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />}
                        </div>
                        <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed">
                          {preset.description}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. Custom Prompt & Tweak */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-indigo-600" />
                    <span>3. نص التوجيه الحركي (Motion Prompt):</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setCustomPromptEnabled(!customPromptEnabled)}
                    className="text-[11px] text-slate-500 hover:text-indigo-600 underline cursor-pointer"
                  >
                    {customPromptEnabled ? 'إغلاق المحرر اليدوي' : 'تخصيص نص التوجيه'}
                  </button>
                </div>

                <textarea
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  disabled={isGenerating}
                  rows={2}
                  placeholder="اكتب تعليمات مخصصة لتحريك عناصر الصورة، مثلاً: تحريك أمواج البحر وسير السحب في السماء..."
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all disabled:opacity-60"
                />
              </div>

              {/* Generation Button */}
              <div>
                <button
                  type="button"
                  onClick={handleStartGeneration}
                  disabled={isGenerating || !imagePreview}
                  className="w-full py-3.5 px-6 bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 hover:from-amber-600 hover:via-rose-600 hover:to-indigo-700 text-white font-bold text-sm rounded-2xl shadow-lg shadow-rose-500/25 transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed hover:scale-[1.01] active:scale-[0.99]"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      <span>جاري المعالجة بواسطة Veo ({progressPercent}%)...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 animate-pulse" />
                      <span>
                        {generationResult ? 'إعادة توليد فيديو جديد' : 'توليد الفيديو الآن عبر Veo'}
                      </span>
                    </>
                  )}
                </button>
              </div>

              {/* Output Actions when Video is Generated */}
              {generationResult && (
                <div className="p-4 bg-gradient-to-r from-indigo-50 via-slate-50 to-rose-50 border border-indigo-100 rounded-2xl space-y-3 animate-fade-in">
                  <div className="flex items-center gap-2 text-indigo-950 font-bold text-xs">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>تم توليد الفيديو بجودة عالية! ماذا تريد أن تفعل به؟</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      onClick={handleDownloadVideo}
                      className="flex-1 min-w-[140px] flex items-center justify-center gap-2 py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>تنزيل MP4 على جهازك</span>
                    </button>

                    {onSaveVideoToDrive && (
                      <button
                        onClick={handleSaveToDrive}
                        disabled={isSavingToDrive}
                        className="flex-1 min-w-[140px] flex items-center justify-center gap-2 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-500/20 transition-all cursor-pointer disabled:opacity-50"
                      >
                        {isSavingToDrive ? (
                          <RefreshCw className="w-4 h-4 animate-spin" />
                        ) : (
                          <HardDrive className="w-4 h-4" />
                        )}
                        <span>
                          {isSavingToDrive ? 'جاري الحفظ في Drive...' : 'حفظ الفيديو في Google Drive'}
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              )}

            </div>

          </div>

        </div>

        {/* Footer */}
        <div className="p-4 px-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <Video className="w-4 h-4 text-amber-500" />
            <span>مدعوم بنموذج Google Veo الفائق للذكاء الاصطناعي التوليدي</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-200 border border-slate-200 rounded-xl font-bold text-slate-700 transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
