import React from 'react';
import { X, Keyboard, Command, Sparkles } from 'lucide-react';

interface KeyboardShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ShortcutItem {
  keys: string[];
  description: string;
  category: 'التنقل والبحث' | 'إدارة الملفات' | 'الإنشاء والرفع';
}

const SHORTCUTS: ShortcutItem[] = [
  { keys: ['/'], description: 'التركيز على شريط البحث المتقدم', category: 'التنقل والبحث' },
  { keys: ['Ctrl', 'K'], description: 'فتح البحث السريع', category: 'التنقل والبحث' },
  { keys: ['G'], description: 'التبديل بين طريقة العرض شبكة / جدول', category: 'التنقل والبحث' },
  { keys: ['Ctrl', 'B'], description: 'طي / توسيع القائمة الجانبية للتنقل', category: 'التنقل والبحث' },
  { keys: ['F'], description: 'تحليل محتوى المجلد بالذكاء الاصطناعي (AI)', category: 'التنقل والبحث' },
  { keys: ['Esc'], description: 'إغلاق النوافذ المنبثقة / إلغاء التحديد', category: 'التنقل والبحث' },
  { keys: ['?'], description: 'عرض قائمة اختصارات لوحة المفاتيح', category: 'التنقل والبحث' },

  { keys: ['Ctrl', 'A'], description: 'تحديد كافة الملفات المعروضة', category: 'إدارة الملفات' },
  { keys: ['F2'], description: 'إعادة التسمية الجماعية للملفات المحددة', category: 'إدارة الملفات' },
  { keys: ['Delete'], description: 'حذف أو نقل الملفات المحددة لسلة المهملات', category: 'إدارة الملفات' },
  
  { keys: ['U'], description: 'فتح نافذة رفع الملفات', category: 'الإنشاء والرفع' },
  { keys: ['N'], description: 'إنشاء مجلد جديد', category: 'الإنشاء والرفع' },
  { keys: ['D'], description: 'إنشاء مستند ذكي بالذكاء الاصطناعي', category: 'الإنشاء والرفع' },
];

export const KeyboardShortcutsModal: React.FC<KeyboardShortcutsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const categories = ['التنقل والبحث', 'إدارة الملفات', 'الإنشاء والرفع'] as const;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
              <Keyboard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                اختصارات لوحة المفاتيح
              </h2>
              <p className="text-xs text-slate-500">
                تحكم سريع واحترافي في كافة مهام Google Drive
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {categories.map((cat) => {
            const items = SHORTCUTS.filter((s) => s.category === cat);
            return (
              <div key={cat} className="space-y-2.5">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  {cat}
                </h3>
                <div className="bg-slate-50/70 border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden">
                  {items.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between px-4 py-2.5 hover:bg-slate-100/50 transition-colors"
                    >
                      <span className="text-xs font-medium text-slate-700">
                        {item.description}
                      </span>
                      <div className="flex items-center gap-1 ltr" dir="ltr">
                        {item.keys.map((k, ki) => (
                          <kbd
                            key={ki}
                            className="px-2 py-1 bg-white border border-slate-300 shadow-2xs rounded-lg text-[11px] font-mono font-bold text-slate-800"
                          >
                            {k}
                          </kbd>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            <span>يمكنك الضغط على مفتاح <kbd className="px-1.5 py-0.5 bg-white border rounded text-[10px] font-bold text-slate-700">?</kbd> في أي وقت لعرض هذه القائمة</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition-colors text-xs cursor-pointer"
          >
            فهمت
          </button>
        </div>
      </div>
    </div>
  );
};
