import React, { useState, useEffect } from 'react';
import {
  X,
  Palette,
  Check,
  Sparkles,
  Sliders,
  RotateCcw,
  Volume2,
  VolumeX,
  Sun,
  Layout,
  Layers,
  Folder,
  CheckCircle2,
  ArrowRight,
  Eye,
  SlidersHorizontal,
  FolderTree,
  FileText,
  BadgeCheck
} from 'lucide-react';
import {
  ACCENT_PRESETS,
  DEFAULT_THEME_PREFERENCES,
  ThemeService,
  UserThemePreferences,
  AccentThemePreset
} from '../services/themeService';
import { SoundEffects } from '../utils/audioChime';

interface ThemeSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPreferences: UserThemePreferences;
  onUpdatePreferences: (newPrefs: UserThemePreferences) => void;
}

export const ThemeSettingsModal: React.FC<ThemeSettingsModalProps> = ({
  isOpen,
  onClose,
  currentPreferences,
  onUpdatePreferences,
}) => {
  const [activeTab, setActiveTab] = useState<'accents' | 'appearance' | 'preview'>('accents');
  const [tempPrefs, setTempPrefs] = useState<UserThemePreferences>(currentPreferences);
  const [customHexInput, setCustomHexInput] = useState<string>(currentPreferences.customHex || '#3b82f6');
  const [isSavedRecently, setIsSavedRecently] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setTempPrefs(currentPreferences);
      setCustomHexInput(currentPreferences.customHex || '#3b82f6');
      setIsSavedRecently(false);
    }
  }, [isOpen, currentPreferences]);

  if (!isOpen) return null;

  const activePreset: AccentThemePreset = ThemeService.getActivePreset(tempPrefs);

  const handleSelectPreset = (presetId: string) => {
    SoundEffects.playPop();
    const updated: UserThemePreferences = {
      ...tempPrefs,
      accentId: presetId,
    };
    setTempPrefs(updated);
    onUpdatePreferences(updated);
    ThemeService.savePreferences(updated);
    triggerSavedFeedback();
  };

  const handleCustomHexChange = (hex: string) => {
    setCustomHexInput(hex);
    if (/^#[0-9A-Fa-f]{6}$/.test(hex)) {
      const updated: UserThemePreferences = {
        ...tempPrefs,
        accentId: 'custom',
        customHex: hex,
      };
      setTempPrefs(updated);
      onUpdatePreferences(updated);
      ThemeService.savePreferences(updated);
      triggerSavedFeedback();
    }
  };

  const handleRadiusChange = (radius: 'subtle' | 'standard' | 'pill') => {
    SoundEffects.playPop();
    const updated: UserThemePreferences = {
      ...tempPrefs,
      borderRadius: radius,
    };
    setTempPrefs(updated);
    onUpdatePreferences(updated);
    ThemeService.savePreferences(updated);
    triggerSavedFeedback();
  };

  const handleDensityChange = (density: 'comfortable' | 'compact') => {
    SoundEffects.playPop();
    const updated: UserThemePreferences = {
      ...tempPrefs,
      density: density,
    };
    setTempPrefs(updated);
    onUpdatePreferences(updated);
    ThemeService.savePreferences(updated);
    triggerSavedFeedback();
  };

  const handleToggleGlow = () => {
    SoundEffects.playPop();
    const updated: UserThemePreferences = {
      ...tempPrefs,
      enableGlow: !tempPrefs.enableGlow,
    };
    setTempPrefs(updated);
    onUpdatePreferences(updated);
    ThemeService.savePreferences(updated);
    triggerSavedFeedback();
  };

  const handleToggleSound = () => {
    const updated: UserThemePreferences = {
      ...tempPrefs,
      soundEffects: !tempPrefs.soundEffects,
    };
    setTempPrefs(updated);
    onUpdatePreferences(updated);
    ThemeService.savePreferences(updated);
    if (updated.soundEffects) {
      SoundEffects.playSuccess();
    }
    triggerSavedFeedback();
  };

  const handleResetToDefaults = () => {
    SoundEffects.playPop();
    setTempPrefs(DEFAULT_THEME_PREFERENCES);
    setCustomHexInput('#3b82f6');
    onUpdatePreferences(DEFAULT_THEME_PREFERENCES);
    ThemeService.savePreferences(DEFAULT_THEME_PREFERENCES);
    triggerSavedFeedback();
  };

  const triggerSavedFeedback = () => {
    setIsSavedRecently(true);
    setTimeout(() => {
      setIsSavedRecently(false);
    }, 2000);
  };

  // Quick custom color palettes
  const quickColors = [
    '#0284c7', // Sky Blue
    '#2563eb', // Indigo Blue
    '#059669', // Emerald
    '#10b981', // Mint
    '#7c3aed', // Purple
    '#9333ea', // Violet
    '#e11d48', // Crimson Rose
    '#ea580c', // Coral Orange
    '#d97706', // Golden Amber
    '#0891b2', // Deep Cyan
    '#475569', // Slate
    '#1e293b', // Midnight
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200/90 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center shadow-xs text-white transition-colors"
              style={{ backgroundColor: activePreset.primary }}
            >
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">تخصيص المظهر وألوان التمييز</h3>
                <span
                  className="text-[11px] font-semibold px-2 py-0.5 rounded-full border text-xs"
                  style={{
                    backgroundColor: activePreset.primaryLight,
                    borderColor: activePreset.primaryBorder,
                    color: activePreset.primaryText,
                  }}
                >
                  {activePreset.name}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                غيّر ألوان التطبيق وحواف العناصر ليناسب ذوقك الشخصي (تُحفظ التفضيلات تلقائياً)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetToDefaults}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 rounded-xl transition-colors cursor-pointer"
              title="استعادة الإعدادات الافتراضية للتطبيق"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">استعادة الافتراضي</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-xl transition-colors cursor-pointer"
              aria-label="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-100 bg-white">
          <button
            onClick={() => setActiveTab('accents')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'accents'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>لوحة ألوان التمييز (Accent Colors)</span>
          </button>

          <button
            onClick={() => setActiveTab('appearance')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'appearance'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>الحواف والمؤثرات (Layout & Effects)</span>
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'preview'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span>معاينة واجهة حية (Live Preview)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-slate-50/40">
          {/* TAB 1: Accent Colors */}
          {activeTab === 'accents' && (
            <div className="space-y-6">
              {/* Presets Grid */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    ألوان التمييز الجاهزة (Preset Palettes)
                  </h4>
                  <span className="text-xs text-slate-400 font-mono">
                    {ACCENT_PRESETS.length} خيارات متاحة
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {ACCENT_PRESETS.map((preset) => {
                    const isSelected = tempPrefs.accentId === preset.id;
                    return (
                      <button
                        key={preset.id}
                        onClick={() => handleSelectPreset(preset.id)}
                        className={`relative p-3.5 rounded-xl border text-right transition-all flex flex-col justify-between cursor-pointer group text-slate-800 bg-white ${
                          isSelected
                            ? 'border-slate-900 ring-2 ring-slate-900/10 shadow-md bg-gradient-to-b from-white to-slate-50/70'
                            : 'border-slate-200/80 hover:border-slate-300 hover:shadow-xs'
                        }`}
                      >
                        {/* Top: Color Swatch & Selection Indicator */}
                        <div className="flex items-center justify-between mb-2.5">
                          <div className="flex items-center gap-1.5">
                            <span
                              className="w-5 h-5 rounded-full shadow-xs border border-white flex items-center justify-center transition-transform group-hover:scale-110"
                              style={{ backgroundColor: preset.primary }}
                            />
                            <span
                              className="w-3.5 h-3.5 rounded-full shadow-xs opacity-70"
                              style={{ backgroundColor: preset.folderColor }}
                            />
                          </div>

                          {isSelected && (
                            <span
                              className="w-5 h-5 rounded-full text-white flex items-center justify-center shadow-xs text-xs animate-in zoom-in-75"
                              style={{ backgroundColor: preset.primary }}
                            >
                              <Check className="w-3 h-3 stroke-[3]" />
                            </span>
                          )}
                        </div>

                        {/* Middle: Title & Names */}
                        <div>
                          <p className="text-xs font-bold text-slate-900 group-hover:text-slate-950">
                            {preset.name}
                          </p>
                          <p className="text-[11px] text-slate-400 font-mono mb-1">
                            {preset.nameEn}
                          </p>
                          <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                            {preset.description}
                          </p>
                        </div>

                        {/* Bottom Accent Bar */}
                        <div
                          className="mt-2.5 h-1 w-full rounded-full transition-all"
                          style={{
                            backgroundColor: isSelected ? preset.primary : preset.primaryBorder,
                          }}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Custom Color Picker Section */}
              <div className="p-4 bg-white rounded-xl border border-slate-200/80 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles
                      className="w-4 h-4"
                      style={{ color: activePreset.primary }}
                    />
                    <h4 className="text-xs font-bold text-slate-800">
                      تخصيص لون يدوي (Custom HEX Color Picker)
                    </h4>
                  </div>
                  {tempPrefs.accentId === 'custom' && (
                    <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                      مفعّل حالياً
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-1">
                  {/* Color Native Input */}
                  <div className="flex items-center gap-2 border border-slate-200 rounded-xl p-1.5 bg-slate-50">
                    <input
                      type="color"
                      value={customHexInput}
                      onChange={(e) => handleCustomHexChange(e.target.value)}
                      className="w-8 h-8 rounded-lg cursor-pointer border-0 p-0 bg-transparent"
                      title="اختر درجة اللون الدقيقة"
                    />
                    <input
                      type="text"
                      value={customHexInput}
                      onChange={(e) => handleCustomHexChange(e.target.value)}
                      placeholder="#3b82f6"
                      className="w-24 text-xs font-mono font-bold text-slate-800 bg-white border border-slate-200 rounded-lg px-2 py-1 text-center uppercase focus:outline-hidden focus:ring-1 focus:ring-slate-400"
                    />
                  </div>

                  {/* Quick Color Swatches */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[11px] text-slate-400 ml-1">تدرجات سريعة:</span>
                    {quickColors.map((hex) => (
                      <button
                        key={hex}
                        onClick={() => handleCustomHexChange(hex)}
                        className={`w-6 h-6 rounded-full border-2 transition-transform hover:scale-110 cursor-pointer ${
                          tempPrefs.accentId === 'custom' && customHexInput.toLowerCase() === hex.toLowerCase()
                            ? 'border-slate-900 scale-110 shadow-xs'
                            : 'border-white shadow-xs'
                        }`}
                        style={{ backgroundColor: hex }}
                        title={hex}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Appearance & Layout */}
          {activeTab === 'appearance' && (
            <div className="space-y-6">
              {/* Border Radius Options */}
              <div className="p-4 bg-white rounded-xl border border-slate-200/80 shadow-xs space-y-3">
                <div className="flex items-center gap-2">
                  <Layout className="w-4 h-4 text-slate-600" />
                  <h4 className="text-xs font-bold text-slate-800">
                    استدارة حواف العناصر (Border Radius)
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  {[
                    { id: 'subtle' as const, label: 'حواف حادة ناعمة (8px)', desc: 'مظهر عملي ورسمي', sample: 'rounded-md' },
                    { id: 'standard' as const, label: 'حواف قياسية (12px)', desc: 'التصميم الكلاسيكي المتوازن', sample: 'rounded-xl' },
                    { id: 'pill' as const, label: 'حواف دائرية (18px)', desc: 'مظهر عصري حديث', sample: 'rounded-2xl' },
                  ].map((rad) => {
                    const isSelected = tempPrefs.borderRadius === rad.id;
                    return (
                      <button
                        key={rad.id}
                        onClick={() => handleRadiusChange(rad.id)}
                        className={`p-3.5 border text-right rounded-xl transition-all cursor-pointer ${
                          isSelected
                            ? 'border-slate-900 ring-2 ring-slate-900/10 bg-slate-50 shadow-xs'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div
                            className={`w-8 h-8 border-2 border-slate-400 bg-slate-100 ${rad.sample}`}
                          />
                          {isSelected && <Check className="w-4 h-4 text-slate-900" />}
                        </div>
                        <p className="text-xs font-bold text-slate-800">{rad.label}</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">{rad.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Density Options */}
              <div className="p-4 bg-white rounded-xl border border-slate-200/80 shadow-xs space-y-3">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-slate-600" />
                  <h4 className="text-xs font-bold text-slate-800">
                    كثافة العرض والمسافات (Layout Density)
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {[
                    { id: 'comfortable' as const, label: 'عرض مريح (Comfortable)', desc: 'مسافات واسعة ومريحة لتصفح سهل وبديهي' },
                    { id: 'compact' as const, label: 'عرض مدمج (Compact)', desc: 'مسافات أصغر لعرض أكبر عدد ممكن من الملفات في الشاشة' },
                  ].map((dens) => {
                    const isSelected = tempPrefs.density === dens.id;
                    return (
                      <button
                        key={dens.id}
                        onClick={() => handleDensityChange(dens.id)}
                        className={`p-3.5 border text-right rounded-xl transition-all cursor-pointer ${
                          isSelected
                            ? 'border-slate-900 ring-2 ring-slate-900/10 bg-slate-50 shadow-xs'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <p className="text-xs font-bold text-slate-800">{dens.label}</p>
                          {isSelected && <Check className="w-4 h-4 text-slate-900" />}
                        </div>
                        <p className="text-[11px] text-slate-500 leading-relaxed">{dens.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Extra Toggles: Glow & Sound */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Glow Toggle */}
                <div className="p-4 bg-white rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
                  <div>
                    <p className="text-xs font-bold text-slate-800">توهج الأزرار النشطة (Accent Glow)</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      إضافة ظل لوني خفيف يعكس لون التمييز
                    </p>
                  </div>
                  <button
                    onClick={handleToggleGlow}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      tempPrefs.enableGlow ? 'bg-slate-900' : 'bg-slate-200'
                    }`}
                  >
                    <span
                      className={`block w-4 h-4 rounded-full bg-white transition-transform ${
                        tempPrefs.enableGlow ? 'translate-x-1' : 'translate-x-6'
                      }`}
                    />
                  </button>
                </div>

                {/* Sound Toggle */}
                <div className="p-4 bg-white rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {tempPrefs.soundEffects ? (
                      <Volume2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-slate-400" />
                    )}
                    <div>
                      <p className="text-xs font-bold text-slate-800">التأثيرات الصوتية (Sound Chimes)</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        أصوات ناعمة عند النقر وإكمال المهام
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleToggleSound}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      tempPrefs.soundEffects ? 'bg-slate-900' : 'bg-slate-200'
                    }`}
                  >
                    <span
                      className={`block w-4 h-4 rounded-full bg-white transition-transform ${
                        tempPrefs.soundEffects ? 'translate-x-1' : 'translate-x-6'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Live Preview */}
          {activeTab === 'preview' && (
            <div className="space-y-4">
              <div className="p-4 bg-white rounded-xl border border-slate-200/80 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-800">
                    معاينة حية للمكونات بلون التمييز: {activePreset.name}
                  </h4>
                  <span
                    className="text-xs font-mono font-bold px-2 py-0.5 rounded-full"
                    style={{
                      backgroundColor: activePreset.primaryLight,
                      color: activePreset.primaryText,
                    }}
                  >
                    {activePreset.primary}
                  </span>
                </div>

                {/* Mock UI Showcase */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70 space-y-4">
                  {/* Buttons Row */}
                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      className="px-4 py-2 text-xs font-bold text-white rounded-xl shadow-sm transition-all cursor-pointer"
                      style={{
                        backgroundColor: activePreset.primary,
                        boxShadow: tempPrefs.enableGlow
                          ? `0 4px 14px ${activePreset.ringColor}`
                          : undefined,
                      }}
                    >
                      زر رئيسي ملوّن (Primary Action)
                    </button>

                    <button
                      className="px-4 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer"
                      style={{
                        borderColor: activePreset.primaryBorder,
                        backgroundColor: activePreset.primaryLight,
                        color: activePreset.primaryText,
                      }}
                    >
                      زر فرعي مميّز (Soft Accent)
                    </button>

                    <span
                      className="px-3 py-1.5 text-xs font-bold rounded-xl border flex items-center gap-1.5"
                      style={{
                        backgroundColor: activePreset.primaryLight,
                        borderColor: activePreset.primaryBorder,
                        color: activePreset.primaryText,
                      }}
                    >
                      <BadgeCheck className="w-3.5 h-3.5" />
                      شارة حالة مفعلة (Active Badge)
                    </span>
                  </div>

                  {/* Sample Mock File Card */}
                  <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center"
                        style={{ backgroundColor: activePreset.primaryLight }}
                      >
                        <Folder
                          className="w-5 h-5"
                          style={{ color: activePreset.folderColor }}
                        />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800">
                          مجلد وثائق ومشاريع العام 2026
                        </p>
                        <p className="text-[11px] text-slate-400">14 ملف • تم التعديل منذ ساعة</p>
                      </div>
                    </div>
                    <span
                      className="text-[11px] font-bold px-2 py-1 rounded-lg"
                      style={{
                        backgroundColor: activePreset.primaryLight,
                        color: activePreset.primaryText,
                      }}
                    >
                      مجلد مخصص
                    </span>
                  </div>

                  {/* Sample Active Selection Bar */}
                  <div
                    className="p-3 rounded-xl border flex items-center justify-between"
                    style={{
                      backgroundColor: activePreset.primaryLight,
                      borderColor: activePreset.primaryBorder,
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <CheckCircle2
                        className="w-4 h-4"
                        style={{ color: activePreset.primary }}
                      />
                      <span
                        className="text-xs font-bold"
                        style={{ color: activePreset.primaryText }}
                      >
                        تم تحديد 3 عناصر للنسخ الاحتياطي أو النقل
                      </span>
                    </div>
                    <span
                      className="text-xs font-bold px-3 py-1 text-white rounded-lg"
                      style={{ backgroundColor: activePreset.primary }}
                    >
                      تأكيد الإجراء
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-100 bg-white">
          <div className="flex items-center gap-2">
            {isSavedRecently && (
              <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 animate-in fade-in duration-200">
                <Check className="w-3.5 h-3.5" />
                <span>تم حفظ التفضيلات وتطبيقها بنجاح</span>
              </span>
            )}
            {!isSavedRecently && (
              <span className="text-xs text-slate-400">
                يتم حفظ كل التغييرات تلقائياً في ذاكرة المتصفح (localStorage)
              </span>
            )}
          </div>

          <button
            onClick={() => {
              SoundEffects.playSuccess();
              onClose();
            }}
            className="px-5 py-2 text-xs font-bold text-white rounded-xl shadow-sm transition-all cursor-pointer"
            style={{
              backgroundColor: activePreset.primary,
              boxShadow: tempPrefs.enableGlow
                ? `0 4px 14px ${activePreset.ringColor}`
                : undefined,
            }}
          >
            إغلاق وحفظ
          </button>
        </div>
      </div>
    </div>
  );
};
