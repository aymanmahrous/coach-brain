import React, { useState } from 'react';
import { 
  CheckCircle2, 
  ExternalLink, 
  Copy, 
  Check, 
  X, 
  ShieldCheck, 
  FileCheck, 
  Clock, 
  Download, 
  Share2, 
  Facebook, 
  Instagram, 
  Sparkles,
  Key
} from 'lucide-react';

export interface PublishingReceipt {
  receiptId: string;
  postId: string;
  title: string;
  platform: string;
  publishedAt: string;
  author: string;
  branch: string;
  facebookPostId?: string;
  facebookUrl?: string;
  instagramPostId?: string;
  instagramUrl?: string;
  mediaHash: string;
  status: 'published_live' | 'verified_by_meta';
  signature: string;
  tokenFingerprint: string;
  safePublisherVersion: string;
  summary: string;
  rawMetaResponse?: any;
}

interface PublishingReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  receipt: PublishingReceipt | null;
}

export const PublishingReceiptModal: React.FC<PublishingReceiptModalProps> = ({
  isOpen,
  onClose,
  receipt
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen || !receipt) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleDownloadReceipt = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(receipt, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${receipt.receiptId}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const formattedDate = new Date(receipt.publishedAt).toLocaleString('ar-AE', {
    timeZone: 'Asia/Dubai',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="bg-[#07131e] border-2 border-emerald-500/40 rounded-3xl max-w-2xl w-full p-6 text-white shadow-2xl relative overflow-hidden"
        dir="rtl"
      >
        {/* Glow ambient background */}
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-emerald-950/80 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-500/25 shrink-0">
              <CheckCircle2 className="w-7 h-7 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-white">إيصال توثيق النشر الرسمي (Meta Live Receipt)</h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold">
                  {receipt.safePublisherVersion || 'Version 27 — ACTIVE'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                تم اعتماد ونشر المنشور بنجاح عبر المسار الخادمي الآمن وربطه مع Meta Graph API
              </p>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="py-4 space-y-4 max-h-[75vh] overflow-y-auto pr-1">
          
          {/* Post Title & Status Banner */}
          <div className="bg-gradient-to-r from-emerald-950/40 via-[#0a1b2a] to-[#0a1827] border border-emerald-800/40 rounded-2xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <span className="text-xs font-bold text-slate-300">عنوان المنشور المعتمد:</span>
              <span className="text-[11px] bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 px-2.5 py-0.5 rounded-lg font-bold">
                {receipt.platform}
              </span>
            </div>
            <h4 className="text-sm font-extrabold text-white leading-snug">
              {receipt.title}
            </h4>
            <div className="flex items-center gap-4 text-xs text-slate-300 mt-2">
              <span>الفرع: <strong className="text-cyan-400">{receipt.branch}</strong></span>
              <span>•</span>
              <span>المسؤول: <strong className="text-emerald-400">{receipt.author}</strong></span>
            </div>
          </div>

          {/* Facebook Post Direct Link & ID */}
          {receipt.facebookPostId && (
            <div className="bg-[#050f18] border border-blue-900/60 rounded-2xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-blue-400 font-bold text-xs">
                  <Facebook className="w-4 h-4 fill-blue-500" />
                  <span>معرف المنشور على فيسبوك (Facebook Post ID):</span>
                </div>
                <span className="text-[10px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-md font-mono">
                  Live on Graph API
                </span>
              </div>

              <div className="flex items-center justify-between bg-[#081522] border border-blue-900/40 rounded-xl px-3 py-2 text-xs font-mono text-slate-200">
                <span className="truncate">{receipt.facebookPostId}</span>
                <button
                  onClick={() => handleCopy(receipt.facebookPostId!, 'fb-id')}
                  className="mr-2 text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 shrink-0"
                >
                  {copiedKey === 'fb-id' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'fb-id' ? 'تم النسخ' : 'نسخ'}</span>
                </button>
              </div>

              {receipt.facebookUrl && (
                <div className="pt-1 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">رابط المنشور المباشر على فيسبوك:</span>
                  <a
                    href={receipt.facebookUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-600/25 transition-all"
                  >
                    <span>فتح المنشور على فيسبوك</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>
          )}

          {/* Instagram Post Link & ID */}
          {receipt.instagramPostId && (
            <div className="bg-[#050f18] border border-pink-900/60 rounded-2xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-pink-400 font-bold text-xs">
                  <Instagram className="w-4 h-4" />
                  <span>معرف منشور إنستغرام (Instagram Media ID):</span>
                </div>
                <span className="text-[10px] bg-pink-500/20 text-pink-300 px-2 py-0.5 rounded-md font-mono">
                  Instagram Business
                </span>
              </div>

              <div className="flex items-center justify-between bg-[#081522] border border-pink-900/40 rounded-xl px-3 py-2 text-xs font-mono text-slate-200">
                <span className="truncate">{receipt.instagramPostId}</span>
                <button
                  onClick={() => handleCopy(receipt.instagramPostId!, 'ig-id')}
                  className="mr-2 text-xs text-pink-400 hover:text-pink-300 flex items-center gap-1 shrink-0"
                >
                  {copiedKey === 'ig-id' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'ig-id' ? 'تم النسخ' : 'نسخ'}</span>
                </button>
              </div>

              {receipt.instagramUrl && (
                <div className="pt-1 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">رابط المنشور المباشر على إنستغرام:</span>
                  <a
                    href={receipt.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white rounded-xl text-xs font-bold shadow-md transition-all"
                  >
                    <span>فتح على إنستغرام</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>
          )}

          {/* Audit & Security Details Grid */}
          <div className="bg-[#061019] border border-cyan-950 rounded-2xl p-4 space-y-2 text-xs">
            <div className="text-xs font-bold text-cyan-300 mb-2 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>سجل التحقق والبيانات الأمنية (Audit Trail):</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-[11px]">
              <div className="flex items-center justify-between p-2 rounded-lg bg-[#091522] border border-slate-800">
                <span className="text-slate-400">رقم الإيصال:</span>
                <span className="font-mono text-cyan-300 font-bold">{receipt.receiptId}</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-lg bg-[#091522] border border-slate-800">
                <span className="text-slate-400">وقت النشر الدقيق:</span>
                <span className="font-mono text-slate-200">{formattedDate}</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-lg bg-[#091522] border border-slate-800">
                <span className="text-slate-400">حالة المسار الخادمي:</span>
                <span className="text-emerald-400 font-bold">RLS Bypassed via Service Role</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-lg bg-[#091522] border border-slate-800">
                <span className="text-slate-400">بصمة التوكن:</span>
                <span className="font-mono text-slate-300 text-[10px]">{receipt.tokenFingerprint}</span>
              </div>
            </div>

            <div className="mt-2 p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-800/40 text-[11px] text-emerald-300 leading-relaxed">
              ✓ {receipt.summary}
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-emerald-950/80 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={handleDownloadReceipt}
            className="px-4 py-2 bg-[#0d1e2e] hover:bg-[#13283c] text-cyan-300 text-xs font-bold rounded-xl border border-cyan-800/60 flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تحميل الإيصال (JSON)</span>
          </button>

          <div className="flex items-center gap-2">
            {receipt.facebookUrl && (
              <button
                onClick={() => handleCopy(receipt.facebookUrl!, 'fb-url')}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copiedKey === 'fb-url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'fb-url' ? 'تم نسخ الرابط' : 'نسخ رابط المنشور'}</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer"
            >
              تم وموافق
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
