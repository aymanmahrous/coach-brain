import React from 'react';
import { 
  Bell, 
  Clock, 
  Check, 
  ExternalLink, 
  X, 
  AlertTriangle,
  Sparkles,
  ArrowLeft
} from 'lucide-react';
import { FileReminder, DriveFile } from '../types';
import { ReminderService } from '../services/reminderService';
import { NotificationService } from '../services/notificationService';

interface ReminderNotificationBannerProps {
  dueReminders: FileReminder[];
  onOpenFile: (fileId: string) => void;
  onMarkComplete: (reminderId: string) => void;
  onDismiss: (reminderId: string) => void;
  onOpenReminderList: () => void;
}

export const ReminderNotificationBanner: React.FC<ReminderNotificationBannerProps> = ({
  dueReminders,
  onOpenFile,
  onMarkComplete,
  onDismiss,
  onOpenReminderList,
}) => {
  if (!dueReminders || dueReminders.length === 0) return null;

  const current = dueReminders[0];
  const isMultiple = dueReminders.length > 1;

  const priorityColor = 
    current.priority === 'high' 
      ? 'border-rose-300 bg-gradient-to-r from-rose-50 to-amber-50 text-rose-950 shadow-rose-500/10'
      : 'border-amber-300 bg-gradient-to-r from-amber-50 via-orange-50/50 to-yellow-50 text-amber-950 shadow-amber-500/10';

  const badgeColor = 
    current.priority === 'high'
      ? 'bg-rose-600 text-white'
      : 'bg-amber-500 text-white';

  return (
    <div
      id="in-app-reminder-alert"
      className="fixed bottom-5 left-5 z-50 max-w-md w-full animate-in slide-in-from-bottom-5 duration-300 pointer-events-auto select-none"
    >
      <div className={`p-4 rounded-3xl border shadow-2xl backdrop-blur-md flex flex-col gap-2.5 ${priorityColor}`}>
        {/* Top bar */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="relative">
              <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-white shadow-xs text-amber-600">
                <Bell className="h-4 w-4 animate-bounce" />
              </span>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black">حان موعد التذكير!</span>
                <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${badgeColor}`}>
                  {current.priority === 'high' ? 'أهمية قصوى' : 'تذكير مستحق'}
                </span>
              </div>
              <span className="text-[10px] text-slate-500">
                {ReminderService.formatReminderDate(current.remindAt)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {isMultiple && (
              <button
                onClick={onOpenReminderList}
                className="text-[11px] font-bold text-blue-700 bg-white/80 hover:bg-white px-2 py-0.5 rounded-lg border border-blue-200/60 shadow-2xs cursor-pointer"
              >
                +{dueReminders.length - 1} تذكيرات أخرى
              </button>
            )}
            <button
              onClick={() => onDismiss(current.id)}
              className="p-1 text-slate-400 hover:text-slate-700 hover:bg-black/5 rounded-lg transition-colors cursor-pointer"
              title="إغلاق التنبيه"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Details */}
        <div className="bg-white/90 rounded-2xl p-2.5 border border-white/80 shadow-2xs">
          <p className="text-xs font-extrabold text-slate-900 truncate" title={current.fileName}>
            📄 {current.fileName}
          </p>
          {current.note && (
            <p className="text-[11px] text-slate-600 mt-1 font-medium bg-slate-50 p-1.5 rounded-lg border border-slate-100">
              💡 {current.note}
            </p>
          )}
        </div>

        {/* Desktop Notification Enablement Prompt if not granted yet */}
        {NotificationService.isSupported() && NotificationService.getPermission() === 'default' && (
          <div className="flex items-center justify-between gap-2 px-2.5 py-1.5 bg-blue-50/80 rounded-xl border border-blue-200/60 text-[11px] text-blue-900">
            <span className="truncate">تلقي هذا التنبيه على سطح المكتب حتى عند إغلاق التبويب؟</span>
            <button
              onClick={async () => {
                await NotificationService.requestPermission();
              }}
              className="px-2 py-0.5 bg-blue-600 text-white rounded-lg font-bold text-[10px] hover:bg-blue-700 transition-colors shrink-0 cursor-pointer"
            >
              تفعيل إشعار سطح المكتب
            </button>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2 pt-1">
          <button
            onClick={() => onDismiss(current.id)}
            className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-black/5 rounded-xl transition-colors cursor-pointer"
          >
            لاحقاً
          </button>
          
          <button
            onClick={() => onMarkComplete(current.id)}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-emerald-700 bg-emerald-100/80 hover:bg-emerald-200 border border-emerald-300/60 rounded-xl transition-all cursor-pointer shadow-2xs"
          >
            <Check className="w-3.5 h-3.5" />
            <span>تم الإنجاز</span>
          </button>

          <button
            onClick={() => onOpenFile(current.fileId)}
            className="flex items-center gap-1 px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md shadow-blue-500/20 transition-all cursor-pointer"
          >
            <span>فتح الملف</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
