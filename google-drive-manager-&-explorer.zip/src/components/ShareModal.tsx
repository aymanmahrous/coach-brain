import React, { useState, useEffect } from 'react';
import { 
  X, 
  Share2, 
  UserPlus, 
  Mail, 
  Eye, 
  MessageSquare, 
  Edit3, 
  ShieldCheck, 
  Check, 
  Copy, 
  Trash2, 
  Loader2, 
  AlertCircle, 
  Users,
  Send,
  Lock,
  Globe
} from 'lucide-react';
import { DriveFile, DrivePermission, DrivePermissionRole, ShareFileRequest } from '../types';
import { DriveService, getFileTypeMeta } from '../services/driveService';

interface ShareModalProps {
  file: DriveFile | null;
  isOpen: boolean;
  onClose: () => void;
  token: string | null;
  onShareSuccess?: (fileId: string, email: string, role: DrivePermissionRole) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  file,
  isOpen,
  onClose,
  token,
  onShareSuccess,
}) => {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<'reader' | 'commenter' | 'writer'>('reader');
  const [message, setMessage] = useState('');
  const [sendNotification, setSendNotification] = useState(true);
  
  const [permissions, setPermissions] = useState<DrivePermission[]>([]);
  const [isLoadingPermissions, setIsLoadingPermissions] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [modifyingPermId, setModifyingPermId] = useState<string | null>(null);

  // Load permissions when modal opens with a file
  useEffect(() => {
    if (!isOpen || !file) {
      setEmail('');
      setMessage('');
      setActionError(null);
      setSuccessMsg(null);
      setPermissions([]);
      return;
    }

    let isMounted = true;
    setIsLoadingPermissions(true);
    setActionError(null);

    DriveService.getFilePermissions(token, file.id, file)
      .then((perms) => {
        if (isMounted) {
          setPermissions(perms);
        }
      })
      .catch((err) => {
        if (isMounted) {
          console.warn('Error loading permissions:', err);
        }
      })
      .finally(() => {
        if (isMounted) {
          setIsLoadingPermissions(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, file, token]);

  if (!isOpen || !file) return null;

  const meta = getFileTypeMeta(file.mimeType);

  const handleShareSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      setActionError('يرجى كتابة بريد إلكتروني صحيح ومكتمل.');
      return;
    }

    setIsSubmitting(true);
    setActionError(null);
    setSuccessMsg(null);

    try {
      const request: ShareFileRequest = {
        emailAddress: email.trim(),
        role,
        sendNotificationEmail: sendNotification,
        message: message.trim() || undefined,
      };

      const newPerm = await DriveService.shareFile(token, file.id, request);
      
      setSuccessMsg(`تمت مشاركة "${file.name}" مع ${email} بصلاحية (${getRoleLabel(role)}) بنجاح.`);
      setEmail('');
      setMessage('');

      // Refresh permissions list
      const updated = await DriveService.getFilePermissions(token, file.id, file);
      setPermissions(updated);

      if (onShareSuccess) {
        onShareSuccess(file.id, request.emailAddress, role);
      }
    } catch (err: any) {
      console.error('Share error:', err);
      setActionError(err.message || 'حدث خطأ أثناء محاولة المشاركة. يرجى التحقق من البريد الإلكتروني.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRoleChange = async (permId: string, newRole: DrivePermissionRole) => {
    if (newRole === 'owner') return;
    setModifyingPermId(permId);
    setActionError(null);

    try {
      await DriveService.updateFilePermission(token, file.id, permId, newRole);
      const updated = await DriveService.getFilePermissions(token, file.id, file);
      setPermissions(updated);
      setSuccessMsg('تم تحديث صلاحية الوصول بنجاح.');
    } catch (err: any) {
      setActionError(err.message || 'فشل تحديث الصلاحية.');
    } finally {
      setModifyingPermId(null);
    }
  };

  const handleRemovePermission = async (permId: string, userEmail?: string) => {
    const confirm = window.confirm(`هل أنت متأكد من إزالة حق الوصول للمستخدم (${userEmail || 'المحدد'})؟`);
    if (!confirm) return;

    setModifyingPermId(permId);
    setActionError(null);

    try {
      await DriveService.removeFilePermission(token, file.id, permId);
      const updated = await DriveService.getFilePermissions(token, file.id, file);
      setPermissions(updated);
      setSuccessMsg('تمت إزالة صلاحية الوصول.');
    } catch (err: any) {
      setActionError(err.message || 'فشل حذف الصلاحية.');
    } finally {
      setModifyingPermId(null);
    }
  };

  const handleCopyLink = () => {
    const link = file.webViewLink || `https://drive.google.com/file/d/${file.id}/view`;
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const getRoleLabel = (r: DrivePermissionRole) => {
    switch (r) {
      case 'owner': return 'المالك';
      case 'writer': return 'تعديل (محرر)';
      case 'commenter': return 'تعليق (معلق)';
      case 'reader': return 'عرض فقط (عارض)';
      default: return r;
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/80">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 shrink-0">
              <Share2 className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base font-bold text-slate-900 truncate">
                مشاركة «{file.name}»
              </h2>
              <p className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                <span className={`px-1.5 py-0.2 rounded border font-semibold text-[10px] ${meta.color}`}>
                  {meta.label}
                </span>
                <span>تحديد صلاحيات الوصول والمستخدمين</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-full transition-colors shrink-0"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex flex-col gap-6">
          {/* Alerts / Feedback Messages */}
          {actionError && (
            <div className="flex items-start gap-2.5 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl text-xs animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <div className="flex-1 font-medium">{actionError}</div>
            </div>
          )}

          {successMsg && (
            <div className="flex items-start gap-2.5 p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs animate-in fade-in">
              <Check className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
              <div className="flex-1 font-medium">{successMsg}</div>
            </div>
          )}

          {/* Add People Section */}
          <form onSubmit={handleShareSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                إضافة مستخدمين ومجموعات
              </label>
              
              {/* Input row: Email + Role Selector */}
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <Mail className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    id="share-email-input"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="أدخل البريد الإلكتروني (مثال: colleague@gmail.com)..."
                    className="w-full pr-10 pl-3 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 rounded-xl text-xs text-slate-800 outline-none transition-all placeholder-slate-400 focus:ring-4 focus:ring-blue-500/10"
                    required
                  />
                </div>

                {/* Role Selector */}
                <div className="sm:w-36">
                  <select
                    id="share-role-select"
                    value={role}
                    onChange={(e) => setRole(e.target.value as any)}
                    className="w-full py-2.5 px-3 bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 rounded-xl text-xs font-bold text-slate-800 outline-none transition-all cursor-pointer"
                  >
                    <option value="reader">👁️ عرض (عارض)</option>
                    <option value="commenter">💬 تعليق (معلق)</option>
                    <option value="writer">✏️ تعديل (محرر)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Role Explanations Banner */}
            <div className="p-3 bg-blue-50/60 border border-blue-100 rounded-2xl">
              <div className="text-[11px] font-semibold text-blue-900 flex items-center gap-1.5 mb-1">
                {role === 'reader' && <Eye className="w-3.5 h-3.5 text-blue-600" />}
                {role === 'commenter' && <MessageSquare className="w-3.5 h-3.5 text-blue-600" />}
                {role === 'writer' && <Edit3 className="w-3.5 h-3.5 text-blue-600" />}
                <span>
                  {role === 'reader' && 'صلاحية العرض: يستطيع المستخدم فقط الاطلاع وتنزيل الملف.'}
                  {role === 'commenter' && 'صلاحية التعليق: يستطيع كتابة واقتراح تعليقات دون تغيير المحتوى.'}
                  {role === 'writer' && 'صلاحية التعديل: يمتلك حق تحرير المحتوى، الحفظ، وإعادة التنظيم.'}
                </span>
              </div>
            </div>

            {/* Optional Notification Message */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                رسالة مخصصة (اختياري)
              </label>
              <textarea
                id="share-message-input"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={2}
                placeholder="أضف ملاحظة أو سياقاً للمستلم..."
                className="w-full p-2.5 bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 rounded-xl text-xs text-slate-800 outline-none transition-all placeholder-slate-400 focus:ring-4 focus:ring-blue-500/10 resize-none"
              />
            </div>

            {/* Send email checkbox & Submit button */}
            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-600 font-medium">
                <input
                  type="checkbox"
                  checked={sendNotification}
                  onChange={(e) => setSendNotification(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <span>إرسال إشعار بريدي للمستلم</span>
              </label>

              <button
                type="submit"
                disabled={isSubmitting || !email.trim()}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-sm hover:shadow transition-all flex items-center gap-2 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>جارٍ الإرسال...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>مشاركة الملف</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Active Collaborators Section */}
          <div className="border-t border-slate-100 pt-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-slate-600" />
                <h3 className="text-xs font-bold text-slate-800">
                  من لديهم حق الوصول ({permissions.length})
                </h3>
              </div>
              {isLoadingPermissions && (
                <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  <span>تحديث الصلاحيات...</span>
                </div>
              )}
            </div>

            <div className="space-y-2">
              {permissions.map((perm) => {
                const isOwner = perm.role === 'owner';
                const isModifying = modifyingPermId === perm.id;

                return (
                  <div
                    key={perm.id}
                    className="flex items-center justify-between p-3 rounded-2xl bg-slate-50/70 border border-slate-100 hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-slate-200/80 border border-slate-300/60 flex items-center justify-center text-xs font-bold text-slate-700 shrink-0">
                        {perm.photoLink ? (
                          <img 
                            src={perm.photoLink} 
                            alt={perm.displayName || perm.emailAddress || 'User'} 
                            referrerPolicy="no-referrer"
                            className="w-full h-full rounded-full object-cover"
                          />
                        ) : (
                          (perm.displayName || perm.emailAddress || 'U').charAt(0).toUpperCase()
                        )}
                      </div>

                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-800 truncate flex items-center gap-1.5">
                          <span>{perm.displayName || perm.emailAddress?.split('@')[0]}</span>
                          {isOwner && (
                            <span className="text-[10px] px-1.5 py-0.2 bg-amber-50 text-amber-700 border border-amber-200 rounded font-semibold">
                              المالك
                            </span>
                          )}
                        </div>
                        {perm.emailAddress && (
                          <div className="text-[11px] text-slate-500 truncate">
                            {perm.emailAddress}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Role selector or label */}
                    <div className="flex items-center gap-2 shrink-0">
                      {isOwner ? (
                        <span className="text-xs font-bold text-slate-500 px-2 py-1 bg-slate-100 rounded-lg">
                          المالك
                        </span>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <select
                            disabled={isModifying}
                            value={perm.role}
                            onChange={(e) => handleRoleChange(perm.id, e.target.value as DrivePermissionRole)}
                            className="text-xs py-1 px-2 rounded-lg bg-white border border-slate-200 font-semibold text-slate-700 outline-none focus:border-blue-500 cursor-pointer disabled:opacity-50"
                          >
                            <option value="reader">عرض (عارض)</option>
                            <option value="commenter">تعليق (معلق)</option>
                            <option value="writer">تعديل (محرر)</option>
                          </select>

                          <button
                            disabled={isModifying}
                            onClick={() => handleRemovePermission(perm.id, perm.emailAddress)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors disabled:opacity-50"
                            title="إزالة حق الوصول"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            onClick={handleCopyLink}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-blue-700 hover:bg-blue-100/60 bg-blue-50 border border-blue-200 rounded-xl transition-colors cursor-pointer"
          >
            {copiedLink ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700">تم نسخ الرابط!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>نسخ رابط المشاركة</span>
              </>
            )}
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            تم
          </button>
        </div>
      </div>
    </div>
  );
};
