import React, { useState } from 'react';
import { 
  Folder, 
  FileText, 
  Table, 
  Presentation, 
  FileCheck, 
  File, 
  Image as ImageIcon, 
  Video, 
  Music, 
  Star, 
  MoreVertical, 
  ExternalLink, 
  Sparkles, 
  Trash2, 
  Edit3, 
  RotateCcw,
  Receipt,
  BarChart3,
  Rocket,
  FileCheck2,
  GraduationCap,
  Palette,
  FolderGit2,
  Bell,
  Clock,
  CheckCircle2,
  Share2,
  ScanText,
  Film,
  Archive,
  Send
} from 'lucide-react';
import { DriveFile, AICategoryClassification, AICategoryKey, FileReminder } from '../types';
import { formatBytes, formatDate, getFileTypeMeta } from '../services/driveService';
import { AI_CATEGORIES } from '../services/aiCategorizeService';
import { ReminderService } from '../services/reminderService';
import { OCRService } from '../services/ocrService';
import { VeoService } from '../services/veoService';

interface FileCardProps {
  file: DriveFile;
  onOpen: (file: DriveFile) => void;
  onStarToggle: (file: DriveFile) => void;
  onDelete: (file: DriveFile) => void;
  onRestore?: (file: DriveFile) => void;
  onRename: (file: DriveFile) => void;
  onAIAnalyze: (file: DriveFile) => void;
  onShare?: (file: DriveFile) => void;
  onOCR?: (file: DriveFile) => void;
  onVeoAnimate?: (file: DriveFile) => void;
  onBackupFolder?: (folder: DriveFile) => void;
  onSendToAutomation?: (file: DriveFile) => void;
  isTrashView?: boolean;
  aiClassification?: AICategoryClassification;
  onSelectAICategory?: (catKey: AICategoryKey) => void;
  reminder?: FileReminder;
  onSetReminder?: (file: DriveFile) => void;
  isSelected?: boolean;
  onToggleSelect?: (file: DriveFile) => void;
  selectionActive?: boolean;
}

export const FileCard: React.FC<FileCardProps> = ({
  file,
  onOpen,
  onStarToggle,
  onDelete,
  onRestore,
  onRename,
  onAIAnalyze,
  onShare,
  onOCR,
  onVeoAnimate,
  onBackupFolder,
  onSendToAutomation,
  isTrashView = false,
  aiClassification,
  onSelectAICategory,
  reminder,
  onSetReminder,
  isSelected = false,
  onToggleSelect,
  selectionActive = false,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const isFolder = file.mimeType === 'application/vnd.google-apps.folder';
  const meta = getFileTypeMeta(file.mimeType);

  const categoryMeta = aiClassification?.category ? AI_CATEGORIES[aiClassification.category] : null;

  const renderIcon = () => {
    if (isFolder) return <Folder className="w-9 h-9 text-amber-500 fill-amber-500/20" />;
    if (meta.type === 'doc') return <FileText className="w-8 h-8 text-blue-600" />;
    if (meta.type === 'sheet') return <Table className="w-8 h-8 text-emerald-600" />;
    if (meta.type === 'slide') return <Presentation className="w-8 h-8 text-amber-600" />;
    if (meta.type === 'pdf') return <FileCheck className="w-8 h-8 text-rose-600" />;
    if (meta.type === 'image') return <ImageIcon className="w-8 h-8 text-purple-600" />;
    if (meta.type === 'video') return <Video className="w-8 h-8 text-indigo-600" />;
    if (meta.type === 'audio') return <Music className="w-8 h-8 text-pink-600" />;
    return <File className="w-8 h-8 text-slate-500" />;
  };

  const getAIIcon = (key: AICategoryKey) => {
    switch (key) {
      case 'invoices': return <Receipt className="w-3 h-3 text-emerald-600" />;
      case 'reports': return <BarChart3 className="w-3 h-3 text-blue-600" />;
      case 'projects': return <Rocket className="w-3 h-3 text-amber-600" />;
      case 'contracts': return <FileCheck2 className="w-3 h-3 text-purple-600" />;
      case 'education': return <GraduationCap className="w-3 h-3 text-cyan-600" />;
      case 'media': return <Palette className="w-3 h-3 text-rose-600" />;
      default: return <FolderGit2 className="w-3 h-3 text-slate-600" />;
    }
  };

  return (
    <div
      className={`group relative flex flex-col justify-between p-4 rounded-2xl bg-white border transition-all duration-200 select-none ${
        isSelected
          ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/20 shadow-md'
          : 'border-slate-200/90 hover:border-blue-400 hover:shadow-lg hover:shadow-blue-500/5'
      }`}
    >
      {/* Top Bar: Icon, Checkbox, Star, and Action Menu */}
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          {onToggleSelect && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleSelect(file);
              }}
              className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                isSelected
                  ? 'bg-blue-600 border-blue-600 text-white'
                  : selectionActive
                  ? 'bg-white border-slate-300 hover:border-blue-500'
                  : 'bg-white/80 border-slate-300 opacity-0 group-hover:opacity-100 hover:border-blue-500'
              }`}
              title={isSelected ? 'إلغاء التحديد' : 'تحديد الملف'}
            >
              {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
            </button>
          )}

          <div 
            onClick={() => onOpen(file)}
            className="p-2.5 rounded-xl bg-slate-50 group-hover:bg-blue-50/60 transition-colors cursor-pointer"
          >
            {renderIcon()}
          </div>
        </div>

        <div className="flex items-center gap-1">
          {/* Star Button */}
          {!isTrashView && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onStarToggle(file);
              }}
              className={`p-1.5 rounded-lg transition-colors ${
                file.starred
                  ? 'text-amber-500 hover:text-amber-600 bg-amber-50'
                  : 'text-slate-300 hover:text-amber-400 opacity-0 group-hover:opacity-100'
              }`}
              title={file.starred ? 'إزالة من المميزة' : 'تمييز بنجمة'}
            >
              <Star className={`w-4 h-4 ${file.starred ? 'fill-amber-400' : ''}`} />
            </button>
          )}

          {/* Context Dropdown Menu */}
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setMenuOpen(!menuOpen);
              }}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {menuOpen && (
              <>
                <div
                  className="fixed inset-0 z-20"
                  onClick={(e) => {
                    e.stopPropagation();
                    setMenuOpen(false);
                  }}
                />
                <div className="absolute left-0 top-8 z-30 w-48 py-1.5 bg-white rounded-xl shadow-xl border border-slate-200 text-xs text-slate-700 animate-in fade-in zoom-in-95 duration-100">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setMenuOpen(false);
                      onOpen(file);
                    }}
                    className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-slate-50"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                    <span>معاينة وتفاصيل</span>
                  </button>

                  {isFolder && !isTrashView && onBackupFolder && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpen(false);
                        onBackupFolder(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-emerald-50 text-emerald-700 font-bold"
                    >
                      <Archive className="w-3.5 h-3.5 text-emerald-600" />
                      <span>نسخ احتياطي للمجلد (ZIP)</span>
                    </button>
                  )}

                  {!isFolder && !isTrashView && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpen(false);
                        onAIAnalyze(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-indigo-50 text-indigo-700 font-bold"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                      <span>تحليل وتلخيص بالـ AI</span>
                    </button>
                  )}

                  {!isFolder && !isTrashView && onSendToAutomation && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpen(false);
                        onSendToAutomation(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-emerald-50 text-emerald-700 font-bold"
                    >
                      <Send className="w-3.5 h-3.5 text-emerald-600" />
                      <span>إرسال إلى الأتمتة (n8n / WhatsApp)</span>
                    </button>
                  )}

                  {!isFolder && !isTrashView && onOCR && OCRService.isOCRSupported(file) && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpen(false);
                        onOCR(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-violet-50 text-violet-700 font-bold"
                    >
                      <ScanText className="w-3.5 h-3.5 text-violet-600" />
                      <span>استخراج النصوص (OCR)</span>
                    </button>
                  )}

                  {!isFolder && !isTrashView && onVeoAnimate && VeoService.isVeoSupported(file) && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpen(false);
                        onVeoAnimate(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-rose-50 text-rose-700 font-bold"
                    >
                      <Film className="w-3.5 h-3.5 text-rose-600" />
                      <span>تحريك الصورة لفيديو (Veo)</span>
                    </button>
                  )}

                  {!isTrashView && onShare && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpen(false);
                        onShare(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-blue-50 text-blue-700 font-semibold"
                    >
                      <Share2 className="w-3.5 h-3.5 text-blue-600" />
                      <span>مشاركة الصلاحيات (Share)</span>
                    </button>
                  )}

                  {!isTrashView && onSetReminder && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpen(false);
                        onSetReminder(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-amber-50 text-amber-800 font-medium"
                    >
                      <Bell className="w-3.5 h-3.5 text-amber-600" />
                      <span>{reminder ? 'تعديل التذكير' : 'إضافة تذكير'}</span>
                    </button>
                  )}

                  {!isTrashView && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpen(false);
                        onRename(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-slate-50"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-slate-500" />
                      <span>إعادة تسمية</span>
                    </button>
                  )}

                  {file.webViewLink && (
                    <a
                      href={file.webViewLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-slate-50 text-blue-600"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>فتح في Google Drive</span>
                    </a>
                  )}

                  {isTrashView && onRestore && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpen(false);
                        onRestore(file);
                      }}
                      className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-emerald-50 text-emerald-700"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>استعادة الملف</span>
                    </button>
                  )}

                  <div className="h-px bg-slate-100 my-1" />

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setMenuOpen(false);
                      onDelete(file);
                    }}
                    className="flex items-center gap-2 w-full px-3 py-2 text-right hover:bg-red-50 text-red-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isTrashView ? 'حذف نهائي' : 'نقل لسلة المهملات'}</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* File Title & Info */}
      <div 
        onClick={() => onOpen(file)}
        className="cursor-pointer"
      >
        <h3 
          className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2 mb-1.5 leading-snug"
          title={file.name}
        >
          {file.name}
        </h3>
        
        <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
          <span>{isFolder ? 'مجلد' : formatBytes(file.size)}</span>
          <span>{formatDate(file.modifiedTime)}</span>
        </div>
      </div>

      {/* Reminder Status Badge */}
      {reminder && (
        <div className="mt-2.5">
          <button
            onClick={(e) => {
              e.stopPropagation();
              if (onSetReminder) onSetReminder(file);
            }}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition-all text-right cursor-pointer ${
              reminder.completed
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : ReminderService.isDue(reminder)
                  ? 'bg-rose-50 text-rose-700 border-rose-300 animate-pulse shadow-xs'
                  : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100/80'
            }`}
            title="انقر لتعديل أو إدارة التذكير"
          >
            <div className="flex items-center gap-1.5 min-w-0">
              {reminder.completed ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              ) : (
                <Bell className={`w-3.5 h-3.5 shrink-0 ${ReminderService.isDue(reminder) ? 'text-rose-600 animate-bounce' : 'text-amber-600'}`} />
              )}
              <span className="truncate">
                {reminder.completed 
                  ? 'تم إنجاز التذكير'
                  : ReminderService.isDue(reminder)
                    ? 'تذكير مستحق الآن!'
                    : ReminderService.formatReminderDate(reminder.remindAt)}
              </span>
            </div>
            {reminder.priority === 'high' && !reminder.completed && (
              <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-rose-200 text-rose-800 shrink-0 mr-1">
                هام
              </span>
            )}
          </button>
        </div>
      )}

      {/* AI Category Pill & Tags */}
      {!isFolder && categoryMeta && (
        <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
          <button
            onClick={(e) => {
              e.stopPropagation();
              if (onSelectAICategory && aiClassification) {
                onSelectAICategory(aiClassification.category);
              }
            }}
            className={`flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md border transition-transform hover:scale-105 cursor-pointer ${categoryMeta.badgeBg} ${categoryMeta.badgeText} ${categoryMeta.badgeBorder}`}
            title={`تصنيف AI: ${categoryMeta.label} - انقر للفلترة`}
          >
            {getAIIcon(aiClassification.category)}
            <span>{categoryMeta.label}</span>
          </button>

          {aiClassification.tags?.slice(0, 1).map((tag, idx) => (
            <span key={idx} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-medium">
              #{tag}
            </span>
          ))}
        </div>
      )}

      {/* Quick AI Tag or Preview Thumbnail */}
      {file.thumbnailLink && (
        <div 
          onClick={() => onOpen(file)}
          className="mt-3 w-full h-24 rounded-xl overflow-hidden bg-slate-100 cursor-pointer"
        >
          <img 
            src={file.thumbnailLink} 
            alt={file.name} 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
          />
        </div>
      )}

      {/* Quick AI Summary Trigger Badge */}
      {!isFolder && !isTrashView && (
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-1">
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${meta.color} truncate max-w-[90px]`}>
            {meta.label}
          </span>
          <div className="flex items-center gap-1.5">
            {onOCR && OCRService.isOCRSupported(file) && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOCR(file);
                }}
                className="flex items-center gap-1 text-[10px] font-bold text-violet-700 bg-violet-50 hover:bg-violet-100 px-1.5 py-0.5 rounded-md border border-violet-200 transition-colors"
                title="استخراج النص من الصورة أو الـ PDF عبر OCR"
              >
                <ScanText className="w-3 h-3 text-violet-600" />
                <span>OCR</span>
              </button>
            )}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAIAnalyze(file);
              }}
              className="flex items-center gap-1 text-[11px] font-bold text-indigo-600 hover:text-indigo-800 transition-colors opacity-80 group-hover:opacity-100"
            >
              <Sparkles className="w-3 h-3" />
              <span>تلخيص AI</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
