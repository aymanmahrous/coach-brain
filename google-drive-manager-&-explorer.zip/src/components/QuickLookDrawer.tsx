import React, { useEffect, useState } from 'react';
import { 
  X, 
  ExternalLink, 
  Sparkles, 
  Eye, 
  Calendar, 
  HardDrive, 
  User, 
  Star, 
  Copy, 
  Check,
  FileText,
  Receipt,
  BarChart3,
  Rocket,
  FileCheck2,
  GraduationCap,
  Palette,
  FolderGit2,
  Bell,
  Clock,
  CheckCircle2,
  AlertCircle,
  Share2,
  ScanText,
  Film,
  Archive,
  Send
} from 'lucide-react';
import { DriveFile, AICategoryClassification, AICategoryKey, FileReminder } from '../types';
import { DriveService, formatBytes, formatDate, getFileTypeMeta } from '../services/driveService';
import { AI_CATEGORIES } from '../services/aiCategorizeService';
import { ReminderService } from '../services/reminderService';
import { OCRService } from '../services/ocrService';
import { VeoService } from '../services/veoService';

interface QuickLookDrawerProps {
  file: DriveFile | null;
  onClose: () => void;
  token: string | null;
  onAIAnalyze: (file: DriveFile) => void;
  onStarToggle: (file: DriveFile) => void;
  onShare?: (file: DriveFile) => void;
  onOCR?: (file: DriveFile) => void;
  onVeoAnimate?: (file: DriveFile) => void;
  onBackupFolder?: (folder: DriveFile) => void;
  onSendToAutomation?: (file: DriveFile) => void;
  aiClassification?: AICategoryClassification;
  reminder?: FileReminder;
  onSetReminder?: (file: DriveFile) => void;
}

export const QuickLookDrawer: React.FC<QuickLookDrawerProps> = ({
  file,
  onClose,
  token,
  onAIAnalyze,
  onStarToggle,
  onShare,
  onOCR,
  onVeoAnimate,
  onBackupFolder,
  onSendToAutomation,
  aiClassification,
  reminder,
  onSetReminder,
}) => {
  const [content, setContent] = useState<string>('');
  const [isLoadingContent, setIsLoadingContent] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!file) {
      setContent('');
      return;
    }

    let isMounted = true;
    const isFolder = file.mimeType === 'application/vnd.google-apps.folder';

    if (!isFolder) {
      setIsLoadingContent(true);
      DriveService.fetchFileTextContent(token, file)
        .then((text) => {
          if (isMounted) {
            setContent(text);
          }
        })
        .catch((err) => {
          if (isMounted) {
            setContent(`تعذر تحميل محتوى الملف: ${err.message || 'خطأ غير معروف'}`);
          }
        })
        .finally(() => {
          if (isMounted) {
            setIsLoadingContent(false);
          }
        });
    } else {
      setContent('');
      setIsLoadingContent(false);
    }

    return () => {
      isMounted = false;
    };
  }, [file, token]);

  if (!file) return null;

  const meta = getFileTypeMeta(file.mimeType);
  const isFolder = file.mimeType === 'application/vnd.google-apps.folder';
  const categoryMeta = aiClassification?.category ? AI_CATEGORIES[aiClassification.category] : null;

  const handleCopyLink = () => {
    if (file.webViewLink) {
      navigator.clipboard.writeText(file.webViewLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getAIIcon = (key: AICategoryKey) => {
    switch (key) {
      case 'invoices': return <Receipt className="w-4 h-4 text-emerald-600" />;
      case 'reports': return <BarChart3 className="w-4 h-4 text-blue-600" />;
      case 'projects': return <Rocket className="w-4 h-4 text-amber-600" />;
      case 'contracts': return <FileCheck2 className="w-4 h-4 text-purple-600" />;
      case 'education': return <GraduationCap className="w-4 h-4 text-cyan-600" />;
      case 'media': return <Palette className="w-4 h-4 text-rose-600" />;
      default: return <FolderGit2 className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <>
      {/* Backdrop for mobile / focus */}
      <div 
        className="fixed inset-0 bg-slate-900/30 backdrop-blur-[2px] z-40 transition-opacity"
        onClick={onClose}
      />

      {/* Slide-in Side Drawer */}
      <aside 
        className="fixed top-0 left-0 bottom-0 z-50 w-full sm:w-[480px] md:w-[540px] bg-white shadow-2xl border-r border-slate-200 flex flex-col animate-in slide-in-from-left duration-300 text-slate-900"
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600 border border-blue-200/60">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-extrabold text-slate-900">معاينة سريعة (Quick Look)</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${meta.color}`}>
                  {meta.label}
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate max-w-[260px]">{file.name}</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => onStarToggle(file)}
              className={`p-2 rounded-xl transition-colors ${
                file.starred ? 'text-amber-500 bg-amber-50' : 'text-slate-400 hover:text-amber-500 hover:bg-slate-100'
              }`}
              title={file.starred ? 'إزالة من المميزة' : 'تمييز بنجمة'}
            >
              <Star className={`w-4 h-4 ${file.starred ? 'fill-amber-400' : ''}`} />
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/70 rounded-xl transition-colors"
              title="إغلاق المعاينة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-5">
          
          {/* AI Categorization Card */}
          {!isFolder && categoryMeta && (
            <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50/70 via-purple-50/40 to-white border border-indigo-200/80 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-indigo-100 text-indigo-700">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold text-indigo-900">تصنيف الذكاء الاصطناعي (Gemini)</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                  دقة {Math.round((aiClassification?.confidence || 0.9) * 100)}%
                </span>
              </div>

              <div className="flex items-center gap-2 mt-2">
                <div className={`flex items-center gap-1.5 px-3 py-1 rounded-xl border text-xs font-bold ${categoryMeta.badgeBg} ${categoryMeta.badgeText} ${categoryMeta.badgeBorder}`}>
                  {getAIIcon(categoryMeta.key)}
                  <span>{categoryMeta.label}</span>
                </div>
                <span className="text-xs text-slate-500">{categoryMeta.description}</span>
              </div>

              {aiClassification?.reason && (
                <p className="text-xs text-slate-600 mt-2 bg-white/80 p-2.5 rounded-xl border border-indigo-100">
                  💡 {aiClassification.reason}
                </p>
              )}

              {aiClassification?.tags && aiClassification.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-2.5">
                  {aiClassification.tags.map((tag, idx) => (
                    <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-700 font-medium">
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* File Thumbnail or Media Banner */}
          {file.thumbnailLink && (
            <div className="w-full h-48 rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center p-2">
              <img 
                src={file.thumbnailLink} 
                alt={file.name} 
                referrerPolicy="no-referrer"
                className="max-w-full max-h-full object-contain rounded-xl"
              />
            </div>
          )}

          {/* Reminder Section */}
          <div className="p-3.5 rounded-2xl border transition-all bg-slate-50/80 border-slate-200/80">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`p-1.5 rounded-lg ${reminder ? (reminder.completed ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700') : 'bg-slate-200 text-slate-600'}`}>
                  <Bell className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-900">
                    {reminder ? 'تذكير مجدول لهذا الملف' : 'جدولة تذكير وتنبيه'}
                  </span>
                  {reminder && (
                    <span className="block text-[10px] text-slate-500 font-mono">
                      {ReminderService.formatReminderDate(reminder.remindAt)}
                    </span>
                  )}
                </div>
              </div>

              {onSetReminder && (
                <button
                  onClick={() => onSetReminder(file)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    reminder 
                      ? 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100 shadow-2xs' 
                      : 'bg-amber-500 hover:bg-amber-600 text-white shadow-md shadow-amber-500/20'
                  }`}
                >
                  {reminder ? 'تعديل التذكير' : 'إضافة تذكير'}
                </button>
              )}
            </div>

            {reminder && reminder.note && (
              <div className="mt-2.5 p-2 rounded-xl bg-white text-xs text-slate-700 border border-slate-200/70 font-medium">
                <span className="text-[10px] text-slate-400 font-bold block mb-0.5">ملاحظة:</span>
                {reminder.note}
              </div>
            )}
          </div>

          {/* Quick Details Chips */}
          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center gap-2.5">
              <HardDrive className="w-4 h-4 text-blue-600 shrink-0" />
              <div>
                <span className="text-[10px] text-slate-400 block font-medium">الحجم</span>
                <span className="font-bold text-slate-800">{isFolder ? 'مجلد' : formatBytes(file.size)}</span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center gap-2.5">
              <Calendar className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <span className="text-[10px] text-slate-400 block font-medium">آخر تعديل</span>
                <span className="font-bold text-slate-800">{formatDate(file.modifiedTime)}</span>
              </div>
            </div>
          </div>

          {/* Live File Content Stream / Preview */}
          {!isFolder && (
            <div className="flex-1 flex flex-col min-h-[220px]">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span>محتوى الملف والنص المستخرج</span>
                </div>
                {content && (
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(content);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                    className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1 px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'تم النسخ' : 'نسخ النص'}</span>
                  </button>
                )}
              </div>

              {isLoadingContent ? (
                <div className="flex-1 flex flex-col items-center justify-center p-8 bg-slate-50 rounded-2xl border border-slate-200 text-slate-400 text-xs gap-2">
                  <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                  <span>جاري استخراج ومعاينة محتوى المستند...</span>
                </div>
              ) : content ? (
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/90 text-xs font-mono text-slate-800 leading-relaxed max-h-72 overflow-y-auto whitespace-pre-wrap selection:bg-blue-200">
                  {content}
                </div>
              ) : (
                <div className="p-6 text-center bg-slate-50 rounded-2xl border border-slate-200 text-slate-400 text-xs">
                  لا يتوفر نص مباشر لهذا الملف، يمكنك فتحه مباشرة عبر Google Drive.
                </div>
              )}
            </div>
          )}

          {/* Description note if present */}
          {file.description && (
            <div className="p-3.5 bg-amber-50/60 border border-amber-200/70 rounded-2xl text-xs text-amber-900">
              <span className="font-bold block mb-1">وصف الملف:</span>
              <p>{file.description}</p>
            </div>
          )}
        </div>

        {/* Action Footer */}
        <div className="p-4 px-5 border-t border-slate-200 bg-slate-50/80 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {isFolder && onBackupFolder && (
              <button
                onClick={() => {
                  onClose();
                  onBackupFolder(file);
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
                title="ضغط وتنزيل محتويات المجلد كملف ZIP"
              >
                <Archive className="w-4 h-4" />
                <span>نسخ احتياطي (ZIP)</span>
              </button>
            )}

            {!isFolder && (
              <button
                onClick={() => {
                  onClose();
                  onAIAnalyze(file);
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-500/20 transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>تحليل بـ Gemini</span>
              </button>
            )}

            {!isFolder && onOCR && OCRService.isOCRSupported(file) && (
              <button
                onClick={() => {
                  onClose();
                  onOCR(file);
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-xl shadow-md shadow-violet-500/20 transition-all cursor-pointer"
                title="استخراج النص من الصورة أو الـ PDF عبر الذكاء الاصطناعي"
              >
                <ScanText className="w-4 h-4" />
                <span>استخراج OCR</span>
              </button>
            )}

            {!isFolder && onVeoAnimate && VeoService.isVeoSupported(file) && (
              <button
                onClick={() => {
                  onClose();
                  onVeoAnimate(file);
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-amber-600 via-rose-600 to-indigo-600 hover:from-amber-700 hover:via-rose-700 hover:to-indigo-700 text-white font-bold text-xs rounded-xl shadow-md shadow-rose-500/20 transition-all cursor-pointer"
                title="تحريك الصورة إلى فيديو سينمائي عالي الدقة عبر Google Veo"
              >
                <Film className="w-4 h-4" />
                <span>تحريك بـ Veo Video</span>
              </button>
            )}

            {!isFolder && onSendToAutomation && (
              <button
                onClick={() => {
                  onClose();
                  onSendToAutomation(file);
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
                title="إرسال بيانات الملف إلى أتمتة n8n (WhatsApp / Messenger)"
              >
                <Send className="w-4 h-4" />
                <span>إرسال إلى الأتمتة</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 mr-auto">
            {onShare && (
              <button
                onClick={() => {
                  onClose();
                  onShare(file);
                }}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100/80 rounded-xl transition-colors border border-blue-200"
                title="مشاركة الملف وتحديد الصلاحيات"
              >
                <Share2 className="w-3.5 h-3.5 text-blue-600" />
                <span>مشاركة</span>
              </button>
            )}

            {file.webViewLink && (
              <button
                onClick={handleCopyLink}
                className="p-2 text-slate-600 hover:bg-slate-200/70 rounded-xl transition-colors border border-slate-200"
                title="نسخ رابط الملف"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            )}

            {file.webViewLink && (
              <a
                href={file.webViewLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-all shadow-xs"
              >
                <span>فتح في Drive</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};
