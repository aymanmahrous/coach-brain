import React, { useState, useEffect } from 'react';
import {
  X,
  Radio,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Zap,
  Globe,
  Sliders,
  Bell,
  Palette,
  ExternalLink,
  ShieldCheck,
  Send,
  Save,
  Clock,
  Sparkles,
  ArrowRight,
  HelpCircle,
  CheckCheck,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';
import {
  ACCENT_PRESETS,
  ThemeService,
  UserThemePreferences,
  AccentThemePreset
} from '../services/themeService';
import { SoundEffects } from '../utils/audioChime';

export interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'webhooks' | 'health' | 'appearance' | 'notifications' | 'channels';
  currentPreferences?: UserThemePreferences;
  onUpdatePreferences?: (prefs: UserThemePreferences) => void;
  onWebhookUpdated?: () => void;
}

interface PlatformStatus {
  url: string;
  connected: boolean;
  status: 'Connected' | 'Disconnected' | 'Checking';
  latencyMs?: number;
  lastVerifiedAt?: string | null;
  message?: string;
}

interface HealthCheckItem {
  id: string;
  name: string;
  category: string;
  status: string;
  healthy: boolean;
  latencyMs?: number;
  url?: string;
  details: string;
  icon?: string;
}

interface HealthCheckResponse {
  overallStatus: string;
  allHealthy: boolean;
  checksCount: number;
  activeCount: number;
  totalLatencyMs: number;
  checkedAt: string;
  checks: HealthCheckItem[];
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'webhooks',
  currentPreferences,
  onUpdatePreferences,
  onWebhookUpdated
}) => {
  const [activeTab, setActiveTab] = useState<'webhooks' | 'health' | 'appearance' | 'notifications' | 'channels'>(defaultTab);

  // Health Check State
  const [healthData, setHealthData] = useState<HealthCheckResponse | null>(null);
  const [isLoadingHealth, setIsLoadingHealth] = useState(false);

  // Webhooks State
  const [whatsappUrl, setWhatsappUrl] = useState('');
  const [messengerUrl, setMessengerUrl] = useState('');
  const [whatsappStatus, setWhatsappStatus] = useState<PlatformStatus>({
    url: '',
    connected: false,
    status: 'Disconnected'
  });
  const [messengerStatus, setMessengerStatus] = useState<PlatformStatus>({
    url: '',
    connected: false,
    status: 'Disconnected'
  });

  const [isLoadingSettings, setIsLoadingSettings] = useState(false);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [isCheckingWa, setIsCheckingWa] = useState(false);
  const [isCheckingMsg, setIsCheckingMsg] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Notification API State
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  const [testNotificationSent, setTestNotificationSent] = useState(false);

  // Appearance State
  const [tempPrefs, setTempPrefs] = useState<UserThemePreferences>(() => 
    currentPreferences || ThemeService.getPreferences()
  );

  // Sync state on open
  useEffect(() => {
    if (isOpen) {
      setActiveTab(defaultTab);
      loadWebhookSettings();
      checkNotificationPermission();
      if (currentPreferences) {
        setTempPrefs(currentPreferences);
      }
    }
  }, [isOpen, defaultTab, currentPreferences]);

  const checkNotificationPermission = () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotificationPermission(Notification.permission);
    }
  };

  const handleRequestNotificationPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const result = await Notification.requestPermission();
        setNotificationPermission(result);
        if (result === 'granted') {
          new Notification('Coach Ayman Cockpit — تم التفعيل', {
            body: 'إشعارات سطح المكتب مفعلة الآن للتذكيرات ومحادثات العملاء بنجاح.',
            icon: '/favicon.ico'
          });
          setTestNotificationSent(true);
          setTimeout(() => setTestNotificationSent(false), 4000);
        }
      } catch (err) {
        console.error('Failed to request notification permission:', err);
      }
    }
  };

  const handleSendTestNotification = () => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      new Notification('تنبيه تجريبي من Cockpit Hub', {
        body: 'وصلتك رسالة جديدة عبر n8n من عميل مهتم بدورة تدريب سباحة.',
        icon: '/favicon.ico'
      });
      setTestNotificationSent(true);
      setTimeout(() => setTestNotificationSent(false), 4000);
    }
  };

  const loadWebhookSettings = async () => {
    setIsLoadingSettings(true);
    try {
      const res = await fetch('/api/n8n/webhook-settings');
      if (res.ok) {
        const data = await res.json();
        if (data.settings) {
          const waUrl = data.settings.whatsappWebhookUrl || '';
          const msgUrl = data.settings.messengerWebhookUrl || '';
          setWhatsappUrl(waUrl);
          setMessengerUrl(msgUrl);
          
          setWhatsappStatus({
            url: waUrl,
            connected: Boolean(data.settings.whatsappConnected),
            status: data.settings.whatsappConnected ? 'Connected' : 'Disconnected',
            lastVerifiedAt: data.settings.lastVerifiedAt
          });

          setMessengerStatus({
            url: msgUrl,
            connected: Boolean(data.settings.messengerConnected),
            status: data.settings.messengerConnected ? 'Connected' : 'Disconnected',
            lastVerifiedAt: data.settings.lastVerifiedAt
          });
        }
      }
    } catch (err) {
      console.error('Failed to load webhook settings:', err);
    } finally {
      setIsLoadingSettings(false);
    }
  };

  const loadHealthCheck = async () => {
    setIsLoadingHealth(true);
    try {
      const res = await fetch('/api/health/connections');
      if (res.ok) {
        const data = await res.json();
        setHealthData(data);
      }
    } catch (err) {
      console.error('Failed to load health check:', err);
    } finally {
      setIsLoadingHealth(false);
    }
  };

  useEffect(() => {
    if (isOpen && activeTab === 'health') {
      loadHealthCheck();
    }
  }, [isOpen, activeTab]);

  // Check specific platform via API
  const handleCheckPlatform = async (platform: 'whatsapp' | 'messenger') => {
    if (platform === 'whatsapp') setIsCheckingWa(true);
    if (platform === 'messenger') setIsCheckingMsg(true);

    const targetUrl = platform === 'whatsapp' ? whatsappUrl : messengerUrl;

    try {
      const res = await fetch('/api/n8n/check-platform', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ platform, url: targetUrl })
      });

      if (res.ok) {
        const data = await res.json();
        const isConn = data.connected === true;
        const newStatus: PlatformStatus = {
          url: targetUrl,
          connected: isConn,
          status: isConn ? 'Connected' : 'Disconnected',
          latencyMs: data.latencyMs,
          lastVerifiedAt: data.verifiedAt || new Date().toISOString(),
          message: data.message
        };

        if (platform === 'whatsapp') {
          setWhatsappStatus(newStatus);
        } else {
          setMessengerStatus(newStatus);
        }
      }
    } catch (err: any) {
      const failStatus: PlatformStatus = {
        url: targetUrl,
        connected: false,
        status: 'Disconnected',
        message: err.message || 'فشل الاتصال بالـ API'
      };
      if (platform === 'whatsapp') setWhatsappStatus(failStatus);
      else setMessengerStatus(failStatus);
    } finally {
      if (platform === 'whatsapp') setIsCheckingWa(false);
      if (platform === 'messenger') setIsCheckingMsg(false);
      if (onWebhookUpdated) onWebhookUpdated();
    }
  };

  // Save all settings
  const handleSaveAllWebhooks = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSavingSettings(true);
    setSaveSuccessMsg(null);

    try {
      const res = await fetch('/api/n8n/webhook-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          whatsappWebhookUrl: whatsappUrl,
          messengerWebhookUrl: messengerUrl
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.settings) {
          setWhatsappStatus(prev => ({
            ...prev,
            connected: data.settings.whatsappConnected,
            status: data.settings.whatsappConnected ? 'Connected' : 'Disconnected',
            lastVerifiedAt: data.settings.lastVerifiedAt
          }));
          setMessengerStatus(prev => ({
            ...prev,
            connected: data.settings.messengerConnected,
            status: data.settings.messengerConnected ? 'Connected' : 'Disconnected',
            lastVerifiedAt: data.settings.lastVerifiedAt
          }));
        }
        setSaveSuccessMsg('تم حفظ إعدادات الـ Webhooks بنجاح وتحديث حالات الاتصال عبر الـ API');
        SoundEffects.playSuccess();
        if (onWebhookUpdated) onWebhookUpdated();
        setTimeout(() => setSaveSuccessMsg(null), 4000);
      }
    } catch (err: any) {
      console.error('Failed to save webhook settings:', err);
    } finally {
      setIsSavingSettings(false);
    }
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    SoundEffects.playPop();
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleApplyPreset = (preset: AccentThemePreset) => {
    const updated = { ...tempPrefs, accentId: preset.id };
    setTempPrefs(updated);
    if (onUpdatePreferences) {
      onUpdatePreferences(updated);
    }
    ThemeService.applyTheme(updated);
    SoundEffects.playSuccess();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-[#050b14] border border-cyan-800/60 rounded-2xl shadow-2xl text-slate-100 overflow-hidden font-sans"
        dir="rtl"
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-950/80 bg-gradient-to-r from-[#071322] via-[#09182a] to-[#071322]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-cyan-950/80 border border-cyan-700/60 rounded-xl text-cyan-400 shadow-inner">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-wide">
                  إعدادات النظام والـ Webhooks (Settings Center)
                </h2>
                <span className="text-[10px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 px-2 py-0.5 rounded-full font-mono">
                  v2.6 Hub
                </span>
              </div>
              <p className="text-xs text-slate-400">
                إدارة عناوين ربط n8n التلقائي، وحالات منصات Meta، وتخصيص المظهر والتنبيهات
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors cursor-pointer"
            aria-label="إغلاق الإعدادات"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-[#040810] border-b border-cyan-950/60 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('webhooks')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'webhooks'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg shadow-cyan-950/50'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
            }`}
          >
            <Radio className="w-4 h-4 text-cyan-300" />
            <span>إعدادات Webhooks (n8n & Meta)</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-black/40 text-cyan-200 font-mono">
              WhatsApp & Messenger
            </span>
          </button>

          <button
            onClick={() => setActiveTab('health')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'health'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-950/50'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-300" />
            <span>فحص الاتصال الشامل (Health Check)</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-200 font-mono">
              Live API
            </span>
          </button>

          <button
            onClick={() => setActiveTab('appearance')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'appearance'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-950/50'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
            }`}
          >
            <Palette className="w-4 h-4 text-indigo-300" />
            <span>المظهر وألوان التمييز</span>
          </button>

          <button
            onClick={() => setActiveTab('notifications')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'notifications'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-950/50'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
            }`}
          >
            <Bell className="w-4 h-4 text-emerald-300" />
            <span>إشعارات سطح المكتب (Web API)</span>
          </button>

          <button
            onClick={() => setActiveTab('channels')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'channels'
                ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-lg shadow-amber-950/50'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
            }`}
          >
            <Globe className="w-4 h-4 text-amber-300" />
            <span>معلومات Meta والقنوات</span>
          </button>
        </div>

        {/* Modal Body Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {saveSuccessMsg && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500/50 rounded-xl text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in duration-150">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{saveSuccessMsg}</span>
            </div>
          )}

          {/* TAB 1: WEBHOOKS SETTINGS */}
          {activeTab === 'webhooks' && (
            <div className="space-y-6">
              {/* Architecture Banner */}
              <div className="bg-gradient-to-l from-[#06182c] via-[#091b30] to-[#0a1f36] border border-cyan-800/40 rounded-2xl p-4.5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 rounded-xl text-cyan-400 mt-0.5">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>مسار Webhook ثنائي الاتجاه بين Meta و n8n</span>
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
                        نشط ومُبرمج
                      </span>
                    </h3>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      يتم استقبال رسائل واستفسارات دورات السباحة فورياً من واتساب ومسنجر، وتمريرها إلى سير عمل n8n لتوليد رد ذكي مع الحفاظ على موافقة المدرب اليدوية قبل أي إرسال خارجي.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                  <button
                    onClick={loadWebhookSettings}
                    disabled={isLoadingSettings}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0c223a] hover:bg-[#122e4d] border border-cyan-700/50 text-cyan-200 text-xs rounded-xl font-semibold transition-all cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingSettings ? 'animate-spin text-cyan-400' : ''}`} />
                    <span>تحديث البيانات</span>
                  </button>
                </div>
              </div>

              {/* Form & Platform Settings Grid */}
              <form onSubmit={handleSaveAllWebhooks} className="space-y-5">
                {/* 1. WhatsApp n8n Webhook Card */}
                <div className="bg-[#071322] border border-slate-800 hover:border-emerald-800/60 rounded-2xl p-5 transition-all space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-emerald-950/80 border border-emerald-600/50 flex items-center justify-center text-emerald-400 text-lg">
                        💬
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white">رابط Webhook الخاص بـ WhatsApp (n8n)</h4>
                          {/* Live Connected / Disconnected Badge */}
                          <span
                            className={`flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                              whatsappStatus.connected
                                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                                : 'bg-red-950/80 text-red-300 border-red-500/50'
                            }`}
                          >
                            <span
                              className={`w-2 h-2 rounded-full ${
                                whatsappStatus.connected ? 'bg-emerald-400 animate-ping' : 'bg-red-400'
                              }`}
                            />
                            <span>{whatsappStatus.connected ? 'Connected (متصل)' : 'Disconnected (غير متصل)'}</span>
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          العنوان الذي يرسل إليه النظام إشعارات رسائل الواتساب الواردة عبر n8n
                        </p>
                      </div>
                    </div>

                    {/* Latency / Ping ms badge */}
                    {whatsappStatus.latencyMs !== undefined && (
                      <div className="text-[11px] bg-slate-900 border border-slate-700 text-slate-300 px-2.5 py-1 rounded-lg font-mono flex items-center gap-1.5">
                        <Clock className="w-3 h-3 text-emerald-400" />
                        <span>سرعة الاستجابة: {whatsappStatus.latencyMs}ms</span>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <div className="relative flex-1">
                      <input
                        type="url"
                        value={whatsappUrl}
                        onChange={(e) => setWhatsappUrl(e.target.value)}
                        placeholder="https://n8n.your-domain.com/webhook/coach-whatsapp"
                        className="w-full bg-[#030914] border border-cyan-900/60 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 font-mono outline-none transition-all dir-ltr text-left"
                      />
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleCheckPlatform('whatsapp')}
                        disabled={isCheckingWa}
                        className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-black text-xs font-bold rounded-xl transition-all cursor-pointer shadow-xs"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isCheckingWa ? 'animate-spin' : ''}`} />
                        <span>{isCheckingWa ? 'جارٍ الفحص...' : 'فحص الاتصال عبر API'}</span>
                      </button>

                      {whatsappUrl && (
                        <button
                          type="button"
                          onClick={() => copyToClipboard(whatsappUrl, 'wa_url')}
                          className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors cursor-pointer"
                          title="نسخ الرابط"
                        >
                          {copiedKey === 'wa_url' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                      )}
                    </div>
                  </div>

                  {whatsappStatus.message && (
                    <div className="text-[11px] text-slate-400 bg-slate-900/60 p-2 rounded-lg border border-slate-800 flex items-center gap-1.5">
                      <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>{whatsappStatus.message}</span>
                    </div>
                  )}
                </div>

                {/* 2. Facebook Messenger n8n Webhook Card */}
                <div className="bg-[#071322] border border-slate-800 hover:border-blue-800/60 rounded-2xl p-5 transition-all space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-blue-950/80 border border-blue-600/50 flex items-center justify-center text-blue-400 text-lg">
                        ⚡
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white">رابط Webhook الخاص بـ Facebook Messenger (n8n)</h4>
                          {/* Live Connected / Disconnected Badge */}
                          <span
                            className={`flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                              messengerStatus.connected
                                ? 'bg-blue-950/80 text-blue-300 border-blue-500/50'
                                : 'bg-red-950/80 text-red-300 border-red-500/50'
                            }`}
                          >
                            <span
                              className={`w-2 h-2 rounded-full ${
                                messengerStatus.connected ? 'bg-blue-400 animate-ping' : 'bg-red-400'
                              }`}
                            />
                            <span>{messengerStatus.connected ? 'Connected (متصل)' : 'Disconnected (غير متصل)'}</span>
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          العنوان الذي يرسل إليه النظام إشعارات رسائل فيسبوك مسنجر والصفحة الرسمية عبر n8n
                        </p>
                      </div>
                    </div>

                    {/* Latency / Ping ms badge */}
                    {messengerStatus.latencyMs !== undefined && (
                      <div className="text-[11px] bg-slate-900 border border-slate-700 text-slate-300 px-2.5 py-1 rounded-lg font-mono flex items-center gap-1.5">
                        <Clock className="w-3 h-3 text-blue-400" />
                        <span>سرعة الاستجابة: {messengerStatus.latencyMs}ms</span>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <div className="relative flex-1">
                      <input
                        type="url"
                        value={messengerUrl}
                        onChange={(e) => setMessengerUrl(e.target.value)}
                        placeholder="https://n8n.your-domain.com/webhook/coach-messenger"
                        className="w-full bg-[#030914] border border-cyan-900/60 focus:border-blue-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 font-mono outline-none transition-all dir-ltr text-left"
                      />
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleCheckPlatform('messenger')}
                        disabled={isCheckingMsg}
                        className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-xs"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isCheckingMsg ? 'animate-spin' : ''}`} />
                        <span>{isCheckingMsg ? 'جارٍ الفحص...' : 'فحص الاتصال عبر API'}</span>
                      </button>

                      {messengerUrl && (
                        <button
                          type="button"
                          onClick={() => copyToClipboard(messengerUrl, 'msg_url')}
                          className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors cursor-pointer"
                          title="نسخ الرابط"
                        >
                          {copiedKey === 'msg_url' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                      )}
                    </div>
                  </div>

                  {messengerStatus.message && (
                    <div className="text-[11px] text-slate-400 bg-slate-900/60 p-2 rounded-lg border border-slate-800 flex items-center gap-1.5">
                      <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>{messengerStatus.message}</span>
                    </div>
                  )}
                </div>

                {/* Bottom Action Bar for Webhooks */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <ShieldCheck className="w-4 h-4 text-cyan-400" />
                    <span>يتم حفظ الروابط وتشفيرها محلياً على الخادم مع إمكانية التحديث المباشر في أي وقت</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        handleCheckPlatform('whatsapp');
                        handleCheckPlatform('messenger');
                      }}
                      className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                    >
                      فحص كلا المنصتين معاً
                    </button>
                    <button
                      type="submit"
                      disabled={isSavingSettings}
                      className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-black text-xs font-bold rounded-xl transition-all cursor-pointer shadow-lg shadow-cyan-950/50 disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      <span>{isSavingSettings ? 'جارٍ الحفظ والتحقق...' : 'حفظ إعدادات الـ Webhooks وتحديث الحالة'}</span>
                    </button>
                  </div>
                </div>
              </form>

                {/* Meta Developer Portal & Inbound Endpoints Box */}
                <div className="bg-[#030812] border border-cyan-950 rounded-2xl p-4.5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                      <Globe className="w-4 h-4 text-cyan-400" />
                      <span>عناوين الاستقبال السحابية المباشرة (Inbound Webhooks for Meta App)</span>
                    </h4>
                    <span className="text-[10px] text-slate-500 font-mono">Meta Graph API v20+</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="bg-[#061220] border border-slate-800 p-3 rounded-xl space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-[11px] font-semibold">رابط الاستقبال لواتساب في الكوكبيت:</span>
                        <button
                          type="button"
                          onClick={() => copyToClipboard(`${window.location.origin}/api/n8n/webhook/whatsapp`, 'in_wa')}
                          className="text-[10px] text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          {copiedKey === 'in_wa' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          <span>نسخ</span>
                        </button>
                      </div>
                      <code className="text-[11px] text-cyan-300 font-mono block truncate dir-ltr text-left">
                        {typeof window !== 'undefined' ? `${window.location.origin}/api/n8n/webhook/whatsapp` : '/api/n8n/webhook/whatsapp'}
                      </code>
                    </div>

                    <div className="bg-[#061220] border border-slate-800 p-3 rounded-xl space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-[11px] font-semibold">رابط الاستقبال لمسنجر في الكوكبيت:</span>
                        <button
                          type="button"
                          onClick={() => copyToClipboard(`${window.location.origin}/api/n8n/webhook/messenger`, 'in_msg')}
                          className="text-[10px] text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          {copiedKey === 'in_msg' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          <span>نسخ</span>
                        </button>
                      </div>
                      <code className="text-[11px] text-blue-300 font-mono block truncate dir-ltr text-left">
                        {typeof window !== 'undefined' ? `${window.location.origin}/api/n8n/webhook/messenger` : '/api/n8n/webhook/messenger'}
                      </code>
                    </div>
                  </div>

                  {/* Interactive Meta Step-by-Step Guide for messages & statuses */}
                  <div className="bg-gradient-to-r from-[#06182c] to-[#040e1a] p-4 rounded-xl border border-cyan-800/60 space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-amber-500/20 text-amber-300 rounded-lg">
                        <AlertCircle className="w-4 h-4" />
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-white">حل خطوة Meta: تفعيل اشتراكات messages و statuses</h5>
                        <p className="text-[11px] text-slate-300">السبب وراء عدم رد البوت عند إرسال رسالة من رقم آخر هو أن Meta تحتاج لتفعيل هذين الحقلين لتمرير الرسائل إلى n8n</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-[11px]">
                      <div className="p-2.5 bg-black/40 rounded-lg border border-slate-800 flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-cyan-900 text-cyan-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">1</span>
                        <div>
                          <strong className="text-slate-200 block">افتح لوحة Meta للمطورين</strong>
                          <span className="text-slate-400">انتقل إلى: Use cases &gt; WhatsApp &gt; Basic setup &gt; Step 2: Configure Webhooks</span>
                        </div>
                      </div>

                      <div className="p-2.5 bg-black/40 rounded-lg border border-slate-800 flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-cyan-900 text-cyan-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">2</span>
                        <div>
                          <strong className="text-emerald-300 block">اضغط Manage Subscriptions</strong>
                          <span className="text-slate-400">فعل علامة الصح بجانب <code className="text-emerald-300 bg-slate-900 px-1 py-0.5 rounded">messages</code> وبجانب <code className="text-emerald-300 bg-slate-900 px-1 py-0.5 rounded">statuses</code></span>
                        </div>
                      </div>
                    </div>

                    <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">رمز التحقق الافتراضي لـ Webhook (Verify Token):</span>
                      <div className="flex items-center gap-2">
                        <code className="text-cyan-300 font-mono bg-black/60 px-2 py-0.5 rounded">coach_ayman_webhook_verify_2026</code>
                        <button
                          type="button"
                          onClick={() => copyToClipboard('coach_ayman_webhook_verify_2026', 'vtoken')}
                          className="text-slate-300 hover:text-white cursor-pointer"
                          title="نسخ Verify Token"
                        >
                          {copiedKey === 'vtoken' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          )}

          {/* TAB 2: HEALTH CHECK (فحص الاتصال الشامل) */}
          {activeTab === 'health' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              {/* Header card with overall status */}
              <div className="bg-gradient-to-l from-[#06182c] via-[#091b30] to-[#0a1f36] border border-cyan-800/40 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-emerald-400 mt-0.5">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white">فحص الاتصال الشامل (Connection Health Check)</h3>
                      <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold">
                        {healthData?.overallStatus || 'جاهز للفحص'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      فحص تشخيصي حي لكافة الأنظمة: الخادم، والذكاء الاصطناعي، ومفاتيح Meta الرسمية، ومولد Canva، وروابط n8n للواتساب والمسنجر.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                  <button
                    onClick={loadHealthCheck}
                    disabled={isLoadingHealth}
                    className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-lg shadow-emerald-950/40 disabled:opacity-50"
                  >
                    <RefreshCw className={`w-4 h-4 ${isLoadingHealth ? 'animate-spin' : ''}`} />
                    <span>{isLoadingHealth ? 'جارٍ الفحص الحي...' : 'إعادة فحص كافة الأنظمة الآن'}</span>
                  </button>
                </div>
              </div>

              {/* Summary Metrics */}
              {healthData && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="bg-[#071322] border border-slate-800 p-3 rounded-xl flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[11px] block">إجمالي الخدمات:</span>
                      <strong className="text-white text-sm font-mono">{healthData.checksCount} خدمات</strong>
                    </div>
                    <span className="text-xl">📊</span>
                  </div>
                  <div className="bg-[#071322] border border-slate-800 p-3 rounded-xl flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[11px] block">الخدمات المتصلة:</span>
                      <strong className="text-emerald-400 text-sm font-mono">{healthData.activeCount} متصلة</strong>
                    </div>
                    <span className="text-xl">✅</span>
                  </div>
                  <div className="bg-[#071322] border border-slate-800 p-3 rounded-xl flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[11px] block">زمن الاستجابة:</span>
                      <strong className="text-cyan-400 text-sm font-mono">{healthData.totalLatencyMs}ms</strong>
                    </div>
                    <span className="text-xl">⚡</span>
                  </div>
                  <div className="bg-[#071322] border border-slate-800 p-3 rounded-xl flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[11px] block">آخر تدقيق:</span>
                      <strong className="text-slate-300 text-[10px] font-mono">
                        {new Date(healthData.checkedAt).toLocaleTimeString('ar-EG')}
                      </strong>
                    </div>
                    <span className="text-xl">🕒</span>
                  </div>
                </div>
              )}

              {/* Service Cards List */}
              <div className="space-y-3">
                {isLoadingHealth && !healthData && (
                  <div className="p-8 text-center text-slate-400 text-xs flex flex-col items-center gap-2">
                    <RefreshCw className="w-6 h-6 animate-spin text-cyan-400" />
                    <span>جارٍ الاتصال بكافة الخدمات وفحص سلامة التوصيل...</span>
                  </div>
                )}

                {healthData?.checks.map((check) => (
                  <div
                    key={check.id}
                    className="bg-[#071322] border border-slate-800 hover:border-slate-700/80 rounded-2xl p-4 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 border ${
                          check.healthy
                            ? 'bg-emerald-950/80 text-emerald-400 border-emerald-600/40'
                            : 'bg-amber-950/80 text-amber-400 border-amber-600/40'
                        }`}
                      >
                        {check.healthy ? '✓' : '!'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white">{check.name}</h4>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              check.healthy
                                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                                : 'bg-amber-950/80 text-amber-300 border-amber-500/50'
                            }`}
                          >
                            {check.status}
                          </span>
                          {check.latencyMs !== undefined && (
                            <span className="text-[10px] text-slate-400 font-mono">
                              ({check.latencyMs}ms)
                            </span>
                          )}
                        </div>
                        <p className="text-slate-300 text-xs mt-1">{check.details}</p>
                        {check.url && (
                          <span className="text-[10px] text-cyan-400 font-mono mt-0.5 block truncate max-w-md dir-ltr text-left">
                            {check.url}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                      {check.id.startsWith('n8n_') && (
                        <button
                          onClick={() => {
                            setActiveTab('webhooks');
                            if (check.id === 'n8n_whatsapp') handleCheckPlatform('whatsapp');
                            if (check.id === 'n8n_messenger') handleCheckPlatform('messenger');
                          }}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs rounded-xl font-bold transition-colors cursor-pointer"
                        >
                          اختبار المسار
                        </button>
                      )}
                      {check.id === 'meta_graph' && (
                        <button
                          onClick={() => setActiveTab('channels')}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs rounded-xl font-bold transition-colors cursor-pointer"
                        >
                          عرض بيانات Meta
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: APPEARANCE & THEMES */}
          {activeTab === 'appearance' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white mb-1">سمات وألوان التمييز (Accent Theme Presets)</h3>
                <p className="text-xs text-slate-400">اختر لوحة الألوان المناسبة لمظهر الواجهة والبطاقات</p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {ACCENT_PRESETS.map((preset) => {
                  const isSelected = tempPrefs.accentId === preset.id;
                  return (
                    <button
                      key={preset.id}
                      onClick={() => handleApplyPreset(preset)}
                      className={`p-3.5 rounded-xl border text-right transition-all flex flex-col justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-[#091b30] border-cyan-400 shadow-md shadow-cyan-950/40 ring-2 ring-cyan-500/20'
                          : 'bg-[#071322] border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div
                          className="w-5 h-5 rounded-full shadow-inner border border-white/20"
                          style={{ backgroundColor: preset.primary }}
                        />
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
                      </div>
                      <span className="text-xs font-bold text-white block">{preset.name}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{preset.nameEn}</span>
                    </button>
                  );
                })}
              </div>

              <div className="bg-[#071322] border border-slate-800 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white">المؤثرات الصوتية للتفاعل (UI Chimes)</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">تشغيل صوت نقر وتأكيد خفيف عند حفظ الإعدادات أو الإجراءات</p>
                </div>
                <button
                  onClick={() => {
                    const updated = { ...tempPrefs, soundEffects: !tempPrefs.soundEffects };
                    setTempPrefs(updated);
                    if (onUpdatePreferences) onUpdatePreferences(updated);
                    ThemeService.applyTheme(updated);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                    tempPrefs.soundEffects
                      ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300'
                      : 'bg-slate-900 border-slate-700 text-slate-400'
                  }`}
                >
                  {tempPrefs.soundEffects ? 'مفعل' : 'معطل'}
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: NOTIFICATIONS API */}
          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <div className="bg-[#071322] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
                      <Bell className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">إشعارات المتصفح لسطح المكتب (Web Notifications API)</h4>
                      <p className="text-xs text-slate-400 mt-0.5">
                        استقبال تنبيهات فورية عند ورود رسالة عميل جديدة أو اقتراب موعد تذكير هام
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-full border ${
                      notificationPermission === 'granted'
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                        : notificationPermission === 'denied'
                        ? 'bg-red-950/80 text-red-300 border-red-500/40'
                        : 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                    }`}
                  >
                    {notificationPermission === 'granted'
                      ? 'مفعلة (Granted)'
                      : notificationPermission === 'denied'
                      ? 'محظورة (Denied)'
                      : 'في انتظار الإذن (Default)'}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  {notificationPermission !== 'granted' ? (
                    <button
                      onClick={handleRequestNotificationPermission}
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-black text-xs font-bold rounded-xl transition-all cursor-pointer shadow-md"
                    >
                      طلب تفعيل إشعارات سطح المكتب
                    </button>
                  ) : (
                    <button
                      onClick={handleSendTestNotification}
                      className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-2"
                    >
                      <Send className="w-3.5 h-3.5 text-cyan-400" />
                      <span>إرسال إشعار تجريبي الآن</span>
                    </button>
                  )}

                  {testNotificationSent && (
                    <span className="text-xs text-emerald-400 flex items-center gap-1 font-semibold animate-pulse">
                      <Check className="w-4 h-4" />
                      تم إرسال الإشعار إلى سطح المكتب!
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CHANNELS & META INFO */}
          {activeTab === 'channels' && (
            <div className="space-y-4">
              <div className="bg-[#071322] border border-cyan-900/60 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-cyan-950/80 pb-3">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>تكامل منصة Meta Graph API الرسمية — Relax Fix UAE Platform</span>
                  </h4>
                  <span className="text-[10px] bg-emerald-950/80 text-emerald-300 border border-emerald-500/50 px-2 py-0.5 rounded-full font-mono">
                    App ID: 980385998373405
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[11px]">اسم التطبيق في Meta</span>
                    <p className="font-bold text-slate-100 flex items-center justify-between">
                      <span>Relax Fix UAE Platform</span>
                      <span className="text-[10px] text-cyan-400 font-mono">أنشطة تجارية وصفحات</span>
                    </p>
                    <p className="text-[10px] text-slate-500 font-mono">ID: 980385998373405</p>
                  </div>

                  <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[11px]">حساب Instagram للأعمال المرتبط</span>
                    <p className="font-bold text-pink-300 flex items-center justify-between">
                      <span>@relaxfixuae (Relax Fix one)</span>
                      <span className="text-[10px] text-emerald-400 font-mono">معين لـ 2 أشخاص</span>
                    </p>
                    <p className="text-[10px] text-slate-500 font-mono">Asset ID: 1164107840123575</p>
                  </div>

                  <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[11px]">تطبيق Threads المرتبط</span>
                    <p className="font-bold text-slate-200">Relax Fix UAE Platform</p>
                    <p className="text-[10px] text-slate-500 font-mono">Threads App ID: 2511896295978588</p>
                  </div>

                  <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[11px]">نطاقات التطبيق ومسار الـ Hub</span>
                    <p className="font-bold text-cyan-300 font-mono">hub.relaxfixuae.com</p>
                    <p className="text-[10px] text-slate-400">relaxfixuae.com</p>
                  </div>

                  <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[11px]">البريد الرسمي المعتمد للتواصل</span>
                    <p className="font-bold text-slate-200 font-mono">swimmingayman@gmail.com</p>
                    <span className="text-[10px] text-slate-500">مسؤول الاتصال وحماية البيانات</span>
                  </div>

                  <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[11px]">سياسة الخصوصية وحذف البيانات</span>
                    <p className="font-mono text-[11px] text-slate-300 truncate">https://hub.relaxfixuae.com/privacy-policy/</p>
                    <p className="font-mono text-[10px] text-slate-500 truncate">/user-data-deletion/</p>
                  </div>
                </div>

                <div className="p-3.5 bg-cyan-950/30 rounded-xl border border-cyan-800/40 text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="text-slate-300">
                      بيانات Meta موثقة وجاهزة للربط مع n8n لنشر محتوى مصنع الإعلانات والـ 30 يوماً تلقائياً.
                    </span>
                  </div>
                  <button
                    onClick={() => setActiveTab('webhooks')}
                    className="px-3 py-1.5 bg-cyan-700 hover:bg-cyan-600 text-white font-bold rounded-lg text-[11px] transition-colors cursor-pointer shrink-0"
                  >
                    ضبط روابط الويبهوك
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-cyan-950/80 bg-[#06101c] flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>نظام التشغيل متصل وجاهز للاستقبال السحابي</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
