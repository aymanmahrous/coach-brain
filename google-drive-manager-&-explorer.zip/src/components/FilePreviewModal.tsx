import React from 'react';
import { 
  X, 
  ExternalLink, 
  Sparkles, 
  Download, 
  Calendar, 
  HardDrive, 
  User, 
  FileText, 
  Tag,
  Star,
  Copy,
  Check,
  Share2,
  ScanText,
  Film,
  Send
} from 'lucide-react';
import { DriveFile } from '../types';
import { formatBytes, formatDate, getFileTypeMeta } from '../services/driveService';
import { OCRService } from '../services/ocrService';
import { VeoService } from '../services/veoService';

interface FilePreviewModalProps {
  file: DriveFile | null;
  onClose: () => void;
  onAIAnalyze: (file: DriveFile) => void;
  onStarToggle: (file: DriveFile) => void;
  onShare?: (file: DriveFile) => void;
  onOCR?: (file: DriveFile) => void;
  onVeoAnimate?: (file: DriveFile) => void;
  onSendToAutomation?: (file: DriveFile) => void;
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({
  file,
  onClose,
  onAIAnalyze,
  onStarToggle,
  onShare,
  onOCR,
  onVeoAnimate,
  onSendToAutomation,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!file) return null;

  const meta = getFileTypeMeta(file.mimeType);
  const isFolder = file.mimeType === 'application/vnd.google-apps.folder';

  const handleCopyLink = () => {
    if (file.webViewLink) {
      navigator.clipboard.writeText(file.webViewLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div className="flex items-center gap-3">
            <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${meta.color}`}>
              {meta.label}
            </span>
            <button
              onClick={() => onStarToggle(file)}
              className={`p-1.5 rounded-lg transition-colors ${
                file.starred ? 'text-amber-500 bg-amber-50' : 'text-slate-400 hover:text-amber-500'
              }`}
            >
              <Star className={`w-4 h-4 ${file.starred ? 'fill-amber-400' : ''}`} />
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex flex-col gap-6">
          {/* File Title */}
          <div>
            <h2 className="text-xl font-bold text-slate-900 leading-tight mb-1">
              {file.name}
            </h2>
            {file.description && (
              <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 mt-2">
                {file.description}
              </p>
            )}
          </div>

          {/* Thumbnail preview if available */}
          {file.thumbnailLink && (
            <div className="w-full h-48 rounded-2xl overflow-hidden bg-slate-100 border border-slate-200/60 flex items-center justify-center">
              <img 
                src={file.thumbnailLink} 
                alt={file.name} 
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain" 
              />
            </div>
          )}

          {/* Metadata Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center gap-3">
              <HardDrive className="w-5 h-5 text-blue-600 shrink-0" />
              <div>
                <span className="text-[11px] text-slate-400 block font-medium">الحجم</span>
                <span className="text-sm font-bold text-slate-800">
                  {isFolder ? 'مجلد' : formatBytes(file.size)}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center gap-3">
              <Calendar className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <span className="text-[11px] text-slate-400 block font-medium">آخر تعديل</span>
                <span className="text-sm font-bold text-slate-800">
                  {formatDate(file.modifiedTime)}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center gap-3">
              <User className="w-5 h-5 text-indigo-600 shrink-0" />
              <div>
                <span className="text-[11px] text-slate-400 block font-medium">المالك</span>
                <span className="text-sm font-bold text-slate-800">
                  {file.owners?.[0]?.displayName || file.owners?.[0]?.emailAddress || 'أنا'}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center gap-3">
              <Tag className="w-5 h-5 text-purple-600 shrink-0" />
              <div>
                <span className="text-[11px] text-slate-400 block font-medium">معرف الملف (File ID)</span>
                <span className="text-xs font-mono font-semibold text-slate-600 truncate block max-w-[170px]">
                  {file.id}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 px-6 border-t border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex flex-wrap items-center gap-2">
            {!isFolder && (
              <button
                onClick={() => {
                  onClose();
                  onAIAnalyze(file);
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-500/20 transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4 animate-pulse" />
                <span>تحليل وتلخيص بالـ AI</span>
              </button>
            )}

            {!isFolder && onOCR && OCRService.isOCRSupported(file) && (
              <button
                onClick={() => {
                  onClose();
                  onOCR(file);
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-xl shadow-md shadow-violet-500/20 transition-all cursor-pointer"
                title="استخراج كامل النصوص والجداول من الصورة أو الـ PDF وتحويلها لمستند نصي"
              >
                <ScanText className="w-4 h-4" />
                <span>استخراج النصوص (OCR)</span>
              </button>
            )}

            {!isFolder && onVeoAnimate && VeoService.isVeoSupported(file) && (
              <button
                onClick={() => {
                  onClose();
                  onVeoAnimate(file);
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-600 via-rose-600 to-indigo-600 hover:from-amber-700 hover:via-rose-700 hover:to-indigo-700 text-white font-bold text-xs rounded-xl shadow-md shadow-rose-500/20 transition-all cursor-pointer"
                title="تحريك الصورة إلى فيديو سينمائي عبر Google Veo"
              >
                <Film className="w-4 h-4" />
                <span>تحريك لفيديو (Veo)</span>
              </button>
            )}

            {!isFolder && onSendToAutomation && (
              <button
                onClick={() => {
                  onClose();
                  onSendToAutomation(file);
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
                title="إرسال بيانات الملف إلى نقاط النهاية الخاصة بـ n8n (WhatsApp / Messenger)"
              >
                <Send className="w-4 h-4" />
                <span>إرسال إلى الأتمتة</span>
              </button>
            )}

            {onShare && (
              <button
                onClick={() => {
                  onClose();
                  onShare(file);
                }}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100/80 rounded-xl transition-colors border border-blue-200"
              >
                <Share2 className="w-3.5 h-3.5 text-blue-600" />
                <span>مشاركة (Share)</span>
              </button>
            )}

            {file.webViewLink && (
              <button
                onClick={handleCopyLink}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200/70 rounded-xl transition-colors border border-slate-200"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'تم النسخ!' : 'نسخ الرابط'}</span>
              </button>
            )}
          </div>

          {file.webViewLink && (
            <a
              href={file.webViewLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-all shadow-sm"
            >
              <span>فتح في Google Drive</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </div>
      </div>
    </div>
  );
};
