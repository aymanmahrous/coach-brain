/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  FolderPlus, 
  Upload, 
  FilePlus2, 
  Sparkles, 
  HardDrive, 
  Search, 
  Info, 
  CheckCircle2, 
  AlertCircle,
  FolderOpen,
  ArrowRight,
  ShieldCheck,
  Folder,
  Layers,
  Filter,
  RefreshCw,
  X,
  Receipt,
  BarChart3,
  Rocket,
  FileCheck2,
  GraduationCap,
  Palette,
  FolderGit2,
  Bell,
  Clock,
  Archive
} from 'lucide-react';
import { 
  DriveFile, 
  DriveAbout, 
  DriveCategoryFilter, 
  ViewMode, 
  BreadcrumbItem,
  AICategoryClassification,
  AICategoryKey,
  FileReminder,
  AdvancedSearchFilters,
  DEFAULT_SEARCH_FILTERS,
  SortOption
} from './types';
import { DriveService } from './services/driveService';
import { AICategorizeService, AI_CATEGORIES } from './services/aiCategorizeService';
import { ReminderService } from './services/reminderService';
import { NotificationService } from './services/notificationService';
import { SoundEffects } from './utils/audioChime';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Breadcrumbs } from './components/Breadcrumbs';
import { FileCard } from './components/FileCard';
import { FileTableRow } from './components/FileTableRow';
import { FilePreviewModal } from './components/FilePreviewModal';
import { AIInsightModal } from './components/AIInsightModal';
import { UploadModal } from './components/UploadModal';
import { NewFolderModal } from './components/NewFolderModal';
import { NewDocModal } from './components/NewDocModal';
import { RenameModal } from './components/RenameModal';
import { OAuthModal } from './components/OAuthModal';
import { QuickLookDrawer } from './components/QuickLookDrawer';
import { DragDropOverlay } from './components/DragDropOverlay';
import { ReminderModal } from './components/ReminderModal';
import { ReminderNotificationBanner } from './components/ReminderNotificationBanner';
import { ShareModal } from './components/ShareModal';
import { BatchActionBar } from './components/BatchActionBar';
import { SortControls } from './components/SortControls';
import { KeyboardShortcutsModal } from './components/KeyboardShortcutsModal';
import { FolderAnalysisDrawer } from './components/FolderAnalysisDrawer';
import { BulkRenameModal } from './components/BulkRenameModal';
import { OCRModal } from './components/OCRModal';
import { VeoVideoModal } from './components/VeoVideoModal';
import { FolderBackupModal } from './components/FolderBackupModal';
import { ThemeSettingsModal } from './components/ThemeSettingsModal';
import { SettingsModal } from './components/SettingsModal';
import { SendToAutomationModal } from './components/SendToAutomationModal';
import { ThemeService, UserThemePreferences } from './services/themeService';
import { BrainCircuit } from 'lucide-react';
import { CommandCenterPreview } from './components/CommandCenterPreview';

export default function App() {
  // Toggle to view proposed Command Center Hub
  const [isShowingCommandCenter, setIsShowingCommandCenter] = useState<boolean>(true);

  // State
  const [token, setToken] = useState<string | null>(DriveService.getStoredToken());
  const [aboutInfo, setAboutInfo] = useState<DriveAbout | null>(null);
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Multi-Selection State
  const [selectedFileIds, setSelectedFileIds] = useState<Set<string>>(new Set());

  // Sorting State
  const [sortOption, setSortOption] = useState<SortOption>({
    field: 'modifiedTime',
    direction: 'desc',
  });

  // Keyboard Shortcuts Modal State
  const [isShortcutsModalOpen, setIsShortcutsModalOpen] = useState(false);

  // Reminders State
  const [reminders, setReminders] = useState<FileReminder[]>(() => ReminderService.getReminders());
  const [fileForReminder, setFileForReminder] = useState<DriveFile | null>(null);
  const [isReminderModalOpen, setIsReminderModalOpen] = useState(false);
  const [dismissedReminderIds, setDismissedReminderIds] = useState<Set<string>>(new Set());

  // AI Categorization State
  const [aiClassifications, setAiClassifications] = useState<Record<string, AICategoryClassification>>({});
  const [isCategorizing, setIsCategorizing] = useState(false);

  // Filters & Navigation
  const [currentCategory, setCurrentCategory] = useState<DriveCategoryFilter>('all');
  const [breadcrumbs, setBreadcrumbs] = useState<BreadcrumbItem[]>([]);
  const [searchFilters, setSearchFilters] = useState<AdvancedSearchFilters>(DEFAULT_SEARCH_FILTERS);
  const [viewMode, setViewMode] = useState<ViewMode>('grid');

  // Modals & Drawers
  const [previewFile, setPreviewFile] = useState<DriveFile | null>(null);
  const [quickLookFile, setQuickLookFile] = useState<DriveFile | null>(null);
  const [shareModalFile, setShareModalFile] = useState<DriveFile | null>(null);
  const [aiSelectedFile, setAiSelectedFile] = useState<DriveFile | null>(null);
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [isFolderAnalysisOpen, setIsFolderAnalysisOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isNewFolderModalOpen, setIsNewFolderModalOpen] = useState(false);
  const [isNewDocModalOpen, setIsNewDocModalOpen] = useState(false);
  const [isOAuthModalOpen, setIsOAuthModalOpen] = useState(false);
  const [fileToRename, setFileToRename] = useState<DriveFile | null>(null);
  const [isBulkRenameModalOpen, setIsBulkRenameModalOpen] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isDesktopSidebarCollapsed, setIsDesktopSidebarCollapsed] = useState(false);

  // OCR Modal State
  const [ocrFile, setOcrFile] = useState<DriveFile | null>(null);
  const [ocrCustomBase64, setOcrCustomBase64] = useState<string | undefined>(undefined);
  const [isOCRModalOpen, setIsOCRModalOpen] = useState(false);

  // Veo Video Generation Modal State
  const [veoFile, setVeoFile] = useState<DriveFile | null>(null);
  const [veoCustomBase64, setVeoCustomBase64] = useState<string | undefined>(undefined);
  const [isVeoModalOpen, setIsVeoModalOpen] = useState(false);

  // Folder Backup (ZIP Archive) Modal State
  const [isFolderBackupOpen, setIsFolderBackupOpen] = useState(false);
  const [backupTargetFolder, setBackupTargetFolder] = useState<{ id: string; name: string; files: DriveFile[] } | null>(null);

  // Custom Theme & Accent Colors State
  const [themePreferences, setThemePreferences] = useState<UserThemePreferences>(() => ThemeService.getPreferences());
  const [isThemeModalOpen, setIsThemeModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // n8n Automation Engine State (Send to Automation)
  const [automationFile, setAutomationFile] = useState<DriveFile | null>(null);
  const [isAutomationModalOpen, setIsAutomationModalOpen] = useState(false);

  const handleOpenAutomation = (file: DriveFile) => {
    setAutomationFile(file);
    setIsAutomationModalOpen(true);
  };

  // Apply initial theme on mount and whenever preferences update
  useEffect(() => {
    ThemeService.applyTheme(themePreferences);
  }, [themePreferences]);

  // Drag and Drop Upload State
  const [isPageDragging, setIsPageDragging] = useState(false);
  const [isDropUploading, setIsDropUploading] = useState(false);
  const dragCounterRef = React.useRef(0);

  // Active folder ID
  const currentFolderId = breadcrumbs.length > 0 ? breadcrumbs[breadcrumbs.length - 1].id : 'root';
  const currentFolderName = breadcrumbs.length > 0 ? breadcrumbs[breadcrumbs.length - 1].name : 'ملفاتي الرئيسية';

  // AI Classification Trigger
  const runAICategorization = useCallback(async (fileList: DriveFile[], forceRefresh = false) => {
    if (!fileList || fileList.length === 0) return;
    setIsCategorizing(true);
    try {
      const results = await AICategorizeService.categorizeFiles(fileList, forceRefresh);
      setAiClassifications(results);
    } catch (err) {
      console.warn('AI Categorization warning:', err);
    } finally {
      setIsCategorizing(false);
    }
  }, []);

  // Load user info
  const loadAboutInfo = useCallback(async (authToken: string | null) => {
    try {
      const data = await DriveService.getAbout(authToken);
      setAboutInfo(data);
    } catch (e) {
      console.warn('Could not load about info:', e);
    }
  }, []);

  // Load Files
  const loadFiles = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const isTrash = currentCategory === 'trash';
      const isStarred = currentCategory === 'starred' || searchFilters.onlyStarred;
      const isAICat = currentCategory.startsWith('ai_');
      const folderId = (currentCategory === 'all' && breadcrumbs.length > 0) ? currentFolderId : undefined;

      const res = await DriveService.listFiles(token, {
        folderId,
        category: isAICat ? 'all' : currentCategory,
        searchQuery: searchFilters.query,
        trashed: isTrash,
        starred: isStarred,
        dateModified: searchFilters.dateModified,
        typeFilter: searchFilters.type,
      });

      setFiles(res.files);
      // Run or update AI categorization in background
      runAICategorization(res.files);
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء جلب الملفات.');
    } finally {
      setIsLoading(false);
    }
  }, [token, currentCategory, breadcrumbs, currentFolderId, searchFilters, runAICategorization]);

  // Initial Load & on Token Change
  useEffect(() => {
    loadAboutInfo(token);
    loadFiles();
  }, [token, loadAboutInfo, loadFiles]);

  // Periodic check & sync for Reminders + Web Notifications API
  useEffect(() => {
    const syncAndNotifyReminders = () => {
      const currentReminders = ReminderService.getReminders();
      setReminders(currentReminders);
      // Trigger Web Notifications API for approaching (within 15 minutes) and due reminders
      NotificationService.checkAndNotifyReminders(currentReminders, 15);
    };

    // Run immediately on mount
    syncAndNotifyReminders();

    const interval = setInterval(syncAndNotifyReminders, 10000);
    window.addEventListener('storage', syncAndNotifyReminders);
    return () => {
      clearInterval(interval);
      window.removeEventListener('storage', syncAndNotifyReminders);
    };
  }, []);

  // Listen for desktop notification click to focus and open target file
  useEffect(() => {
    const handleOpenReminderFile = (e: Event) => {
      const customEvent = e as CustomEvent<{ fileId: string; reminderId?: string }>;
      if (customEvent.detail?.fileId) {
        handleOpenFileFromReminder(customEvent.detail.fileId);
      }
    };
    window.addEventListener('app:open-reminder-file', handleOpenReminderFile);
    return () => {
      window.removeEventListener('app:open-reminder-file', handleOpenReminderFile);
    };
  }, [files, reminders]);

  // Map reminders for quick file lookup
  const remindersMap = useMemo(() => {
    const map = new Map<string, FileReminder>();
    for (const r of reminders) {
      map.set(r.fileId, r);
    }
    return map;
  }, [reminders]);

  // Due reminders for in-app alert banner
  const dueReminders = useMemo(() => {
    return ReminderService.getDueReminders().filter((r) => !dismissedReminderIds.has(r.id));
  }, [reminders, dismissedReminderIds]);

  // Filtered files calculation
  const displayedFiles = useMemo(() => {
    let result = files;

    // Reminders Category View
    if (currentCategory === 'reminders') {
      const knownFileIds = new Set(files.map((f) => f.id));
      const reminderFiles: DriveFile[] = files.filter((f) => remindersMap.has(f.id));
      
      // Also synthesize any scheduled files from other directories if not in current memory
      for (const rem of reminders) {
        if (!knownFileIds.has(rem.fileId)) {
          reminderFiles.push({
            id: rem.fileId,
            name: rem.fileName,
            mimeType: rem.fileMimeType || 'application/vnd.google-apps.document',
            modifiedTime: rem.createdAt || new Date().toISOString(),
            size: '0',
            starred: false,
          });
        }
      }
      result = reminderFiles;
    }

    // AI Category Sidebar Filter
    if (currentCategory.startsWith('ai_')) {
      const aiKey = currentCategory.replace('ai_', '') as AICategoryKey;
      result = result.filter((file) => {
        if (file.mimeType === 'application/vnd.google-apps.folder') return false;
        const classification = aiClassifications[file.id] || AICategorizeService.getCachedOrHeuristicCategory(file);
        return classification.category === aiKey;
      });
    }

    // Advanced Search: Text Query
    if (searchFilters.query && searchFilters.query.trim()) {
      const q = searchFilters.query.toLowerCase().trim();
      result = result.filter((f) => {
        const nameMatch = f.name.toLowerCase().includes(q);
        const descMatch = f.description ? f.description.toLowerCase().includes(q) : false;
        return nameMatch || descMatch;
      });
    }

    // Advanced Search: File Type Filter
    if (searchFilters.type !== 'all') {
      result = result.filter((f) => {
        if (searchFilters.type === 'folders') return f.mimeType === 'application/vnd.google-apps.folder';
        if (searchFilters.type === 'docs') return f.mimeType.includes('document') || f.mimeType.includes('text');
        if (searchFilters.type === 'sheets') return f.mimeType.includes('spreadsheet') || f.mimeType.includes('excel') || f.mimeType.includes('csv');
        if (searchFilters.type === 'slides') return f.mimeType.includes('presentation') || f.mimeType.includes('powerpoint');
        if (searchFilters.type === 'pdf') return f.mimeType.includes('pdf');
        if (searchFilters.type === 'images') return f.mimeType.startsWith('image/');
        return true;
      });
    }

    // Advanced Search: Date Modified Filter (Today, Week, Month, Year)
    if (searchFilters.dateModified !== 'all') {
      const now = Date.now();
      let ms = 0;
      if (searchFilters.dateModified === 'today') ms = 24 * 60 * 60 * 1000;
      else if (searchFilters.dateModified === 'week') ms = 7 * 24 * 60 * 60 * 1000;
      else if (searchFilters.dateModified === 'month') ms = 30 * 24 * 60 * 60 * 1000;
      else if (searchFilters.dateModified === 'year') ms = 365 * 24 * 60 * 60 * 1000;

      if (ms > 0) {
        const cutoff = now - ms;
        result = result.filter((f) => {
          if (!f.modifiedTime) return false;
          return new Date(f.modifiedTime).getTime() >= cutoff;
        });
      }
    }

    // Advanced Search: Starred Only
    if (searchFilters.onlyStarred) {
      result = result.filter((f) => f.starred);
    }

    // Advanced Search: Reminders Only
    if (searchFilters.onlyReminders) {
      result = result.filter((f) => remindersMap.has(f.id));
    }

    // Advanced Search: AI Smart Category
    if (searchFilters.aiCategory !== 'all') {
      result = result.filter((f) => {
        if (f.mimeType === 'application/vnd.google-apps.folder') return false;
        const classification = aiClassifications[f.id] || AICategorizeService.getCachedOrHeuristicCategory(f);
        return classification.category === searchFilters.aiCategory;
      });
    }

    // Apply Sorting
    return [...result].sort((a, b) => {
      // Keep folders at top
      if (a.mimeType === 'application/vnd.google-apps.folder' && b.mimeType !== 'application/vnd.google-apps.folder') return -1;
      if (b.mimeType === 'application/vnd.google-apps.folder' && a.mimeType !== 'application/vnd.google-apps.folder') return 1;

      let comparison = 0;
      if (sortOption.field === 'name') {
        comparison = a.name.localeCompare(b.name, 'ar', { sensitivity: 'base' });
      } else if (sortOption.field === 'modifiedTime') {
        const timeA = a.modifiedTime ? new Date(a.modifiedTime).getTime() : 0;
        const timeB = b.modifiedTime ? new Date(b.modifiedTime).getTime() : 0;
        comparison = timeA - timeB;
      } else if (sortOption.field === 'size') {
        const sizeA = Number(a.size || 0);
        const sizeB = Number(b.size || 0);
        comparison = sizeA - sizeB;
      } else if (sortOption.field === 'type') {
        comparison = (a.mimeType || '').localeCompare(b.mimeType || '');
      }

      return sortOption.direction === 'asc' ? comparison : -comparison;
    });
  }, [files, currentCategory, aiClassifications, remindersMap, reminders, searchFilters, sortOption]);

  // Selected Files list
  const selectedFiles = useMemo(() => {
    return files.filter((f) => selectedFileIds.has(f.id));
  }, [files, selectedFileIds]);

  // Multi-Selection Handlers
  const handleToggleSelectFile = useCallback((file: DriveFile) => {
    SoundEffects.playPop();
    setSelectedFileIds((prev) => {
      const next = new Set(prev);
      if (next.has(file.id)) next.delete(file.id);
      else next.add(file.id);
      return next;
    });
  }, []);

  const handleSelectAll = useCallback(() => {
    SoundEffects.playPop();
    setSelectedFileIds(new Set(displayedFiles.map((f) => f.id)));
  }, [displayedFiles]);

  const handleClearSelection = useCallback(() => {
    SoundEffects.playPop();
    setSelectedFileIds(new Set());
  }, []);

  // Batch Operations
  const handleBatchStar = async (star: boolean) => {
    if (selectedFileIds.size === 0) return;
    const targetIds: string[] = Array.from(selectedFileIds);
    SoundEffects.playSuccess();

    // Optimistic
    setFiles((prev) => prev.map((f) => targetIds.includes(f.id) ? { ...f, starred: star } : f));
    try {
      await Promise.all(targetIds.map((id: string) => DriveService.toggleStar(token, id, star)));
    } catch {
      await loadFiles();
    }
  };

  const handleBatchDelete = async () => {
    if (selectedFileIds.size === 0) return;
    const count = selectedFileIds.size;
    const isPermanent = currentCategory === 'trash';
    const msg = isPermanent
      ? `هل أنت متأكد من الحذف النهائي لـ ${count} عناصر محددة؟`
      : `هل تريد نقل ${count} عناصر محددة إلى سلة المهملات؟`;

    if (!window.confirm(msg)) return;

    SoundEffects.playPop();
    const targetIds: string[] = Array.from(selectedFileIds);
    setSelectedFileIds(new Set());

    // Optimistic
    setFiles((prev) => prev.filter((f) => !targetIds.includes(f.id)));

    try {
      await Promise.all(targetIds.map((id: string) => DriveService.trashOrDeleteFile(token, id, isPermanent)));
    } catch (e: any) {
      alert(e.message || 'حدث خطأ أثناء تنفيذ الحذف الجماعي.');
      await loadFiles();
    }
  };

  const handleBatchAIAnalyze = () => {
    if (selectedFiles.length > 0) {
      setAiSelectedFile(selectedFiles[0]);
      setIsAIModalOpen(true);
    }
  };

  const handleBatchOpenLinks = () => {
    selectedFiles.forEach((file) => {
      if (file.webViewLink) {
        window.open(file.webViewLink, '_blank');
      }
    });
  };

  const handleBulkRename = async (renames: { fileId: string; newName: string }[]) => {
    if (!renames || renames.length === 0) return;

    // Optimistic UI Update
    setFiles((prev) =>
      prev.map((f) => {
        const found = renames.find((r) => r.fileId === f.id);
        return found ? { ...f, name: found.newName } : f;
      })
    );

    // Call API for each rename in parallel batches
    const renamePromises = renames.map(({ fileId, newName }) =>
      DriveService.renameFile(token, fileId, newName)
    );

    await Promise.all(renamePromises);
    setSelectedFileIds(new Set());
    await loadFiles();
  };

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) {
        return;
      }

      if (e.key === '?') {
        e.preventDefault();
        setIsShortcutsModalOpen((prev) => !prev);
      } else if (e.key === 'Escape') {
        if (isShortcutsModalOpen) setIsShortcutsModalOpen(false);
        else if (isMobileSidebarOpen) setIsMobileSidebarOpen(false);
        else if (isFolderAnalysisOpen) setIsFolderAnalysisOpen(false);
        else if (isBulkRenameModalOpen) setIsBulkRenameModalOpen(false);
        else if (selectedFileIds.size > 0) setSelectedFileIds(new Set());
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
        e.preventDefault();
        setIsDesktopSidebarCollapsed((prev) => !prev);
        SoundEffects.playPop();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        setSelectedFileIds(new Set(displayedFiles.map((f) => f.id)));
      } else if (e.key === 'F2' && selectedFileIds.size > 0) {
        e.preventDefault();
        setIsBulkRenameModalOpen(true);
      } else if (e.key === 'Delete' && selectedFileIds.size > 0) {
        e.preventDefault();
        handleBatchDelete();
      } else if (e.key.toLowerCase() === 'g' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setViewMode((prev) => (prev === 'grid' ? 'list' : 'grid'));
        SoundEffects.playPop();
      } else if (e.key.toLowerCase() === 'f' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setIsFolderAnalysisOpen((prev) => !prev);
        SoundEffects.playPop();
      } else if (e.key.toLowerCase() === 'u' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setIsUploadModalOpen(true);
      } else if (e.key.toLowerCase() === 'n' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setIsNewFolderModalOpen(true);
      } else if (e.key.toLowerCase() === 'd' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setIsNewDocModalOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [displayedFiles, selectedFileIds, isShortcutsModalOpen]);

  // Handle Google Auth Connect
  const handleConnectGoogle = async () => {
    try {
      setIsLoading(true);
      const accessToken = await DriveService.requestGoogleAuth();
      setToken(accessToken);
      await loadAboutInfo(accessToken);
      await loadFiles();
    } catch (e: any) {
      alert(e.message || 'تعذر استكمال تسجيل الدخول بحساب Google.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Disconnect
  const handleDisconnect = () => {
    DriveService.clearStoredToken();
    setToken(null);
    setAboutInfo(null);
    setBreadcrumbs([]);
    setCurrentCategory('all');
  };

  // Navigate into a folder
  const handleOpenFile = (file: DriveFile) => {
    if (file.mimeType === 'application/vnd.google-apps.folder') {
      setCurrentCategory('all');
      setBreadcrumbs((prev) => [...prev, { id: file.id, name: file.name }]);
      setSearchFilters(DEFAULT_SEARCH_FILTERS);
    } else {
      setPreviewFile(file);
    }
  };

  // Breadcrumb navigation
  const handleNavigateBreadcrumb = (index: number) => {
    if (index === -1) {
      setBreadcrumbs([]);
    } else {
      setBreadcrumbs((prev) => prev.slice(0, index + 1));
    }
    setSearchFilters(DEFAULT_SEARCH_FILTERS);
  };

  // Star Toggle
  const handleStarToggle = async (file: DriveFile) => {
    SoundEffects.playPop();
    const newStarred = !file.starred;
    // Optimistic update
    setFiles((prev) => prev.map((f) => (f.id === file.id ? { ...f, starred: newStarred } : f)));
    if (previewFile?.id === file.id) {
      setPreviewFile((prev) => (prev ? { ...prev, starred: newStarred } : null));
    }

    try {
      await DriveService.toggleStar(token, file.id, newStarred);
    } catch (e) {
      // Revert on error
      setFiles((prev) => prev.map((f) => (f.id === file.id ? { ...f, starred: !newStarred } : f)));
    }
  };

  // Delete or Trash File
  const handleDeleteFile = async (file: DriveFile) => {
    const isPermanent = currentCategory === 'trash';
    const confirmText = isPermanent
      ? `هل أنت متأكد من الحذف النهائي للملف "${file.name}"؟`
      : `هل تريد نقل "${file.name}" إلى سلة المهملات؟`;

    if (!window.confirm(confirmText)) return;

    SoundEffects.playPop();
    // Optimistic update
    setFiles((prev) => prev.filter((f) => f.id !== file.id));
    if (previewFile?.id === file.id) setPreviewFile(null);

    try {
      await DriveService.trashOrDeleteFile(token, file.id, isPermanent);
    } catch (e: any) {
      alert(e.message || 'فشل في حذف الملف.');
      loadFiles();
    }
  };

  // Restore File
  const handleRestoreFile = async (file: DriveFile) => {
    SoundEffects.playSuccess();
    setFiles((prev) => prev.filter((f) => f.id !== file.id));
    try {
      await DriveService.restoreFile(token, file.id);
    } catch (e: any) {
      alert(e.message || 'فشل في استعادة الملف.');
      loadFiles();
    }
  };

  // Upload File
  const handleUpload = async (file: File) => {
    await DriveService.uploadFile(token, file, currentFolderId);
    SoundEffects.playSuccess();
    await loadFiles();
    await loadAboutInfo(token);
  };

  // Drag and drop event handlers for main file drop zone
  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.types && Array.from(e.dataTransfer.types).includes('Files')) {
      dragCounterRef.current += 1;
      setIsPageDragging(true);
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounterRef.current -= 1;
    if (dragCounterRef.current <= 0) {
      dragCounterRef.current = 0;
      setIsPageDragging(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) {
      e.dataTransfer.dropEffect = 'copy';
    }
  };

  const handleFilesDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounterRef.current = 0;
    setIsPageDragging(false);

    const droppedFiles = e.dataTransfer.files;
    if (!droppedFiles || droppedFiles.length === 0) return;

    setIsDropUploading(true);
    try {
      // Upload all dropped files sequentially
      for (let i = 0; i < droppedFiles.length; i++) {
        const file = droppedFiles[i];
        await DriveService.uploadFile(token, file, currentFolderId);
      }
      SoundEffects.playSuccess();
      await loadFiles();
      await loadAboutInfo(token);
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء رفع الملفات التي تم إفلاتها.');
      await loadFiles();
    } finally {
      setIsDropUploading(false);
    }
  };

  // Create Folder
  const handleCreateFolder = async (name: string) => {
    await DriveService.createFolder(token, name, currentFolderId);
    SoundEffects.playSuccess();
    await loadFiles();
  };

  // Create Document
  const handleCreateDoc = async (title: string, content: string) => {
    await DriveService.createTextDocument(token, title, content, currentFolderId);
    SoundEffects.playSuccess();
    await loadFiles();
    await loadAboutInfo(token);
  };

  // Rename File
  const handleRename = async (fileId: string, newName: string) => {
    await DriveService.renameFile(token, fileId, newName);
    SoundEffects.playSuccess();
    setFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, name: newName } : f)));
    if (previewFile?.id === fileId) {
      setPreviewFile((prev) => (prev ? { ...prev, name: newName } : null));
    }
  };

  // Trigger AI Assistant for a specific file
  const handleOpenAIForFile = (file: DriveFile) => {
    setAiSelectedFile(file);
    setIsAIModalOpen(true);
  };

  // General AI trigger
  const handleOpenGeneralAI = () => {
    setAiSelectedFile(null);
    setIsAIModalOpen(true);
  };

  // Trigger OCR extraction for an image or PDF
  const handleOpenOCR = (file: DriveFile, customBase64?: string) => {
    SoundEffects.playPop();
    setOcrFile(file);
    setOcrCustomBase64(customBase64);
    setIsOCRModalOpen(true);
  };

  // General OCR scanner trigger from top bar
  const handleOpenGenericOCR = () => {
    SoundEffects.playPop();
    setOcrFile(null);
    setOcrCustomBase64(undefined);
    setIsOCRModalOpen(true);
  };

  // Trigger Veo Video Generation
  const handleOpenVeo = (file?: DriveFile | null, customBase64?: string) => {
    SoundEffects.playPop();
    setVeoFile(file || null);
    setVeoCustomBase64(customBase64);
    setIsVeoModalOpen(true);
  };

  // Trigger Folder Backup (ZIP Archive Compression & Download)
  const handleOpenFolderBackup = (folder?: DriveFile | null) => {
    SoundEffects.playPop();
    if (folder && folder.mimeType === 'application/vnd.google-apps.folder') {
      setBackupTargetFolder({
        id: folder.id,
        name: folder.name,
        files: []
      });
    } else {
      setBackupTargetFolder({
        id: currentFolderId,
        name: currentFolderName,
        files: displayedFiles
      });
    }
    setIsFolderBackupOpen(true);
  };

  // Save generated video directly to Google Drive
  const handleSaveVideoToDrive = async (fileName: string, videoBlob: Blob): Promise<DriveFile> => {
    const videoFile = new File([videoBlob], fileName, { type: 'video/mp4' });
    const uploaded = await DriveService.uploadFile(token, videoFile, currentFolderId);
    SoundEffects.playSuccess();
    await loadFiles();
    return uploaded;
  };

  // Reminder Handlers
  const handleOpenReminderModal = (file: DriveFile) => {
    setFileForReminder(file);
    setIsReminderModalOpen(true);
  };

  const handleSaveReminder = (reminderData: FileReminder) => {
    ReminderService.setReminder(reminderData);
    SoundEffects.playSuccess();
    setReminders(ReminderService.getReminders());
    setIsReminderModalOpen(false);
    setFileForReminder(null);
  };

  const handleDeleteReminder = (fileId: string) => {
    ReminderService.deleteReminder(fileId);
    setReminders(ReminderService.getReminders());
    setIsReminderModalOpen(false);
    setFileForReminder(null);
  };

  const handleToggleCompleteReminder = (reminderId: string) => {
    ReminderService.toggleComplete(reminderId);
    setReminders(ReminderService.getReminders());
  };

  const handleDismissNotification = (reminderId: string) => {
    setDismissedReminderIds((prev) => new Set([...prev, reminderId]));
  };

  const handleOpenFileFromReminder = (fileId: string) => {
    const found = files.find((f) => f.id === fileId);
    if (found) {
      setQuickLookFile(found);
    } else {
      const rem = reminders.find((r) => r.fileId === fileId);
      if (rem) {
        setQuickLookFile({
          id: rem.fileId,
          name: rem.fileName,
          mimeType: rem.fileMimeType || 'application/vnd.google-apps.document',
          modifiedTime: rem.createdAt || new Date().toISOString(),
          size: '0',
          starred: false,
        });
      }
    }
  };

  // Active AI Category metadata if filtered
  const activeAICategoryKey = currentCategory.startsWith('ai_') 
    ? (currentCategory.replace('ai_', '') as AICategoryKey) 
    : null;
  const activeAICategoryMeta = activeAICategoryKey ? AI_CATEGORIES[activeAICategoryKey] : null;

  // Get current view title
  const getCategoryTitle = () => {
    if (activeAICategoryMeta) {
      return `تصنيف AI: ${activeAICategoryMeta.label}`;
    }

    switch (currentCategory) {
      case 'folders': return 'المجلدات فقط';
      case 'docs': return 'مستندات Google Docs';
      case 'sheets': return 'جداول Google Sheets';
      case 'slides': return 'عروض Google Slides';
      case 'pdf': return 'ملفات PDF';
      case 'images': return 'الصور والوسائط';
      case 'starred': return 'الملفات والمجلدات المميزة بنجمة';
      case 'reminders': return 'المجدولة والتذكيرات';
      case 'trash': return 'سلة المهملات';
      default: return breadcrumbs.length > 0 ? breadcrumbs[breadcrumbs.length - 1].name : 'كل ملفاتي';
    }
  };

  const renderActiveAIIcon = (key: AICategoryKey) => {
    switch (key) {
      case 'invoices': return <Receipt className="w-5 h-5 text-emerald-600" />;
      case 'reports': return <BarChart3 className="w-5 h-5 text-blue-600" />;
      case 'projects': return <Rocket className="w-5 h-5 text-amber-600" />;
      case 'contracts': return <FileCheck2 className="w-5 h-5 text-purple-600" />;
      case 'education': return <GraduationCap className="w-5 h-5 text-cyan-600" />;
      case 'media': return <Palette className="w-5 h-5 text-rose-600" />;
      default: return <FolderGit2 className="w-5 h-5 text-slate-600" />;
    }
  };

  if (isShowingCommandCenter) {
    return (
      <CommandCenterPreview 
        onClosePreview={() => setIsShowingCommandCenter(false)} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-blue-600 selection:text-white" dir="rtl">
      
      {/* Switcher Banner to return to Command Center Hub */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-700 text-white px-4 py-2 text-xs font-bold flex items-center justify-between">
        <span className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>مستكشف الملفات نشط — يمكنك التبديل إلى نموذج واجهة الكوماند سنتر المقترحة في أي وقت:</span>
        </span>
        <button 
          onClick={() => setIsShowingCommandCenter(true)}
          className="px-3.5 py-1 bg-white text-blue-900 rounded-lg text-xs font-black shadow hover:bg-blue-50 transition-all flex items-center gap-1.5"
        >
          <span>مشاهدة واجهة الكوماند سنتر المقترحة</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
      
      {/* Top Navbar */}
      <Navbar
        searchFilters={searchFilters}
        onFiltersChange={setSearchFilters}
        onResetFilters={() => setSearchFilters(DEFAULT_SEARCH_FILTERS)}
        totalMatchingCount={displayedFiles.length}
        isConnected={Boolean(token)}
        aboutInfo={aboutInfo}
        onConnectGoogle={handleConnectGoogle}
        onDisconnect={handleDisconnect}
        onOpenAI={handleOpenGeneralAI}
        onOpenOCR={handleOpenGenericOCR}
        onOpenVeo={() => handleOpenVeo()}
        onRefresh={loadFiles}
        isLoading={isLoading}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        onOpenUpload={() => setIsUploadModalOpen(true)}
        onOpenNewFolder={() => setIsNewFolderModalOpen(true)}
        onOpenNewDoc={() => setIsNewDocModalOpen(true)}
        onOpenOAuthModal={() => setIsOAuthModalOpen(true)}
        reminders={reminders}
        onOpenFileReminder={handleOpenFileFromReminder}
        onToggleCompleteReminder={handleToggleCompleteReminder}
        onDeleteReminder={handleDeleteReminder}
        onNavigateToRemindersView={() => {
          setCurrentCategory('reminders');
          setBreadcrumbs([]);
          setSearchFilters(DEFAULT_SEARCH_FILTERS);
        }}
        isMobileSidebarOpen={isMobileSidebarOpen}
        onToggleMobileSidebar={() => {
          SoundEffects.playPop();
          setIsMobileSidebarOpen((prev) => !prev);
        }}
        isDesktopSidebarCollapsed={isDesktopSidebarCollapsed}
        onToggleDesktopSidebar={() => {
          SoundEffects.playPop();
          setIsDesktopSidebarCollapsed((prev) => !prev);
        }}
        onOpenThemeSettings={() => {
          SoundEffects.playPop();
          setIsThemeModalOpen(true);
        }}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex flex-col lg:flex-row max-w-7xl w-full mx-auto">
        
        {/* Navigation Sidebar */}
        <Sidebar
          currentCategory={currentCategory}
          onSelectCategory={(cat) => {
            setCurrentCategory(cat);
            setBreadcrumbs([]);
            setSearchFilters(DEFAULT_SEARCH_FILTERS);
          }}
          aboutInfo={aboutInfo}
          onOpenUpload={() => setIsUploadModalOpen(true)}
          onOpenNewFolder={() => setIsNewFolderModalOpen(true)}
          onOpenNewDoc={() => setIsNewDocModalOpen(true)}
          onOpenAI={handleOpenGeneralAI}
          totalFilesCount={files.length}
          aiClassifications={aiClassifications}
          isCategorizing={isCategorizing}
          onTriggerAICategorize={() => runAICategorization(files, true)}
          remindersCount={reminders.filter(r => !r.completed).length}
          isMobileOpen={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
          isDesktopCollapsed={isDesktopSidebarCollapsed}
          onToggleDesktopCollapse={() => {
            SoundEffects.playPop();
            setIsDesktopSidebarCollapsed((prev) => !prev);
          }}
          onOpenThemeSettings={() => {
            SoundEffects.playPop();
            setIsThemeModalOpen(true);
          }}
        />

        {/* Content Area with Drag & Drop */}
        <main
          id="main-drive-content"
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleFilesDrop}
          className="relative flex-1 flex flex-col p-4 lg:p-6 overflow-y-auto"
        >
          {/* Drag & Drop Visual Overlay */}
          <DragDropOverlay
            isDragging={isPageDragging}
            isUploading={isDropUploading}
            currentFolderName={currentFolderName}
          />
          
          {/* Informative Banner if not connected to Google yet */}
          {!token && (
            <div className="mb-5 p-4 rounded-2xl bg-gradient-to-r from-blue-50 via-indigo-50/50 to-white border border-blue-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-blue-500/20">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    تم إعداد وتفعيل صلاحيات Google Drive بنجاح
                  </h4>
                  <p className="text-xs text-slate-600">
                    أنت تتصفح حالياً وضع المعاينة التفاعلي. يمكنك ربط حساب Google Drive الحقيقي الخاص بك في أي لحظة.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleConnectGoogle}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-500/20 transition-all cursor-pointer"
                >
                  تسجيل الدخول الفوري بحساب Google
                </button>
                <button
                  onClick={() => setIsOAuthModalOpen(true)}
                  className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200 transition-colors"
                >
                  تفاصيل الصلاحيات
                </button>
              </div>
            </div>
          )}

          {/* Reminders Special Category Header Banner */}
          {currentCategory === 'reminders' && (
            <div className="mb-5 p-5 rounded-3xl bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-white border border-amber-200 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-lg shadow-amber-500/20 shrink-0">
                    <Bell className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-black text-slate-900">
                        قائمة الملفات المجدولة والتذكيرات
                      </h3>
                      <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800">
                        {reminders.length} تذكير مسجل
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1">
                      إدارة التنبيهات المجدولة ومتابعة مواعيد المستندات الهامة مع إشعارات مرئية داخل التطبيق.
                    </p>
                  </div>
                </div>

                {/* Quick Reminder Stats Chips */}
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="px-3 py-1.5 rounded-xl bg-white border border-rose-200 text-xs shadow-2xs">
                    <span className="text-slate-400 block text-[10px] font-bold">المستحقة الآن</span>
                    <span className="font-extrabold text-rose-600">
                      {reminders.filter(r => !r.completed && ReminderService.isDue(r)).length}
                    </span>
                  </div>

                  <div className="px-3 py-1.5 rounded-xl bg-white border border-amber-200 text-xs shadow-2xs">
                    <span className="text-slate-400 block text-[10px] font-bold">القادمة</span>
                    <span className="font-extrabold text-amber-700">
                      {reminders.filter(r => !r.completed && !ReminderService.isDue(r)).length}
                    </span>
                  </div>

                  <div className="px-3 py-1.5 rounded-xl bg-white border border-emerald-200 text-xs shadow-2xs">
                    <span className="text-slate-400 block text-[10px] font-bold">المنجزة</span>
                    <span className="font-extrabold text-emerald-700">
                      {reminders.filter(r => r.completed).length}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Active AI Category Filter Banner */}
          {activeAICategoryMeta && (
            <div className={`mb-4 p-4 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${activeAICategoryMeta.badgeBg} ${activeAICategoryMeta.badgeBorder}`}>
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-white shadow-xs">
                  {renderActiveAIIcon(activeAICategoryMeta.key)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className={`text-sm font-extrabold ${activeAICategoryMeta.badgeText}`}>
                      {activeAICategoryMeta.label}
                    </h3>
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-white text-slate-700 shadow-2xs">
                      {displayedFiles.length} ملف مصنف بالذكاء الاصطناعي
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {activeAICategoryMeta.description} (تم التعرف عليها آلياً بواسطة Gemini)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => runAICategorization(files, true)}
                  disabled={isCategorizing}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 shadow-2xs transition-colors cursor-pointer disabled:opacity-60"
                  title="إعادة فحص وتصنيف المحتوى بواسطة الذكاء الاصطناعي"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-indigo-600 ${isCategorizing ? 'animate-spin' : ''}`} />
                  <span>{isCategorizing ? 'جاري التصنيف...' : 'إعادة تصنيف AI'}</span>
                </button>

                <button
                  onClick={() => setCurrentCategory('all')}
                  className="flex items-center gap-1 px-3 py-1.5 bg-white/80 hover:bg-white text-slate-600 hover:text-slate-900 text-xs font-semibold rounded-xl border border-slate-200 shadow-2xs transition-colors cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>إلغاء الفلتر</span>
                </button>
              </div>
            </div>
          )}

          {/* Breadcrumbs & View Heading */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-200/80">
            <div>
              <Breadcrumbs
                breadcrumbs={breadcrumbs}
                onNavigate={handleNavigateBreadcrumb}
                currentTitle={getCategoryTitle()}
              />
              <div className="flex items-center gap-2 mt-1 px-1">
                <h2 className="text-lg font-extrabold text-slate-900 tracking-tight">
                  {getCategoryTitle()}
                </h2>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-200/70 text-slate-700 font-bold">
                  {displayedFiles.length} عنصر
                </span>
                {searchFilters.query && (
                  <span className="text-xs text-blue-600 font-semibold">
                    (نتائج البحث عن: "{searchFilters.query}")
                  </span>
                )}
                {selectedFileIds.size > 0 && (
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold animate-pulse">
                    تم تحديد {selectedFileIds.size}
                  </span>
                )}
              </div>
            </div>

            {/* Quick Action Pills & Sorting */}
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <SortControls
                sortOption={sortOption}
                onSortChange={setSortOption}
                onOpenShortcuts={() => setIsShortcutsModalOpen(true)}
              />

              <button
                onClick={() => {
                  SoundEffects.playPop();
                  setIsFolderAnalysisOpen(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-violet-600 via-indigo-600 to-indigo-700 hover:from-violet-700 hover:to-indigo-800 text-white text-xs font-bold rounded-xl shadow-xs hover:shadow-indigo-500/25 transition-all cursor-pointer"
                title="تحليل شامل لمحتوى المجلد المفتوح حالياً بواسطة الذكاء الاصطناعي (F)"
              >
                <BrainCircuit className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                <span>تحليل المجلد (AI)</span>
              </button>

              <button
                onClick={() => handleOpenFolderBackup()}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 hover:from-emerald-700 hover:to-cyan-800 text-white text-xs font-bold rounded-xl shadow-xs hover:shadow-emerald-500/25 transition-all cursor-pointer"
                title="ضغط كامل محتويات هذا المجلد وتنزيلها كملف ZIP إلى جهازك"
              >
                <Archive className="w-3.5 h-3.5 text-emerald-200" />
                <span>نسخ احتياطي (ZIP)</span>
              </button>

              <div className="h-4 w-px bg-slate-200 hidden sm:block mx-0.5" />

              <button
                onClick={() => setIsUploadModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold rounded-xl border border-blue-200/60 transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>رفع</span>
              </button>
              <button
                onClick={() => setIsNewFolderModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 text-xs font-bold rounded-xl border border-amber-200/60 transition-colors cursor-pointer"
              >
                <FolderPlus className="w-3.5 h-3.5" />
                <span>مجلد</span>
              </button>
              <button
                onClick={() => setIsNewDocModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold rounded-xl border border-indigo-200/60 transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>مستند ذكي</span>
              </button>
            </div>
          </div>

          {/* Files Grid or Table Display */}
          {isLoading && files.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-16 text-center">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center animate-spin mb-3">
                <HardDrive className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">جاري تحميل ملفات ومستندات Google Drive...</h3>
            </div>
          ) : error ? (
            <div className="p-6 rounded-3xl bg-red-50 border border-red-200 text-red-700 text-center">
              <AlertCircle className="w-8 h-8 mx-auto mb-2 text-red-500" />
              <p className="text-sm font-bold mb-1">{error}</p>
              <button
                onClick={loadFiles}
                className="mt-3 px-4 py-2 bg-red-600 text-white font-bold text-xs rounded-xl shadow-xs hover:bg-red-700 transition-colors"
              >
                إعادة المحاولة
              </button>
            </div>
          ) : displayedFiles.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-16 text-center bg-white/60 rounded-3xl border border-dashed border-slate-200">
              <div className="w-16 h-16 rounded-3xl bg-slate-100 text-slate-400 flex items-center justify-center mb-4">
                <FolderOpen className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800 mb-1">
                {(searchFilters.query || searchFilters.type !== 'all' || searchFilters.dateModified !== 'all' || searchFilters.onlyStarred || searchFilters.onlyReminders || searchFilters.aiCategory !== 'all')
                  ? 'لم يتم العثور على ملفات مطابقة لخيارات البحث والتصفية' 
                  : activeAICategoryMeta 
                    ? `لا توجد ملفات مصنفة كـ "${activeAICategoryMeta.label}" حالياً` 
                    : 'هذا المجلد فارغ حالياً'}
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mb-4">
                {activeAICategoryMeta
                  ? 'يقوم الذكاء الاصطناعي بتحليل محتوى الملفات وعناوينها لتصنيفها تلقائياً.'
                  : (searchFilters.query || searchFilters.type !== 'all' || searchFilters.dateModified !== 'all')
                    ? 'جرب إعادة تعيين الفلاتر المتقدمة أو البحث بكلمة مفتاحية مختلفة.'
                    : 'يمكنك سحب وإفلات الملفات مباشرة هنا لرفعها، أو استخدام أزرار الرفع والإنشاء.'}
              </p>
              <div className="flex items-center gap-2">
                {(searchFilters.query || searchFilters.type !== 'all' || searchFilters.dateModified !== 'all' || searchFilters.onlyStarred || searchFilters.onlyReminders || searchFilters.aiCategory !== 'all') ? (
                  <button
                    onClick={() => setSearchFilters(DEFAULT_SEARCH_FILTERS)}
                    className="px-4 py-2 bg-slate-800 text-white font-bold text-xs rounded-xl shadow-sm hover:bg-slate-900 transition-colors"
                  >
                    إعادة تعيين فلاتر البحث
                  </button>
                ) : activeAICategoryMeta ? (
                  <button
                    onClick={() => setCurrentCategory('all')}
                    className="px-4 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-sm hover:bg-blue-700 transition-colors"
                  >
                    عرض جميع الملفات
                  </button>
                ) : (
                  <>
                    <button
                      onClick={() => setIsUploadModalOpen(true)}
                      className="px-4 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-sm hover:bg-blue-700 transition-colors"
                    >
                      رفع أول ملف الآن
                    </button>
                    <button
                      onClick={() => setIsNewDocModalOpen(true)}
                      className="px-4 py-2 bg-indigo-50 text-indigo-700 font-bold text-xs rounded-xl border border-indigo-200 hover:bg-indigo-100 transition-colors"
                    >
                      إنشاء مستند ذكي بالـ AI
                    </button>
                  </>
                )}
              </div>
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {displayedFiles.map((file) => (
                <FileCard
                  key={file.id}
                  file={file}
                  onOpen={handleOpenFile}
                  onStarToggle={handleStarToggle}
                  onDelete={handleDeleteFile}
                  onRestore={handleRestoreFile}
                  onRename={(f) => setFileToRename(f)}
                  onAIAnalyze={handleOpenAIForFile}
                  onShare={(f) => setShareModalFile(f)}
                  onOCR={handleOpenOCR}
                  onVeoAnimate={handleOpenVeo}
                  onBackupFolder={handleOpenFolderBackup}
                  onSendToAutomation={handleOpenAutomation}
                  isTrashView={currentCategory === 'trash'}
                  aiClassification={aiClassifications[file.id] || AICategorizeService.getCachedOrHeuristicCategory(file)}
                  onSelectAICategory={(catKey) => setCurrentCategory(`ai_${catKey}`)}
                  reminder={remindersMap.get(file.id)}
                  onSetReminder={handleOpenReminderModal}
                  isSelected={selectedFileIds.has(file.id)}
                  onToggleSelect={handleToggleSelectFile}
                  selectionActive={selectedFileIds.size > 0}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-right border-collapse">
                  <thead>
                    <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 text-xs font-bold">
                      <th className="py-3 px-4">اسم الملف / المجلد والتصنيف</th>
                      <th className="py-3 px-4 hidden sm:table-cell">النوع</th>
                      <th className="py-3 px-4 hidden md:table-cell">المالك</th>
                      <th className="py-3 px-4">تاريخ التعديل</th>
                      <th className="py-3 px-4">الحجم</th>
                      <th className="py-3 px-4 text-left">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {displayedFiles.map((file) => (
                      <FileTableRow
                        key={file.id}
                        file={file}
                        onOpen={handleOpenFile}
                        onQuickLook={(f) => setQuickLookFile(f)}
                        onStarToggle={handleStarToggle}
                        onDelete={handleDeleteFile}
                        onRestore={handleRestoreFile}
                        onRename={(f) => setFileToRename(f)}
                        onAIAnalyze={handleOpenAIForFile}
                        onShare={(f) => setShareModalFile(f)}
                        onOCR={handleOpenOCR}
                        onVeoAnimate={handleOpenVeo}
                        onBackupFolder={handleOpenFolderBackup}
                        onSendToAutomation={handleOpenAutomation}
                        isTrashView={currentCategory === 'trash'}
                        aiClassification={aiClassifications[file.id] || AICategorizeService.getCachedOrHeuristicCategory(file)}
                        onSelectAICategory={(catKey) => setCurrentCategory(`ai_${catKey}`)}
                        reminder={remindersMap.get(file.id)}
                        onSetReminder={handleOpenReminderModal}
                        isSelected={selectedFileIds.has(file.id)}
                        onToggleSelect={handleToggleSelectFile}
                        selectionActive={selectedFileIds.size > 0}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* MODALS & DRAWERS */}
      
      {/* Quick Look Side Drawer */}
      <QuickLookDrawer
        file={quickLookFile}
        onClose={() => setQuickLookFile(null)}
        token={token}
        onAIAnalyze={handleOpenAIForFile}
        onStarToggle={handleStarToggle}
        onShare={(f) => setShareModalFile(f)}
        onOCR={handleOpenOCR}
        onVeoAnimate={handleOpenVeo}
        onBackupFolder={handleOpenFolderBackup}
        onSendToAutomation={handleOpenAutomation}
        aiClassification={quickLookFile ? (aiClassifications[quickLookFile.id] || AICategorizeService.getCachedOrHeuristicCategory(quickLookFile)) : undefined}
        reminder={quickLookFile ? remindersMap.get(quickLookFile.id) : undefined}
        onSetReminder={handleOpenReminderModal}
      />

      {/* File Details & Preview Modal */}
      <FilePreviewModal
        file={previewFile}
        onClose={() => setPreviewFile(null)}
        onAIAnalyze={handleOpenAIForFile}
        onStarToggle={handleStarToggle}
        onShare={(f) => setShareModalFile(f)}
        onOCR={handleOpenOCR}
        onVeoAnimate={handleOpenVeo}
        onSendToAutomation={handleOpenAutomation}
      />

      {/* File Sharing & Permissions Modal */}
      <ShareModal
        file={shareModalFile}
        isOpen={Boolean(shareModalFile)}
        onClose={() => setShareModalFile(null)}
        token={token}
        onShareSuccess={(fileId) => {
          // Optimistically update file shared state
          setFiles((prev) => prev.map((f) => f.id === fileId ? { ...f, shared: true } : f));
        }}
      />

      {/* Gemini AI Intelligence Suite Modal */}
      <AIInsightModal
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
        selectedFile={aiSelectedFile}
        allFiles={files}
        token={token}
        onSaveNewDocToDrive={async (title, content) => {
          await handleCreateDoc(title, content);
        }}
      />

      {/* Upload File Modal */}
      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onUpload={handleUpload}
        currentFolderName={currentFolderName}
      />

      {/* Create Folder Modal */}
      <NewFolderModal
        isOpen={isNewFolderModalOpen}
        onClose={() => setIsNewFolderModalOpen(false)}
        onCreateFolder={handleCreateFolder}
        currentFolderName={currentFolderName}
      />

      {/* Create Document Modal */}
      <NewDocModal
        isOpen={isNewDocModalOpen}
        onClose={() => setIsNewDocModalOpen(false)}
        onCreateDoc={handleCreateDoc}
        onOpenAIAssistant={() => {
          setIsAIModalOpen(true);
        }}
        currentFolderName={currentFolderName}
      />

      {/* Rename File Modal */}
      <RenameModal
        file={fileToRename}
        onClose={() => setFileToRename(null)}
        onRename={handleRename}
      />

      {/* File Reminder Modal */}
      <ReminderModal
        isOpen={isReminderModalOpen}
        onClose={() => {
          setIsReminderModalOpen(false);
          setFileForReminder(null);
        }}
        file={fileForReminder}
        existingReminder={fileForReminder ? remindersMap.get(fileForReminder.id) : undefined}
        onSave={handleSaveReminder}
        onDelete={handleDeleteReminder}
      />

      {/* In-App Reminder Visual Notification Banner */}
      <ReminderNotificationBanner
        dueReminders={dueReminders}
        onOpenFile={handleOpenFileFromReminder}
        onMarkComplete={handleToggleCompleteReminder}
        onDismiss={handleDismissNotification}
        onOpenReminderList={() => {
          setCurrentCategory('reminders');
          setBreadcrumbs([]);
          setSearchFilters(DEFAULT_SEARCH_FILTERS);
        }}
      />

      {/* OAuth Information & Token Modal */}
      <OAuthModal
        isOpen={isOAuthModalOpen}
        onClose={() => setIsOAuthModalOpen(false)}
        isConnected={Boolean(token)}
        onConnectGoogle={handleConnectGoogle}
        onSetCustomToken={(t) => {
          setToken(t);
          loadAboutInfo(t);
          loadFiles();
        }}
      />

      {/* Floating Multi-Selection Batch Actions Bar */}
      <BatchActionBar
        selectedFiles={selectedFiles}
        totalFilesCount={displayedFiles.length}
        onSelectAll={handleSelectAll}
        onClearSelection={handleClearSelection}
        onBatchStar={(star) => handleBatchStar(star)}
        onBatchDelete={handleBatchDelete}
        onBatchAIAnalyze={handleBatchAIAnalyze}
        onBatchOpenLinks={handleBatchOpenLinks}
        onBatchRename={() => setIsBulkRenameModalOpen(true)}
        onBatchSendToAutomation={() => {
          if (selectedFiles.length > 0) {
            handleOpenAutomation(selectedFiles[0]);
          }
        }}
        isTrashView={currentCategory === 'trash'}
      />

      {/* Bulk Rename Modal */}
      <BulkRenameModal
        isOpen={isBulkRenameModalOpen}
        onClose={() => setIsBulkRenameModalOpen(false)}
        selectedFiles={selectedFiles}
        onApplyRename={handleBulkRename}
      />

      {/* Keyboard Shortcuts Cheat Sheet Modal */}
      <KeyboardShortcutsModal
        isOpen={isShortcutsModalOpen}
        onClose={() => setIsShortcutsModalOpen(false)}
      />

      {/* AI Folder Content Analysis Side Drawer */}
      <FolderAnalysisDrawer
        isOpen={isFolderAnalysisOpen}
        onClose={() => setIsFolderAnalysisOpen(false)}
        folderName={currentFolderName}
        folderId={currentFolderId}
        files={displayedFiles}
        breadcrumbs={breadcrumbs}
        token={token}
        onSaveDocToFolder={handleCreateDoc}
        onBackupFolder={handleOpenFolderBackup}
      />

      {/* Folder ZIP Backup Modal */}
      <FolderBackupModal
        isOpen={isFolderBackupOpen}
        onClose={() => {
          setIsFolderBackupOpen(false);
          setBackupTargetFolder(null);
        }}
        folderId={backupTargetFolder?.id || currentFolderId}
        folderName={backupTargetFolder?.name || currentFolderName}
        initialFiles={backupTargetFolder?.files}
        token={token}
      />

      {/* Optical Character Recognition (OCR) Modal */}
      <OCRModal
        isOpen={isOCRModalOpen}
        onClose={() => {
          setIsOCRModalOpen(false);
          setOcrFile(null);
          setOcrCustomBase64(undefined);
        }}
        file={ocrFile}
        token={token}
        customBase64={ocrCustomBase64}
        onSaveDocToDrive={async (title, content) => {
          await handleCreateDoc(title, content);
        }}
        onOpenAIChatWithContext={(contextText) => {
          setIsOCRModalOpen(false);
          setAiSelectedFile(ocrFile);
          setIsAIModalOpen(true);
        }}
      />

      {/* Veo Video Generation (Image-to-Video AI) Modal */}
      <VeoVideoModal
        isOpen={isVeoModalOpen}
        onClose={() => {
          setIsVeoModalOpen(false);
          setVeoFile(null);
          setVeoCustomBase64(undefined);
        }}
        file={veoFile}
        token={token}
        customBase64={veoCustomBase64}
        onSaveVideoToDrive={handleSaveVideoToDrive}
      />

      {/* Custom Theme & Accent Colors Settings Modal */}
      <ThemeSettingsModal
        isOpen={isThemeModalOpen}
        onClose={() => setIsThemeModalOpen(false)}
        currentPreferences={themePreferences}
        onUpdatePreferences={(newPrefs) => {
          setThemePreferences(newPrefs);
          ThemeService.applyTheme(newPrefs);
        }}
      />

      {/* Unified Settings Center (Webhooks, n8n, Notifications, Meta) */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        defaultTab="webhooks"
        currentPreferences={themePreferences}
        onUpdatePreferences={(newPrefs) => {
          setThemePreferences(newPrefs);
          ThemeService.applyTheme(newPrefs);
        }}
      />

      {/* Send File to n8n Automation Engine (.env.example Webhooks) */}
      <SendToAutomationModal
        file={automationFile}
        isOpen={isAutomationModalOpen}
        onClose={() => {
          setIsAutomationModalOpen(false);
          setAutomationFile(null);
        }}
        onSuccess={() => {
          SoundEffects.playSuccess();
        }}
      />

    </div>
  );
}
