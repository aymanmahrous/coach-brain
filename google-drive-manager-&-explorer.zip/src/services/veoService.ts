import { DriveFile } from '../types';

export interface VeoGenerationParams {
  imageData?: string; // base64 or data URL
  fileId?: string;
  token?: string | null;
  prompt?: string;
  aspectRatio: '16:9' | '9:16';
  resolution?: '720p' | '1080p';
  mimeType?: string;
  onProgress?: (message: string, percent: number) => void;
}

export interface VeoGenerationResult {
  videoBlob: Blob;
  videoUrl: string;
  operationName: string;
  aspectRatio: '16:9' | '9:16';
  prompt: string;
  durationSeconds: number;
}

export interface VeoMotionPreset {
  id: string;
  title: string;
  description: string;
  prompt: string;
  icon: string;
}

export const VEO_MOTION_PRESETS: VeoMotionPreset[] = [
  {
    id: 'cinematic',
    title: 'حركة سينمائية ثلاثية الأبعاد',
    description: 'حركة كاميرا سلسة وواقعية مع عمق مكاني احترافي وإضاءة سينمائية',
    prompt: 'Animate this photo with smooth cinematic 3D camera motion, realistic depth of field, gentle parallax effect, and high-fidelity lighting.',
    icon: 'Clapperboard'
  },
  {
    id: 'zoom_in',
    title: 'تكبير بطيء نحو مركز الصورة (Push-in)',
    description: 'تقريب تدريجي بطيء يركز على التفاصيل الأساسية مع حركة تفاعلية',
    prompt: 'Slow, dramatic push-in zoom into the focal subject with subtle ambient motion, smooth atmospheric depth, and cinematic pacing.',
    icon: 'ZoomIn'
  },
  {
    id: 'natural_breeze',
    title: 'حركة نسيم وعناصر طبيعية',
    description: 'تحريك الأشجار، المياه، الأقمشة والشعر بنسيم حيوي واقعي',
    prompt: 'Add natural organic motion to the scene: gentle wind moving hair, fabric, and foliage, flowing light reflections, and realistic environmental ambiance.',
    icon: 'Wind'
  },
  {
    id: 'panoramic_pan',
    title: 'بانوراما أفقية سلسة (Camera Pan)',
    description: 'تحريك زاوية الرؤية أفقياً لاستعراض كامل المشهد بجمالية',
    prompt: 'Smooth horizontal panoramic camera pan across the scene, revealing environment details with rich perspective shift and seamless frame coherence.',
    icon: 'MoveHorizontal'
  },
  {
    id: 'dramatic_light',
    title: 'إضاءة ديناميكية وتوهج سينمائي',
    description: 'تحريك الظلال وأشعة الشمس والبريق الضوئي بطريقة مبهرة',
    prompt: 'Dynamic moving light rays, golden hour sunbeams passing through the frame, shifting soft shadows, and subtle volumetric atmosphere.',
    icon: 'SunMedium'
  },
  {
    id: 'vibrant_action',
    title: 'حركة ديناميكية سريعة وحيوية',
    description: 'طاقة عالية وحركة نشطة للعناصر في المشهد',
    prompt: 'Vibrant dynamic motion, active movement of key scene elements, high kinetic energy, and fluid visual animation.',
    icon: 'Sparkles'
  }
];

export const VEO_PROGRESS_STEPS = [
  { at: 5, message: 'جاري تهيئة نموذج Veo وتحليل أبعاد وهندسة الصورة...' },
  { at: 18, message: 'استخراج العمق الثلاثي وتوزيع الإضاءة في المشهد...' },
  { at: 35, message: 'توليد مسارات الحركة والإطارات المتتابعة (Frame Coherence)...' },
  { at: 55, message: 'معالجة وتنعيم الحركة السينمائية الفائقة (Frame Interpolation)...' },
  { at: 75, message: 'تطبيق الإضاءة والظلال الواقعية وتحسين الدقة إلى HD...' },
  { at: 90, message: 'وضع اللمسات الأخيرة وترميز ملف الفيديو MP4 النهائي...' },
];

export class VeoService {
  /**
   * Check if a file is an image eligible for Veo animation
   */
  static isVeoSupported(file: DriveFile | null): boolean {
    if (!file) return false;
    if (file.mimeType.startsWith('image/')) return true;
    const name = (file.name || '').toLowerCase();
    return (
      name.endsWith('.png') ||
      name.endsWith('.jpg') ||
      name.endsWith('.jpeg') ||
      name.endsWith('.webp') ||
      name.endsWith('.gif')
    );
  }

  /**
   * Convert image file or URL to base64
   */
  static async fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });
  }

  /**
   * Generate video using Veo 3.1
   */
  static async generateVideo(params: VeoGenerationParams): Promise<VeoGenerationResult> {
    const {
      imageData,
      fileId,
      token,
      prompt = 'Animate this photo with smooth cinematic camera motion and natural depth',
      aspectRatio = '16:9',
      resolution = '720p',
      mimeType = 'image/png',
      onProgress
    } = params;

    if (onProgress) onProgress('جاري إرسال الصورة وبدء عملية التوليد في خوادم Veo...', 5);

    // 1. Initiate Generation Operation
    const initRes = await fetch('/api/video/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        imageData,
        fileId,
        token: token || undefined,
        prompt,
        aspectRatio,
        resolution,
        mimeType
      })
    });

    if (!initRes.ok) {
      const err = await initRes.json().catch(() => ({}));
      throw new Error(err.error || 'فشل في بدء عملية تحريك الصورة بواسطة Veo.');
    }

    const { operationName } = await initRes.json();
    if (!operationName) {
      throw new Error('لم يتم استلام معرّف العملية من الخادم.');
    }

    if (onProgress) onProgress('تم إطلاق عملية التوليد بنجاح! جاري معالجة الإطارات...', 15);

    // 2. Poll Operation Status until done
    const startTime = Date.now();
    let currentPercent = 15;
    let pollAttempts = 0;
    let isDone = false;

    while (!isDone) {
      // Wait 3.5 seconds between polling checks
      await new Promise((r) => setTimeout(r, 3500));
      pollAttempts++;

      // Estimate progress percent dynamically
      const elapsedSeconds = (Date.now() - startTime) / 1000;
      if (currentPercent < 92) {
        currentPercent = Math.min(92, Math.round(15 + elapsedSeconds * 1.8));
      }

      // Pick the corresponding step message
      const activeStep = [...VEO_PROGRESS_STEPS].reverse().find((s) => currentPercent >= s.at);
      if (onProgress && activeStep) {
        onProgress(activeStep.message, currentPercent);
      }

      const statusRes = await fetch('/api/video/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ operationName })
      });

      if (!statusRes.ok) {
        console.warn('Veo status check temporary error, retrying...');
        continue;
      }

      const statusData = await statusRes.json();

      if (statusData.error) {
        throw new Error(
          typeof statusData.error === 'string'
            ? statusData.error
            : statusData.error.message || 'حدث خطأ أثناء معالجة الفيديو في Veo.'
        );
      }

      if (statusData.done) {
        isDone = true;
        if (onProgress) onProgress('تم اكتمال توليد الفيديو بنجاح! جاري تنزيل الملف...', 96);
      }

      // Safeguard against infinite polling (limit to 10 minutes)
      if (pollAttempts > 180) {
        throw new Error('استغرقت عملية توليد الفيديو وقتاً أطول من المتوقع. يرجى إعادة المحاولة.');
      }
    }

    // 3. Download the finished MP4 video file
    if (onProgress) onProgress('جاري تحميل الفيديو إلى جهازك وتجهيز العرض...', 98);

    const downloadRes = await fetch('/api/video/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ operationName })
    });

    if (!downloadRes.ok) {
      const err = await downloadRes.json().catch(() => ({}));
      throw new Error(err.error || 'فشل في استرجاع ملف الفيديو المولد من الخادم.');
    }

    const videoBlob = await downloadRes.blob();
    const videoUrl = URL.createObjectURL(videoBlob);

    if (onProgress) onProgress('اكتمل توليد الفيديو بنجاح!', 100);

    return {
      videoBlob,
      videoUrl,
      operationName,
      aspectRatio,
      prompt,
      durationSeconds: 5
    };
  }
}
