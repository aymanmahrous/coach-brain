import { DriveFile, OCRResult } from '../types';

export class OCRService {
  /**
   * Check if a given file or mimeType is eligible for OCR (Images & PDFs)
   */
  static isOCRSupported(fileOrMimeType: DriveFile | File | string): boolean {
    let mimeType = '';
    let name = '';

    if (typeof fileOrMimeType === 'string') {
      mimeType = fileOrMimeType.toLowerCase();
      name = fileOrMimeType.toLowerCase();
    } else if ('type' in fileOrMimeType) {
      mimeType = (fileOrMimeType as File).type.toLowerCase();
      name = (fileOrMimeType as File).name.toLowerCase();
    } else if ('mimeType' in fileOrMimeType) {
      mimeType = (fileOrMimeType as DriveFile).mimeType.toLowerCase();
      name = (fileOrMimeType as DriveFile).name.toLowerCase();
    }

    if (mimeType.startsWith('image/')) return true;
    if (mimeType.includes('pdf')) return true;

    // Check extension
    const imageExtensions = ['.png', '.jpg', '.jpeg', '.webp', '.bmp', '.gif', '.tiff', '.tif', '.svg'];
    if (imageExtensions.some((ext) => name.endsWith(ext))) return true;
    if (name.endsWith('.pdf')) return true;

    return false;
  }

  /**
   * Convert client File to Base64 string
   */
  static async fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          resolve(reader.result);
        } else {
          reject(new Error('فشل في قراءة بيانات الملف.'));
        }
      };
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  }

  /**
   * Execute OCR extraction using the server Gemini API endpoint
   */
  static async performOCR(params: {
    file?: DriveFile | null;
    fileData?: string;
    fileId?: string;
    mimeType?: string;
    fileName?: string;
    token?: string | null;
  }): Promise<OCRResult> {
    const { file, fileData, fileId, mimeType, fileName, token } = params;

    const payload = {
      fileData: fileData || undefined,
      fileId: fileId || file?.id || undefined,
      mimeType: mimeType || file?.mimeType || 'image/png',
      fileName: fileName || file?.name || 'document.png',
      token: token || undefined,
      language: 'ar',
    };

    const res = await fetch('/api/ai/ocr', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `خطأ في معالجة OCR (${res.status})`);
    }

    const data: OCRResult = await res.json();
    return data;
  }

  /**
   * Trigger local browser download of text/markdown file
   */
  static downloadTextFile(content: string, filename: string): void {
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename.endsWith('.md') || filename.endsWith('.txt') ? filename : `${filename}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
