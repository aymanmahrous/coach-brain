import JSZip from 'jszip';
import { DriveFile } from '../types';

export interface BackupProgress {
  phase: 'scanning' | 'downloading' | 'compressing' | 'completed' | 'error';
  totalFiles: number;
  processedFiles: number;
  currentFileName: string;
  percent: number;
  downloadedBytes: number;
  message: string;
}

export interface BackupOptions {
  includeSubfolders: boolean;
  exportGoogleDocsFormat: 'office' | 'pdf'; // 'office' (.docx/.xlsx/.pptx) or 'pdf'
  includeManifest: boolean;
}

export interface BackupResult {
  zipBlob: Blob;
  fileName: string;
  totalFilesCount: number;
  totalFoldersCount: number;
  uncompressedBytes: number;
  compressedBytes: number;
  durationMs: number;
}

export class FolderBackupService {
  /**
   * Determine suitable extension and export URL for Google Workspace files
   */
  private static getGoogleDocExportConfig(file: DriveFile, format: 'office' | 'pdf'): { exportUrl: string; extension: string } | null {
    const isPdf = format === 'pdf';
    
    switch (file.mimeType) {
      case 'application/vnd.google-apps.document':
        return {
          exportUrl: isPdf 
            ? `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=application/pdf`
            : `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=application/vnd.openxmlformats-officedocument.wordprocessingml.document`,
          extension: isPdf ? '.pdf' : '.docx'
        };
      case 'application/vnd.google-apps.spreadsheet':
        return {
          exportUrl: isPdf
            ? `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=application/pdf`
            : `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`,
          extension: isPdf ? '.pdf' : '.xlsx'
        };
      case 'application/vnd.google-apps.presentation':
        return {
          exportUrl: isPdf
            ? `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=application/pdf`
            : `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=application/vnd.openxmlformats-officedocument.presentationml.presentation`,
          extension: isPdf ? '.pdf' : '.pptx'
        };
      case 'application/vnd.google-apps.drawing':
        return {
          exportUrl: `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=image/png`,
          extension: '.png'
        };
      default:
        return null;
    }
  }

  /**
   * Normalize filename ensuring proper extension
   */
  private static ensureFilename(name: string, extension: string): string {
    if (name.toLowerCase().endsWith(extension.toLowerCase())) {
      return name;
    }
    // Remove .gdoc, .gsheet, .gslides if present
    const cleaned = name.replace(/\.(gdoc|gsheet|gslides|gdraw)$/i, '');
    return `${cleaned}${extension}`;
  }

  /**
   * Recursively fetch folder contents from Google Drive API
   */
  private static async fetchFolderChildren(
    token: string,
    folderId: string,
    onStatus?: (msg: string) => void
  ): Promise<DriveFile[]> {
    if (onStatus) onStatus(`جاري فحص محتويات المجلد (${folderId})...`);
    
    let allFiles: DriveFile[] = [];
    let pageToken: string | undefined = undefined;

    do {
      const url: string = `https://www.googleapis.com/drive/v3/files?q='${folderId}'+in+parents+and+trashed=false&fields=nextPageToken,files(id,name,mimeType,size,modifiedTime,description,thumbnailLink,parents)&pageSize=1000${pageToken ? `&pageToken=${pageToken}` : ''}`;
      
      const res: Response = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!res.ok) {
        console.warn(`Failed to fetch children for folder ${folderId}:`, res.statusText);
        break;
      }

      const data: any = await res.json();
      if (data.files && Array.isArray(data.files)) {
        allFiles = allFiles.concat(data.files);
      }
      pageToken = data.nextPageToken;
    } while (pageToken);

    return allFiles;
  }

  /**
   * Generate dummy buffer for demo mode files
   */
  private static async generateDemoFileContent(file: DriveFile): Promise<Uint8Array> {
    if (file.thumbnailLink && file.thumbnailLink.startsWith('http')) {
      try {
        const imgRes = await fetch(file.thumbnailLink);
        if (imgRes.ok) {
          const ab = await imgRes.arrayBuffer();
          return new Uint8Array(ab);
        }
      } catch (err) {
        // Fallback to text
      }
    }

    const content = `=====================================================
نسخة احتياطية من ملف: ${file.name}
معرف الملف: ${file.id}
نوع الملف: ${file.mimeType}
تاريخ التعديل: ${file.modifiedTime || new Date().toISOString()}
الوصف: ${file.description || 'لا يوجد وصف'}
تم إنشاء هذا الملف التوضيحي تلقائياً ضمن النسخة الاحتياطية.
=====================================================

محتوى توضيحي آمن ومحفوظ بنجاح.`;
    return new TextEncoder().encode(content);
  }

  /**
   * Main function: Create a ZIP backup of the specified folder
   */
  static async backupFolder(
    token: string | null,
    targetFolderId: string,
    targetFolderName: string,
    currentFilesList: DriveFile[],
    options: BackupOptions,
    onProgress?: (progress: BackupProgress) => void
  ): Promise<BackupResult> {
    const startTime = Date.now();
    const zip = new JSZip();

    let totalFilesScanned = 0;
    let totalFoldersScanned = 0;
    let uncompressedBytes = 0;
    let processedCount = 0;

    const manifestFilesList: Array<{
      name: string;
      path: string;
      size: number;
      mimeType: string;
      id: string;
      modifiedTime?: string;
    }> = [];

    // Phase 1: Scanning Folder Hierarchy
    if (onProgress) {
      onProgress({
        phase: 'scanning',
        totalFiles: 0,
        processedFiles: 0,
        currentFileName: targetFolderName,
        percent: 5,
        downloadedBytes: 0,
        message: `جاري فحص وهيكلة مجلد "${targetFolderName}"...`
      });
    }

    interface QueueItem {
      folderId: string;
      folderName: string;
      zipNode: JSZip;
      folderPath: string;
    }

    const folderQueue: QueueItem[] = [
      {
        folderId: targetFolderId,
        folderName: targetFolderName,
        zipNode: zip,
        folderPath: ''
      }
    ];

    // Collect all files to download
    interface DownloadTask {
      file: DriveFile;
      zipFolder: JSZip;
      folderPath: string;
    }
    const downloadTasks: DownloadTask[] = [];

    if (token) {
      while (folderQueue.length > 0) {
        const currentFolder = folderQueue.shift()!;
        totalFoldersScanned++;

        let children: DriveFile[] = [];
        // If this is the root of the current view and we already have currentFilesList loaded
        if (currentFolder.folderId === targetFolderId && currentFilesList.length > 0) {
          children = currentFilesList;
        } else {
          children = await this.fetchFolderChildren(token, currentFolder.folderId, (msg) => {
            if (onProgress) {
              onProgress({
                phase: 'scanning',
                totalFiles: downloadTasks.length,
                processedFiles: 0,
                currentFileName: currentFolder.folderName,
                percent: 8,
                downloadedBytes: uncompressedBytes,
                message: msg
              });
            }
          });
        }

        for (const child of children) {
          if (child.mimeType === 'application/vnd.google-apps.folder') {
            if (options.includeSubfolders) {
              const subZipNode = currentFolder.zipNode.folder(child.name) || currentFolder.zipNode;
              folderQueue.push({
                folderId: child.id,
                folderName: child.name,
                zipNode: subZipNode,
                folderPath: `${currentFolder.folderPath}${child.name}/`
              });
            }
          } else {
            downloadTasks.push({
              file: child,
              zipFolder: currentFolder.zipNode,
              folderPath: currentFolder.folderPath
            });
          }
        }
      }
    } else {
      // Demo Mode without token: use currentFilesList
      for (const item of currentFilesList) {
        if (item.mimeType === 'application/vnd.google-apps.folder') {
          totalFoldersScanned++;
          const subZip = zip.folder(item.name) || zip;
          // Add a placeholder file inside subfolder
          downloadTasks.push({
            file: {
              id: `${item.id}-sample-doc`,
              name: 'ملاحظات المجلد الداخلي.txt',
              mimeType: 'text/plain',
              size: '1024',
              modifiedTime: item.modifiedTime || new Date().toISOString()
            },
            zipFolder: subZip,
            folderPath: `${item.name}/`
          });
        } else {
          downloadTasks.push({
            file: item,
            zipFolder: zip,
            folderPath: ''
          });
        }
      }
    }

    totalFilesScanned = downloadTasks.length;

    if (totalFilesScanned === 0) {
      // Create at least a readme in empty folder
      zip.file('README_BACKUP.txt', `نسخة احتياطية لمجلد فارغ: ${targetFolderName}\nتاريخ الإنشاء: ${new Date().toLocaleString('ar-EG')}`);
    }

    // Phase 2: Downloading & Packing Files
    for (let i = 0; i < downloadTasks.length; i++) {
      const task = downloadTasks[i];
      const { file, zipFolder, folderPath } = task;
      processedCount++;

      const progressPercent = Math.min(85, Math.round(10 + (processedCount / (totalFilesScanned || 1)) * 75));

      if (onProgress) {
        onProgress({
          phase: 'downloading',
          totalFiles: totalFilesScanned,
          processedFiles: processedCount,
          currentFileName: file.name,
          percent: progressPercent,
          downloadedBytes: uncompressedBytes,
          message: `جاري تنزيل وضغط: "${file.name}" (${processedCount} من ${totalFilesScanned})...`
        });
      }

      try {
        let fileData: Uint8Array | ArrayBuffer | string;
        let finalFilename = file.name;

        if (token) {
          const exportConfig = this.getGoogleDocExportConfig(file, options.exportGoogleDocsFormat);

          if (exportConfig) {
            // Google Workspace Doc / Sheet / Slide
            finalFilename = this.ensureFilename(file.name, exportConfig.extension);
            const exportRes = await fetch(exportConfig.exportUrl, {
              headers: { Authorization: `Bearer ${token}` }
            });

            if (exportRes.ok) {
              fileData = await exportRes.arrayBuffer();
            } else {
              // Fallback to text summary if export fails
              const errText = `تعذر تصدير مستند Google Docs: ${file.name} (${exportRes.statusText})`;
              fileData = new TextEncoder().encode(errText);
              finalFilename = `${file.name}.txt`;
            }
          } else {
            // Standard media / binary download
            const downloadUrl = `https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`;
            const binRes = await fetch(downloadUrl, {
              headers: { Authorization: `Bearer ${token}` }
            });

            if (binRes.ok) {
              fileData = await binRes.arrayBuffer();
            } else {
              const errText = `تعذر تحميل ملف: ${file.name} (${binRes.statusText})`;
              fileData = new TextEncoder().encode(errText);
            }
          }
        } else {
          // Demo mode buffer
          fileData = await this.generateDemoFileContent(file);
        }

        const byteSize = fileData.byteLength;
        uncompressedBytes += byteSize;

        zipFolder.file(finalFilename, fileData, { binary: true });

        manifestFilesList.push({
          name: finalFilename,
          path: `${folderPath}${finalFilename}`,
          size: byteSize,
          mimeType: file.mimeType,
          id: file.id,
          modifiedTime: file.modifiedTime
        });

      } catch (fileErr) {
        console.warn(`Error processing file ${file.name} during backup:`, fileErr);
        // Write notice in zip so backup doesn't fail completely
        zipFolder.file(`${file.name}_ERROR_NOTICE.txt`, `فشل في تضمين الملف: ${file.name}\nالسبب: ${fileErr}`);
      }
    }

    // Include manifest metadata if requested
    if (options.includeManifest) {
      const manifest = {
        backupTitle: `نسخة احتياطية لمجلد: ${targetFolderName}`,
        targetFolderId,
        createdAt: new Date().toISOString(),
        totalFiles: manifestFilesList.length,
        totalFolders: totalFoldersScanned,
        uncompressedBytes,
        files: manifestFilesList
      };

      zip.file('backup-manifest.json', JSON.stringify(manifest, null, 2));

      const readmeContent = `===================================================================
🗂️ تقرير النسخ الاحتياطي - Google Drive Folder Backup
===================================================================
اسم المجلد: ${targetFolderName}
معرف المجلد: ${targetFolderId}
تاريخ النسخ الاحتياطي: ${new Date().toLocaleString('ar-EG')}
عدد الملفات: ${manifestFilesList.length} ملف
عدد المجلدات الفرعية: ${totalFoldersScanned} مجلد
إجمالي الحجم الأصلي: ${(uncompressedBytes / (1024 * 1024)).toFixed(2)} ميجابايت

الملفات المضمنة:
${manifestFilesList.map((f, idx) => `${idx + 1}. [${f.path}] (${(f.size / 1024).toFixed(1)} KB)`).join('\n')}

===================================================================
تم الإنشاء تلقائياً بواسطة نظام إدارة Google Drive الذكي
===================================================================`;

      zip.file('README_BACKUP_REPORT.txt', readmeContent);
    }

    // Phase 3: Final Compression
    if (onProgress) {
      onProgress({
        phase: 'compressing',
        totalFiles: totalFilesScanned,
        processedFiles: totalFilesScanned,
        currentFileName: 'توليد حزمة ZIP النهائية',
        percent: 90,
        downloadedBytes: uncompressedBytes,
        message: 'جاري ضغط الملفات وتشفير حزمة ZIP النهائية...'
      });
    }

    const zipBlob = await zip.generateAsync(
      {
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 }
      },
      (meta) => {
        if (onProgress) {
          const compPercent = Math.min(99, Math.round(90 + (meta.percent / 100) * 9));
          onProgress({
            phase: 'compressing',
            totalFiles: totalFilesScanned,
            processedFiles: totalFilesScanned,
            currentFileName: meta.currentFile || 'ضغط الحزمة',
            percent: compPercent,
            downloadedBytes: uncompressedBytes,
            message: `جاري ضغط الحزمة: ${meta.percent.toFixed(0)}% مكتمل...`
          });
        }
      }
    );

    const safeFolderName = targetFolderName.replace(/[\\/:*?"<>|]/g, '_').trim() || 'drive-folder';
    const dateStr = new Date().toISOString().split('T')[0];
    const finalZipName = `backup-${safeFolderName}-${dateStr}.zip`;

    if (onProgress) {
      onProgress({
        phase: 'completed',
        totalFiles: totalFilesScanned,
        processedFiles: totalFilesScanned,
        currentFileName: finalZipName,
        percent: 100,
        downloadedBytes: uncompressedBytes,
        message: 'اكتمل إنشاء النسخة الاحتياطية بنجاح!'
      });
    }

    return {
      zipBlob,
      fileName: finalZipName,
      totalFilesCount: manifestFilesList.length,
      totalFoldersCount: totalFoldersScanned,
      uncompressedBytes,
      compressedBytes: zipBlob.size,
      durationMs: Date.now() - startTime
    };
  }

  /**
   * Trigger automatic file download in the browser
   */
  static triggerBrowserDownload(blob: Blob, fileName: string): void {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}
