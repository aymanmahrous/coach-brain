export interface AccentThemePreset {
  id: string;
  name: string;
  nameEn: string;
  primary: string;
  primaryHover: string;
  primaryLight: string;
  primaryBorder: string;
  primaryText: string;
  ringColor: string;
  gradient: string;
  badgeBg: string;
  folderColor: string;
  description: string;
}

export interface UserThemePreferences {
  accentId: string;
  customHex?: string;
  borderRadius: 'standard' | 'subtle' | 'pill';
  density: 'comfortable' | 'compact';
  enableGlow: boolean;
  soundEffects: boolean;
}

export const ACCENT_PRESETS: AccentThemePreset[] = [
  {
    id: 'blue',
    name: 'أزرق كلاسيكي',
    nameEn: 'Classic Blue',
    primary: '#2563eb',
    primaryHover: '#1d4ed8',
    primaryLight: '#eff6ff',
    primaryBorder: '#bfdbfe',
    primaryText: '#1d4ed8',
    ringColor: 'rgba(37, 99, 235, 0.3)',
    gradient: 'from-blue-600 to-indigo-600',
    badgeBg: 'bg-blue-50 text-blue-700 border-blue-200',
    folderColor: '#3b82f6',
    description: 'اللون الافتراضي الأنيق والمستوحى من هوية Google Drive الرسمية',
  },
  {
    id: 'emerald',
    name: 'أخضر زمردي',
    nameEn: 'Emerald Green',
    primary: '#059669',
    primaryHover: '#047857',
    primaryLight: '#ecfdf5',
    primaryBorder: '#a7f3d0',
    primaryText: '#047857',
    ringColor: 'rgba(5, 150, 105, 0.3)',
    gradient: 'from-emerald-600 to-teal-700',
    badgeBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    folderColor: '#10b981',
    description: 'مظهر منعش ومريح للعين يعزز الإنتاجية والتركيز العالي',
  },
  {
    id: 'indigo',
    name: 'نيلي ملكي',
    nameEn: 'Royal Indigo',
    primary: '#4f46e5',
    primaryHover: '#4338ca',
    primaryLight: '#eef2ff',
    primaryBorder: '#c7d2fe',
    primaryText: '#4338ca',
    ringColor: 'rgba(79, 70, 229, 0.3)',
    gradient: 'from-indigo-600 to-violet-700',
    badgeBg: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    folderColor: '#6366f1',
    description: 'طابع عصري متقدم يبرز جمالية واجهات الذكاء الاصطناعي',
  },
  {
    id: 'violet',
    name: 'بنفسجي إمبراطوري',
    nameEn: 'Imperial Violet',
    primary: '#7c3aed',
    primaryHover: '#6d28d9',
    primaryLight: '#f5f3ff',
    primaryBorder: '#ddd6fe',
    primaryText: '#6d28d9',
    ringColor: 'rgba(124, 58, 237, 0.3)',
    gradient: 'from-violet-600 to-purple-700',
    badgeBg: 'bg-violet-50 text-violet-700 border-violet-200',
    folderColor: '#8b5cf6',
    description: 'لمسة من الإبداع والأناقة الفائقة للمصممين والمبتكرين',
  },
  {
    id: 'rose',
    name: 'وردي ياقوتي',
    nameEn: 'Ruby Rose',
    primary: '#e11d48',
    primaryHover: '#be123c',
    primaryLight: '#fff1f2',
    primaryBorder: '#fecdd3',
    primaryText: '#be123c',
    ringColor: 'rgba(225, 29, 72, 0.3)',
    gradient: 'from-rose-600 to-pink-600',
    badgeBg: 'bg-rose-50 text-rose-700 border-rose-200',
    folderColor: '#f43f5e',
    description: 'تباين مفعم بالحيوية والدفء للتمييز السريع للمستندات',
  },
  {
    id: 'amber',
    name: 'كهرماني / غروب',
    nameEn: 'Sunset Amber',
    primary: '#d97706',
    primaryHover: '#b45309',
    primaryLight: '#fffbeb',
    primaryBorder: '#fde68a',
    primaryText: '#b45309',
    ringColor: 'rgba(217, 119, 6, 0.3)',
    gradient: 'from-amber-600 to-orange-600',
    badgeBg: 'bg-amber-50 text-amber-700 border-amber-200',
    folderColor: '#f59e0b',
    description: 'درجات ذهبية دافئة تمنح شعوراً بالطاقة والإشراق',
  },
  {
    id: 'cyan',
    name: 'أزرق محيطي',
    nameEn: 'Oceanic Cyan',
    primary: '#0891b2',
    primaryHover: '#0e7490',
    primaryLight: '#ecfeff',
    primaryBorder: '#a5f3fc',
    primaryText: '#0e7490',
    ringColor: 'rgba(8, 145, 178, 0.3)',
    gradient: 'from-cyan-600 to-teal-700',
    badgeBg: 'bg-cyan-50 text-cyan-700 border-cyan-200',
    folderColor: '#06b6d4',
    description: 'درجات بحرية نقية توفر وضوحاً فائقاً وراحة بصرية متكاملة',
  },
  {
    id: 'slate',
    name: 'رمادي عصري (مينيمال)',
    nameEn: 'Modern Slate',
    primary: '#475569',
    primaryHover: '#334155',
    primaryLight: '#f8fafc',
    primaryBorder: '#cbd5e1',
    primaryText: '#334155',
    ringColor: 'rgba(71, 85, 105, 0.3)',
    gradient: 'from-slate-700 to-slate-900',
    badgeBg: 'bg-slate-100 text-slate-800 border-slate-300',
    folderColor: '#64748b',
    description: 'تصميم بسيط واحترافي خالي من المشتتات يناسب بيئات الأعمال',
  },
];

export const DEFAULT_THEME_PREFERENCES: UserThemePreferences = {
  accentId: 'blue',
  borderRadius: 'standard',
  density: 'comfortable',
  enableGlow: true,
  soundEffects: true,
};

const STORAGE_KEY = 'gdrive_theme_accent_preferences_v1';

export class ThemeService {
  /**
   * Load stored theme preferences from localStorage
   */
  static getPreferences(): UserThemePreferences {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...DEFAULT_THEME_PREFERENCES, ...parsed };
      }
    } catch (e) {
      console.warn('Failed to load theme preferences from localStorage', e);
    }
    return DEFAULT_THEME_PREFERENCES;
  }

  /**
   * Save preferences to localStorage and apply CSS variables
   */
  static savePreferences(prefs: UserThemePreferences): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
      this.applyTheme(prefs);
    } catch (e) {
      console.warn('Failed to save theme preferences to localStorage', e);
    }
  }

  /**
   * Get active preset details
   */
  static getActivePreset(prefs: UserThemePreferences): AccentThemePreset {
    if (prefs.accentId === 'custom' && prefs.customHex) {
      const hex = prefs.customHex;
      return {
        id: 'custom',
        name: 'لون مخصص',
        nameEn: 'Custom Color',
        primary: hex,
        primaryHover: this.adjustBrightness(hex, -20),
        primaryLight: this.hexToRgba(hex, 0.08),
        primaryBorder: this.hexToRgba(hex, 0.25),
        primaryText: this.adjustBrightness(hex, -15),
        ringColor: this.hexToRgba(hex, 0.3),
        gradient: `from-[${hex}] to-[${this.adjustBrightness(hex, -30)}]`,
        badgeBg: 'bg-slate-100 text-slate-800 border-slate-200',
        folderColor: hex,
        description: `لونك المختار بنظام HEX: ${hex}`,
      };
    }

    const preset = ACCENT_PRESETS.find((p) => p.id === prefs.accentId);
    return preset || ACCENT_PRESETS[0];
  }

  /**
   * Apply CSS variables dynamically to the document root
   */
  static applyTheme(prefs: UserThemePreferences): void {
    if (typeof document === 'undefined') return;

    const preset = this.getActivePreset(prefs);
    const root = document.documentElement;

    root.style.setProperty('--color-primary', preset.primary);
    root.style.setProperty('--color-primary-hover', preset.primaryHover);
    root.style.setProperty('--color-primary-light', preset.primaryLight);
    root.style.setProperty('--color-primary-border', preset.primaryBorder);
    root.style.setProperty('--color-primary-text', preset.primaryText);
    root.style.setProperty('--color-primary-ring', preset.ringColor);
    root.style.setProperty('--color-folder', preset.folderColor);

    // Border radius mappings
    const radiusMap = {
      subtle: '8px',
      standard: '12px',
      pill: '18px',
    };
    root.style.setProperty('--theme-border-radius', radiusMap[prefs.borderRadius] || '12px');

    // Data attributes for high-level selectors
    root.setAttribute('data-theme-accent', prefs.accentId);
    root.setAttribute('data-theme-radius', prefs.borderRadius);
    root.setAttribute('data-theme-density', prefs.density);
  }

  /**
   * Helper: Hex to RGBA
   */
  private static hexToRgba(hex: string, alpha: number): string {
    let cleanHex = hex.replace('#', '');
    if (cleanHex.length === 3) {
      cleanHex = cleanHex.split('').map((c) => c + c).join('');
    }
    const num = parseInt(cleanHex, 16);
    const r = (num >> 16) & 255;
    const g = (num >> 8) & 255;
    const b = num & 255;
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  /**
   * Helper: Adjust Hex Brightness
   */
  private static adjustBrightness(hex: string, percent: number): string {
    let cleanHex = hex.replace('#', '');
    if (cleanHex.length === 3) {
      cleanHex = cleanHex.split('').map((c) => c + c).join('');
    }
    const num = parseInt(cleanHex, 16);
    let r = (num >> 16) + percent;
    let g = ((num >> 8) & 0x00ff) + percent;
    let b = (num & 0x0000ff) + percent;

    r = Math.min(255, Math.max(0, r));
    g = Math.min(255, Math.max(0, g));
    b = Math.min(255, Math.max(0, b));

    return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
  }
}
