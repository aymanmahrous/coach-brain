import { 
  DriveAbout, 
  DriveCategoryFilter, 
  DriveFile, 
  SearchDateFilter, 
  SearchTypeFilter,
  DrivePermission,
  DrivePermissionRole,
  ShareFileRequest
} from '../types';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);

declare global {
  interface Window {
    google?: any;
  }
}

const STORAGE_TOKEN_KEY = 'gdrive_access_token';
const STORAGE_EXPIRES_AT = 'gdrive_token_expires_at';
const STORAGE_USER_KEY = 'gdrive_cached_user';

// Mock sample files for demo / offline preview
const DEMO_FILES: DriveFile[] = [
  {
    id: 'demo-folder-1',
    name: 'مشاريع 2026 والخطط الاستراتيجية',
    mimeType: 'application/vnd.google-apps.folder',
    modifiedTime: new Date(Date.now() - 3600000 * 2).toISOString(),
    starred: true,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
  },
  {
    id: 'demo-folder-2',
    name: 'التقارير المالية والفواتير الرسمية',
    mimeType: 'application/vnd.google-apps.folder',
    modifiedTime: new Date(Date.now() - 3600000 * 24).toISOString(),
    starred: false,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
  },
  {
    id: 'demo-invoice-1',
    name: 'فاتورة اشتراك خدمات السحابة والمعدات Q2-2026.pdf',
    mimeType: 'application/pdf',
    size: '342100',
    modifiedTime: new Date(Date.now() - 3600000 * 3).toISOString(),
    webViewLink: 'https://drive.google.com/file/d/demo_inv1',
    starred: true,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'فاتورة ضريبية رسمية لمصاريف السيرفرات والاشتراكات السحابية للربع الثاني بمبلغ 4,500 ريال.',
  },
  {
    id: 'demo-invoice-2',
    name: 'سند قبض ودفع أتعاب الاستشارات وتطوير البرمجيات.pdf',
    mimeType: 'application/pdf',
    size: '198400',
    modifiedTime: new Date(Date.now() - 3600000 * 18).toISOString(),
    webViewLink: 'https://drive.google.com/file/d/demo_inv2',
    starred: false,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'سند صرف رسمي للدفعة الأولى من خدمات التطوير التقني.',
  },
  {
    id: 'demo-doc-1',
    name: 'وثيقة خطة العمل وخارطة الطريق Q3-Q4.gdoc',
    mimeType: 'application/vnd.google-apps.document',
    size: '148200',
    modifiedTime: new Date(Date.now() - 3600000 * 5).toISOString(),
    webViewLink: 'https://docs.google.com/document/d/demo1',
    starred: true,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'خطة عمل تفصيلية لربع السنة الحالي تشمل الأهداف والمؤشرات والأولويات التقنية.',
  },
  {
    id: 'demo-sheet-1',
    name: 'جدول الميزانية وتتبع المصروفات والأداء المالي 2026.gsheet',
    mimeType: 'application/vnd.google-apps.spreadsheet',
    size: '89400',
    modifiedTime: new Date(Date.now() - 3600000 * 12).toISOString(),
    webViewLink: 'https://docs.google.com/spreadsheets/d/demo2',
    starred: true,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'جدول تحليلي كامل للإيرادات والمصروفات ومؤشرات التدفق النقدي الشهري.',
  },
  {
    id: 'demo-contract-1',
    name: 'عقد اتفاقية تقديم خدمات برمجية وصيانة سنوية SLA.pdf',
    mimeType: 'application/pdf',
    size: '820400',
    modifiedTime: new Date(Date.now() - 3600000 * 30).toISOString(),
    webViewLink: 'https://drive.google.com/file/d/demo_contract1',
    starred: true,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'عقد قانوني ملزم يحدد التزامات مستوى الخدمة وضمانات التشغيل المستمر.',
  },
  {
    id: 'demo-contract-2',
    name: 'اتفاقية عدم الإفصاح وحماية السرية NDA.pdf',
    mimeType: 'application/pdf',
    size: '265000',
    modifiedTime: new Date(Date.now() - 3600000 * 40).toISOString(),
    webViewLink: 'https://drive.google.com/file/d/demo_nda',
    starred: false,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'اتفاقية حماية البيانات والسرية التجارية المتبادلة بين الطرفين.',
  },
  {
    id: 'demo-slide-1',
    name: 'عرض تقديمي - استعراض المنتج والخدمات الجديدة.gslides',
    mimeType: 'application/vnd.google-apps.presentation',
    size: '3450000',
    modifiedTime: new Date(Date.now() - 3600000 * 48).toISOString(),
    webViewLink: 'https://docs.google.com/presentation/d/demo3',
    starred: false,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'شرائح العرض التقديمي لاستعراض الميزات الاستراتيجية للعملاء والمستثمرين.',
  },
  {
    id: 'demo-pdf-1',
    name: 'دليل المستخدم وسياسات الاستخدام والأمان.pdf',
    mimeType: 'application/pdf',
    size: '2411724',
    modifiedTime: new Date(Date.now() - 3600000 * 72).toISOString(),
    webViewLink: 'https://drive.google.com/file/d/demo4',
    starred: false,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'دليل تدريبي وتعليمي شامل للمستخدمين الجدد.',
  },
  {
    id: 'demo-edu-1',
    name: 'ملخص دورة إدارة المنتجات الرقمية والذكاء الاصطناعي.gdoc',
    mimeType: 'application/vnd.google-apps.document',
    size: '112000',
    modifiedTime: new Date(Date.now() - 3600000 * 80).toISOString(),
    webViewLink: 'https://docs.google.com/document/d/demo_edu1',
    starred: false,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'مذكرات وملاحظات تعليمية حول تطبيق أدوات الذكاء الاصطناعي في إدارة المنتجات.',
  },
  {
    id: 'demo-img-1',
    name: 'شعار المنصة بدقة عالية - الهوية البصرية.png',
    mimeType: 'image/png',
    size: '1240000',
    modifiedTime: new Date(Date.now() - 3600000 * 96).toISOString(),
    thumbnailLink: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&auto=format&fit=crop&q=60',
    webViewLink: 'https://drive.google.com/file/d/demo5',
    starred: true,
    owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
    description: 'الملف الرسومي المعتمد لشعار وهوية المنصة.',
  }
];

let localDemoFiles: DriveFile[] = [...DEMO_FILES];

export class DriveService {
  static getStoredToken(): string | null {
    const token = localStorage.getItem(STORAGE_TOKEN_KEY);
    const expiresAt = localStorage.getItem(STORAGE_EXPIRES_AT);
    if (!token) return null;
    if (expiresAt && Number(expiresAt) < Date.now()) {
      localStorage.removeItem(STORAGE_TOKEN_KEY);
      localStorage.removeItem(STORAGE_EXPIRES_AT);
      return null;
    }
    return token;
  }

  static setStoredToken(token: string, expiresInSeconds: number = 3599): void {
    localStorage.setItem(STORAGE_TOKEN_KEY, token);
    localStorage.setItem(STORAGE_EXPIRES_AT, String(Date.now() + expiresInSeconds * 1000));
  }

  static clearStoredToken(): void {
    localStorage.removeItem(STORAGE_TOKEN_KEY);
    localStorage.removeItem(STORAGE_EXPIRES_AT);
    localStorage.removeItem(STORAGE_USER_KEY);
  }

  // Request OAuth Access Token using Firebase Auth or Google Identity Services
  static async requestGoogleAuth(clientId?: string): Promise<string> {
    // 1. Try Firebase Auth popup first
    let fbPopupBlocked = false;
    try {
      const provider = new GoogleAuthProvider();
      provider.addScope('https://www.googleapis.com/auth/drive.readonly');
      provider.addScope('https://www.googleapis.com/auth/drive.file');

      const result = await signInWithPopup(auth, provider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        DriveService.setStoredToken(credential.accessToken, 3599);
        return credential.accessToken;
      }
    } catch (fbErr: any) {
      console.warn('Firebase Auth popup attempt:', fbErr?.code || fbErr?.message || fbErr);
      if (fbErr?.code === 'auth/popup-blocked') {
        fbPopupBlocked = true;
      }
    }

    // 2. Fallback to Google Identity Services (GSI)
    return new Promise((resolve, reject) => {
      if (!window.google?.accounts?.oauth2) {
        if (fbPopupBlocked) {
          reject(new Error('تم حظر النافذة المنبثقة بواسطة المتصفح. يرجى السماح بالنوافذ المنبثقة (Popups) لهذا الموقع أو فتح التطبيق في تبويب مستقل.'));
          return;
        }
        reject(new Error('مكتبة المصادقة غير محملة بعد، يرجى المحاولة بعد لحظات.'));
        return;
      }

      const effectiveClientId = clientId || 
        ((import.meta as any).env?.VITE_GOOGLE_CLIENT_ID as string) || 
        firebaseConfig.oAuthClientId ||
        '824575616729-0d21e2s5un7il5qu6a6e4ib6aqpls0p2.apps.googleusercontent.com';

      try {
        const client = window.google.accounts.oauth2.initTokenClient({
          client_id: effectiveClientId,
          scope: 'https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/drive.file',
          callback: (response: any) => {
            if (response.error) {
              reject(new Error(response.error_description || response.error));
              return;
            }
            if (response.access_token) {
              const expiresIn = response.expires_in ? Number(response.expires_in) : 3599;
              DriveService.setStoredToken(response.access_token, expiresIn);
              resolve(response.access_token);
            } else {
              reject(new Error('لم يتم استلام رمز الوصول المصرح.'));
            }
          },
          error_callback: (err: any) => {
            const isPopupBlocked = err?.type === 'popup_failed_to_open' || err?.type === 'popup_closed';
            if (isPopupBlocked || fbPopupBlocked) {
              reject(new Error('تم حظر النافذة المنبثقة بواسطة المتصفح أو إطار المعاينة. يرجى السماح بالنوافذ المنبثقة (Popups) أو فتح التطبيق في نافذة جديدة.'));
            } else {
              reject(new Error(err.message || 'فشلت عملية تسجيل الدخول إلى Google.'));
            }
          }
        });

        client.requestAccessToken({ prompt: 'consent' });
      } catch (err: any) {
        reject(err);
      }
    });
  }

  // Fetch user profile and storage quota
  static async getAbout(token: string | null): Promise<DriveAbout> {
    if (!token) {
      return {
        user: {
          displayName: 'أيمن محروس',
          emailAddress: 'swimmingayman@gmail.com',
          photoLink: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
        },
        storageQuota: {
          limit: '16106127360', // 15 GB
          usage: '5261334937',  // 4.9 GB
          usageInDrive: '4120394012',
          usageInDriveTrash: '140940925',
        }
      };
    }

    try {
      const res = await fetch('https://www.googleapis.com/drive/v3/about?fields=user,storageQuota,maxUploadSize', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) {
        if (res.status === 401) {
          DriveService.clearStoredToken();
          throw new Error('انتهت صلاحية جلسة Google Drive. يرجى إعادة تسجيل الدخول.');
        }
        throw new Error(`خطأ في جلب بيانات الحساب (${res.status})`);
      }
      return await res.json();
    } catch (e) {
      console.warn('Falling back to local user profile info', e);
      return {
        user: {
          displayName: 'مستخدم Google Drive',
          emailAddress: 'swimmingayman@gmail.com',
        },
        storageQuota: {
          limit: '16106127360',
          usage: '4294967296',
        }
      };
    }
  }

  // List files with search, filtering, and parent folder navigation
  static async listFiles(
    token: string | null,
    options: {
      folderId?: string;
      searchQuery?: string;
      category?: DriveCategoryFilter;
      trashed?: boolean;
      starred?: boolean;
      dateModified?: SearchDateFilter;
      typeFilter?: SearchTypeFilter;
    } = {}
  ): Promise<{ files: DriveFile[]; nextPageToken?: string }> {
    const { 
      folderId = 'root', 
      searchQuery, 
      category = 'all', 
      trashed = false, 
      starred = false,
      dateModified = 'all',
      typeFilter = 'all',
    } = options;

    if (!token) {
      // Return local demo files filtered accordingly
      let filtered = [...localDemoFiles];

      if (trashed) {
        filtered = filtered.filter(f => f.trashed);
      } else {
        filtered = filtered.filter(f => !f.trashed);

        if (starred) {
          filtered = filtered.filter(f => f.starred);
        } else if (category === 'folders' || typeFilter === 'folders') {
          filtered = filtered.filter(f => f.mimeType === 'application/vnd.google-apps.folder');
        } else if (category === 'docs' || typeFilter === 'docs') {
          filtered = filtered.filter(f => f.mimeType.includes('document') || f.mimeType.includes('text'));
        } else if (category === 'sheets' || typeFilter === 'sheets') {
          filtered = filtered.filter(f => f.mimeType.includes('spreadsheet') || f.mimeType.includes('excel') || f.mimeType.includes('csv'));
        } else if (category === 'slides' || typeFilter === 'slides') {
          filtered = filtered.filter(f => f.mimeType.includes('presentation') || f.mimeType.includes('powerpoint'));
        } else if (category === 'pdf' || typeFilter === 'pdf') {
          filtered = filtered.filter(f => f.mimeType.includes('pdf'));
        } else if (category === 'images' || typeFilter === 'images') {
          filtered = filtered.filter(f => f.mimeType.startsWith('image/'));
        }
      }

      // Date Modified Filter for local demo
      if (dateModified && dateModified !== 'all') {
        const now = Date.now();
        let ms = 0;
        if (dateModified === 'today') ms = 24 * 60 * 60 * 1000;
        else if (dateModified === 'week') ms = 7 * 24 * 60 * 60 * 1000;
        else if (dateModified === 'month') ms = 30 * 24 * 60 * 60 * 1000;
        else if (dateModified === 'year') ms = 365 * 24 * 60 * 60 * 1000;

        if (ms > 0) {
          const cutoff = now - ms;
          filtered = filtered.filter(f => {
            if (!f.modifiedTime) return false;
            return new Date(f.modifiedTime).getTime() >= cutoff;
          });
        }
      }

      if (searchQuery && searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        filtered = filtered.filter(f => f.name.toLowerCase().includes(q));
      }

      return { files: filtered };
    }

    // Build Google Drive API query string (q parameter)
    const queries: string[] = [];

    if (trashed) {
      queries.push('trashed = true');
    } else {
      queries.push('trashed = false');

      const effectiveType = typeFilter !== 'all' ? typeFilter : category;

      if (starred) {
        queries.push('starred = true');
      } else if (effectiveType === 'folders') {
        queries.push("mimeType = 'application/vnd.google-apps.folder'");
      } else if (effectiveType === 'docs') {
        queries.push("mimeType = 'application/vnd.google-apps.document' or mimeType = 'text/plain'");
      } else if (effectiveType === 'sheets') {
        queries.push("mimeType = 'application/vnd.google-apps.spreadsheet' or mimeType = 'text/csv'");
      } else if (effectiveType === 'slides') {
        queries.push("mimeType = 'application/vnd.google-apps.presentation'");
      } else if (effectiveType === 'pdf') {
        queries.push("mimeType = 'application/pdf'");
      } else if (effectiveType === 'images') {
        queries.push("mimeType contains 'image/'");
      } else if (category === 'all' && folderId && (!searchQuery || !searchQuery.trim())) {
        queries.push(`'${folderId}' in parents`);
      }
    }

    // Date Modified Filter for Google Drive API
    if (dateModified && dateModified !== 'all') {
      const now = Date.now();
      let ms = 0;
      if (dateModified === 'today') ms = 24 * 60 * 60 * 1000;
      else if (dateModified === 'week') ms = 7 * 24 * 60 * 60 * 1000;
      else if (dateModified === 'month') ms = 30 * 24 * 60 * 60 * 1000;
      else if (dateModified === 'year') ms = 365 * 24 * 60 * 60 * 1000;

      if (ms > 0) {
        const iso = new Date(now - ms).toISOString();
        queries.push(`modifiedTime >= '${iso}'`);
      }
    }

    if (searchQuery && searchQuery.trim()) {
      const sanitized = searchQuery.replace(/'/g, "\\'");
      queries.push(`name contains '${sanitized}'`);
    }

    const q = queries.join(' and ');
    const fields = 'files(id, name, mimeType, size, createdTime, modifiedTime, webViewLink, webContentLink, thumbnailLink, iconLink, shared, starred, trashed, parents, owners, description), nextPageToken';
    const url = `https://www.googleapis.com/drive/v3/files?pageSize=50&fields=${encodeURIComponent(fields)}&orderBy=folder,modifiedTime desc&q=${encodeURIComponent(q)}`;

    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok) {
      if (res.status === 401) {
        DriveService.clearStoredToken();
        throw new Error('انتهت صلاحية رمز الدخول. يرجى إعادة تسجيل الدخول إلى Google.');
      }
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || `فشل في استعراض الملفات (${res.status})`);
    }

    const data = await res.json();
    return { files: data.files || [], nextPageToken: data.nextPageToken };
  }

  // Create a new folder
  static async createFolder(token: string | null, name: string, parentId: string = 'root'): Promise<DriveFile> {
    if (!token) {
      const newFolder: DriveFile = {
        id: `demo-folder-${Date.now()}`,
        name,
        mimeType: 'application/vnd.google-apps.folder',
        modifiedTime: new Date().toISOString(),
        starred: false,
        owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
      };
      localDemoFiles.unshift(newFolder);
      return newFolder;
    }

    const metadata: any = {
      name,
      mimeType: 'application/vnd.google-apps.folder',
    };
    if (parentId && parentId !== 'root') {
      metadata.parents = [parentId];
    }

    const res = await fetch('https://www.googleapis.com/drive/v3/files', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(metadata)
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'فشل إنشاء المجلد الجديد.');
    }

    return await res.json();
  }

  // Upload a file using multipart upload
  static async uploadFile(
    token: string | null,
    file: File,
    parentId: string = 'root',
    onProgress?: (percent: number) => void
  ): Promise<DriveFile> {
    if (!token) {
      const newFile: DriveFile = {
        id: `demo-file-${Date.now()}`,
        name: file.name,
        mimeType: file.type || 'application/octet-stream',
        size: String(file.size),
        modifiedTime: new Date().toISOString(),
        starred: false,
        owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
      };
      localDemoFiles.unshift(newFile);
      if (onProgress) onProgress(100);
      return newFile;
    }

    const metadata: any = {
      name: file.name,
      mimeType: file.type || 'application/octet-stream',
    };
    if (parentId && parentId !== 'root') {
      metadata.parents = [parentId];
    }

    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', file);

    const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: form
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'فشل في رفع الملف إلى Google Drive.');
    }

    if (onProgress) onProgress(100);
    return await res.json();
  }

  // Create a new text/markdown document directly in Drive
  static async createTextDocument(
    token: string | null,
    title: string,
    content: string,
    parentId: string = 'root'
  ): Promise<DriveFile> {
    if (!token) {
      const newDoc: DriveFile = {
        id: `demo-doc-${Date.now()}`,
        name: title.endsWith('.txt') || title.endsWith('.md') ? title : `${title}.md`,
        mimeType: 'text/markdown',
        size: String(new Blob([content]).size),
        modifiedTime: new Date().toISOString(),
        starred: false,
        description: content.slice(0, 150),
        owners: [{ displayName: 'أيمن محروس', emailAddress: 'swimmingayman@gmail.com' }],
      };
      localDemoFiles.unshift(newDoc);
      return newDoc;
    }

    const metadata: any = {
      name: title.endsWith('.txt') || title.endsWith('.md') ? title : `${title}.md`,
      mimeType: 'text/markdown',
    };
    if (parentId && parentId !== 'root') {
      metadata.parents = [parentId];
    }

    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', new Blob([content], { type: 'text/markdown' }));

    const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: form
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'فشل في حفظ المستند في Google Drive.');
    }

    return await res.json();
  }

  // Rename a file
  static async renameFile(token: string | null, fileId: string, newName: string): Promise<void> {
    if (!token) {
      const file = localDemoFiles.find(f => f.id === fileId);
      if (file) file.name = newName;
      return;
    }

    const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name: newName })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'فشل في إعادة تسمية الملف.');
    }
  }

  // Star or unstar a file
  static async toggleStar(token: string | null, fileId: string, starred: boolean): Promise<void> {
    if (!token) {
      const file = localDemoFiles.find(f => f.id === fileId);
      if (file) file.starred = starred;
      return;
    }

    const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ starred })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'فشل في تحديث حالة التمييز بنجمة.');
    }
  }

  // Delete or move to trash
  static async trashOrDeleteFile(token: string | null, fileId: string, permanent: boolean = false): Promise<void> {
    if (!token) {
      if (permanent) {
        localDemoFiles = localDemoFiles.filter(f => f.id !== fileId);
      } else {
        const file = localDemoFiles.find(f => f.id === fileId);
        if (file) file.trashed = true;
      }
      return;
    }

    if (permanent) {
      const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error?.message || 'فشل في الحذف النهائي للملف.');
      }
    } else {
      const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ trashed: true })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error?.message || 'فشل في نقل الملف إلى سلة المهملات.');
      }
    }
  }

  // Restore file from trash
  static async restoreFile(token: string | null, fileId: string): Promise<void> {
    if (!token) {
      const file = localDemoFiles.find(f => f.id === fileId);
      if (file) file.trashed = false;
      return;
    }

    const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ trashed: false })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'فشل في استعادة الملف.');
    }
  }

  // Read text content from Google Docs / plain files for AI processing
  static async fetchFileTextContent(token: string | null, file: DriveFile): Promise<string> {
    if (!token) {
      if (file.description) return file.description;
      return `محتوى تجريبي لمستند "${file.name}". يحتوي على تفاصيل وخطط عمل وملاحظات متقدمة لإدارة المشاريع وتحليل الأداء والنتائج.`;
    }

    try {
      if (file.mimeType === 'application/vnd.google-apps.document') {
        const exportUrl = `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/plain`;
        const res = await fetch(exportUrl, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          return await res.text();
        }
      } else if (file.mimeType.startsWith('text/') || file.mimeType.includes('json') || file.mimeType.includes('csv')) {
        const downloadUrl = `https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`;
        const res = await fetch(downloadUrl, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          return await res.text();
        }
      }
    } catch (e) {
      console.warn('Could not read file body directly:', e);
    }

    return `الملف: ${file.name}\nالنوع: ${file.mimeType}\nالحجم: ${file.size || 'غير محدد'}\nآخر تعديل: ${file.modifiedTime || 'غير محدد'}`;
  }

  // File Sharing & Permissions API
  private static demoPermissionsStore: Record<string, DrivePermission[]> = {
    'demo-folder-1': [
      {
        id: 'perm-owner-1',
        type: 'user',
        role: 'owner',
        displayName: 'أيمن محروس (أنت)',
        emailAddress: 'swimmingayman@gmail.com',
      },
      {
        id: 'perm-1',
        type: 'user',
        role: 'writer',
        displayName: 'فريق التطوير والبرمجة',
        emailAddress: 'dev-team@company.org',
      }
    ],
    'demo-folder-2': [
      {
        id: 'perm-owner-2',
        type: 'user',
        role: 'owner',
        displayName: 'أيمن محروس (أنت)',
        emailAddress: 'swimmingayman@gmail.com',
      }
    ],
    'demo-invoice-1': [
      {
        id: 'perm-owner-3',
        type: 'user',
        role: 'owner',
        displayName: 'أيمن محروس (أنت)',
        emailAddress: 'swimmingayman@gmail.com',
      },
      {
        id: 'perm-2',
        type: 'user',
        role: 'reader',
        displayName: 'المحاسب المالي',
        emailAddress: 'finance-audit@company.org',
      }
    ],
    'demo-doc-1': [
      {
        id: 'perm-owner-4',
        type: 'user',
        role: 'owner',
        displayName: 'أيمن محروس (أنت)',
        emailAddress: 'swimmingayman@gmail.com',
      },
      {
        id: 'perm-3',
        type: 'user',
        role: 'commenter',
        displayName: 'إدارة العمليات',
        emailAddress: 'operations@company.org',
      }
    ]
  };

  /**
   * List all permissions / collaborators for a given Google Drive file
   */
  static async getFilePermissions(
    token: string | null, 
    fileId: string, 
    fallbackFile?: DriveFile | null
  ): Promise<DrivePermission[]> {
    if (token) {
      try {
        const url = `https://www.googleapis.com/drive/v3/files/${fileId}/permissions?fields=permissions(id,displayName,emailAddress,role,type,photoLink,deleted)&supportsAllDrives=true`;
        const res = await fetch(url, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.permissions) && data.permissions.length > 0) {
            return data.permissions;
          }
        }
      } catch (err) {
        console.warn('Google Drive getPermissions API error:', err);
      }
    }

    // Local / Demo Fallback
    if (DriveService.demoPermissionsStore[fileId]) {
      return [...DriveService.demoPermissionsStore[fileId]];
    }

    const defaultOwnerEmail = fallbackFile?.owners?.[0]?.emailAddress || 'swimmingayman@gmail.com';
    const defaultOwnerName = fallbackFile?.owners?.[0]?.displayName || 'المالك الحالي';

    const defaultPerms: DrivePermission[] = [
      {
        id: `perm-owner-${fileId}`,
        type: 'user',
        role: 'owner',
        displayName: `${defaultOwnerName} (أنت)`,
        emailAddress: defaultOwnerEmail,
      }
    ];

    DriveService.demoPermissionsStore[fileId] = defaultPerms;
    return [...defaultPerms];
  }

  /**
   * Share a file by granting a specific role (reader, commenter, writer) to an email address
   */
  static async shareFile(
    token: string | null,
    fileId: string,
    request: ShareFileRequest
  ): Promise<DrivePermission> {
    const { emailAddress, role, sendNotificationEmail = true, message } = request;

    if (!emailAddress || !emailAddress.includes('@')) {
      throw new Error('يرجى إدخال عنوان بريد إلكتروني صالح.');
    }

    if (token) {
      try {
        let url = `https://www.googleapis.com/drive/v3/files/${fileId}/permissions?sendNotificationEmail=${Boolean(sendNotificationEmail)}&supportsAllDrives=true`;
        if (message && sendNotificationEmail) {
          url += `&emailMessage=${encodeURIComponent(message)}`;
        }

        const res = await fetch(url, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            role,
            type: 'user',
            emailAddress: emailAddress.trim()
          })
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          const errMsg = errData.error?.message || `فشل إضافة الإذن (كود: ${res.status})`;
          throw new Error(errMsg);
        }

        const createdPerm: DrivePermission = await res.json();
        
        // Also update local store for instant reactive responsiveness
        if (!DriveService.demoPermissionsStore[fileId]) {
          DriveService.demoPermissionsStore[fileId] = [];
        }
        DriveService.demoPermissionsStore[fileId].push(createdPerm);

        return createdPerm;
      } catch (err: any) {
        console.warn('API share error, falling back to local simulation:', err);
        if (token && !err.message?.includes('Failed to fetch') && !err.message?.includes('NetworkError')) {
          // If it's a real API permission error from Google, throw it so user gets feedback
          throw err;
        }
      }
    }

    // Local / Demo implementation
    const newPerm: DrivePermission = {
      id: `perm-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      type: 'user',
      role,
      displayName: emailAddress.split('@')[0],
      emailAddress: emailAddress.trim(),
    };

    if (!DriveService.demoPermissionsStore[fileId]) {
      DriveService.demoPermissionsStore[fileId] = [
        {
          id: `perm-owner-${fileId}`,
          type: 'user',
          role: 'owner',
          displayName: 'أنت (المالك)',
          emailAddress: 'swimmingayman@gmail.com',
        }
      ];
    }

    // Check if user already exists
    const existingIndex = DriveService.demoPermissionsStore[fileId].findIndex(
      p => p.emailAddress?.toLowerCase() === emailAddress.trim().toLowerCase()
    );

    if (existingIndex >= 0) {
      DriveService.demoPermissionsStore[fileId][existingIndex].role = role;
      return DriveService.demoPermissionsStore[fileId][existingIndex];
    } else {
      DriveService.demoPermissionsStore[fileId].push(newPerm);
      // Mark file as shared in local files list
      const targetFile = localDemoFiles.find(f => f.id === fileId);
      if (targetFile) targetFile.shared = true;
      return newPerm;
    }
  }

  /**
   * Update an existing collaborator's permission role (reader / commenter / writer)
   */
  static async updateFilePermission(
    token: string | null,
    fileId: string,
    permissionId: string,
    role: DrivePermissionRole
  ): Promise<DrivePermission> {
    if (token) {
      try {
        const url = `https://www.googleapis.com/drive/v3/files/${fileId}/permissions/${permissionId}?supportsAllDrives=true`;
        const res = await fetch(url, {
          method: 'PATCH',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ role })
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error?.message || `فشل تحديث الصلاحية (${res.status})`);
        }

        const updated: DrivePermission = await res.json();
        return updated;
      } catch (err: any) {
        console.warn('API update permission error:', err);
        if (token && !err.message?.includes('Failed to fetch')) {
          throw err;
        }
      }
    }

    // Local / Demo update
    const list = DriveService.demoPermissionsStore[fileId] || [];
    const item = list.find(p => p.id === permissionId);
    if (item) {
      item.role = role;
      return item;
    }

    throw new Error('لم يتم العثور على الإذن المطلوب.');
  }

  /**
   * Delete a collaborator's permission (revoke access)
   */
  static async removeFilePermission(
    token: string | null,
    fileId: string,
    permissionId: string
  ): Promise<boolean> {
    if (token) {
      try {
        const url = `https://www.googleapis.com/drive/v3/files/${fileId}/permissions/${permissionId}?supportsAllDrives=true`;
        const res = await fetch(url, {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        if (!res.ok && res.status !== 204) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error?.message || `فشل حذف الإذن (${res.status})`);
        }
      } catch (err: any) {
        console.warn('API remove permission error:', err);
        if (token && !err.message?.includes('Failed to fetch')) {
          throw err;
        }
      }
    }

    // Local / Demo update
    if (DriveService.demoPermissionsStore[fileId]) {
      DriveService.demoPermissionsStore[fileId] = DriveService.demoPermissionsStore[fileId].filter(
        p => p.id !== permissionId
      );
    }
    return true;
  }
}

// Utility: Format bytes to human-readable size
export function formatBytes(bytes?: string | number): string {
  if (!bytes) return '—';
  const num = Number(bytes);
  if (isNaN(num) || num === 0) return '0 بايت';
  const k = 1024;
  const sizes = ['بايت', 'ك.ب', 'م.ب', 'ج.ب', 'ت.ب'];
  const i = Math.floor(Math.log(num) / Math.log(k));
  return parseFloat((num / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// Utility: Format ISO date string to localized Arabic date
export function formatDate(isoString?: string): string {
  if (!isoString) return '—';
  try {
    const d = new Date(isoString);
    return new Intl.DateTimeFormat('ar-EG', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(d);
  } catch {
    return isoString;
  }
}

// Utility: Identify file category and styling colors
export function getFileTypeMeta(mimeType: string) {
  if (mimeType === 'application/vnd.google-apps.folder') {
    return { label: 'مجلد', color: 'text-amber-500 bg-amber-50 border-amber-200', type: 'folder' };
  }
  if (mimeType.includes('document') || mimeType.includes('word') || mimeType.includes('text')) {
    return { label: 'مستند Google Docs', color: 'text-blue-600 bg-blue-50 border-blue-200', type: 'doc' };
  }
  if (mimeType.includes('spreadsheet') || mimeType.includes('excel') || mimeType.includes('csv')) {
    return { label: 'جدول Google Sheets', color: 'text-emerald-600 bg-emerald-50 border-emerald-200', type: 'sheet' };
  }
  if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) {
    return { label: 'عرض Google Slides', color: 'text-amber-600 bg-amber-50 border-amber-200', type: 'slide' };
  }
  if (mimeType.includes('pdf')) {
    return { label: 'ملف PDF', color: 'text-rose-600 bg-rose-50 border-rose-200', type: 'pdf' };
  }
  if (mimeType.startsWith('image/')) {
    return { label: 'صورة', color: 'text-purple-600 bg-purple-50 border-purple-200', type: 'image' };
  }
  if (mimeType.startsWith('video/')) {
    return { label: 'فيديو', color: 'text-indigo-600 bg-indigo-50 border-indigo-200', type: 'video' };
  }
  if (mimeType.startsWith('audio/')) {
    return { label: 'ملف صوتي', color: 'text-pink-600 bg-pink-50 border-pink-200', type: 'audio' };
  }
  if (mimeType.includes('zip') || mimeType.includes('tar') || mimeType.includes('compressed')) {
    return { label: 'ملف مضغوط', color: 'text-slate-600 bg-slate-100 border-slate-300', type: 'zip' };
  }
  return { label: 'ملف', color: 'text-slate-600 bg-slate-50 border-slate-200', type: 'file' };
}
