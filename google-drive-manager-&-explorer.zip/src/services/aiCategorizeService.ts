import { AICategoryKey, AICategoryClassification, DriveFile } from '../types';

const STORAGE_CATEGORIES_CACHE = 'gdrive_ai_categories_cache_v2';

export interface AICategoryMeta {
  key: AICategoryKey;
  label: string;
  description: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  iconName: string;
  examples: string;
}

export const AI_CATEGORIES: Record<AICategoryKey, AICategoryMeta> = {
  invoices: {
    key: 'invoices',
    label: 'فواتير وسندات مالية',
    description: 'فواتير، إيصالات، مطالبات، تسعيرات وسندات دفع',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-700',
    badgeBorder: 'border-emerald-200',
    iconName: 'Receipt',
    examples: 'فاتورة، إيصال، حساب، ميزانية، سند',
  },
  reports: {
    key: 'reports',
    label: 'تقارير وتحليلات',
    description: 'تقارير أداء دورية، مؤشرات KPI، تحليلات بيانات',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-700',
    badgeBorder: 'border-blue-200',
    iconName: 'BarChart3',
    examples: 'تقرير، إحصائيات، تحليل، ملخص مالي',
  },
  projects: {
    key: 'projects',
    label: 'مشاريع وخطط عمل',
    description: 'خطط تنفيذية، Roadmap، دراسات جدوى ومواصفات',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-700',
    badgeBorder: 'border-amber-200',
    iconName: 'Rocket',
    examples: 'خطة، مشروع، roadmap، استراتيجية',
  },
  contracts: {
    key: 'contracts',
    label: 'عقود ومستندات رسمية',
    description: 'عقود عمل، اتفاقيات NDA، تراخيص ولوائح نظامية',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-purple-700',
    badgeBorder: 'border-purple-200',
    iconName: 'FileCheck2',
    examples: 'عقد، اتفاقية، تفويض، شروط، NDA',
  },
  education: {
    key: 'education',
    label: 'تعليم ومذكرات',
    description: 'دورات تدريبية، ملخصات كتب ومذكرات معرفية',
    badgeBg: 'bg-cyan-50',
    badgeText: 'text-cyan-700',
    badgeBorder: 'border-cyan-200',
    iconName: 'GraduationCap',
    examples: 'دورة، تدريب، كتاب، ملخص، مرجع',
  },
  media: {
    key: 'media',
    label: 'تصاميم ووسائط',
    description: 'صور، تصاميم جرافيك، هويات بصرية وملفات إعلانية',
    badgeBg: 'bg-rose-50',
    badgeText: 'text-rose-700',
    badgeBorder: 'border-rose-200',
    iconName: 'Palette',
    examples: 'شعار، تصميم، صورة، فيديو، mockup',
  },
  general: {
    key: 'general',
    label: 'عام ومراسلات',
    description: 'مستندات متنوعة، نصوص عامة وملاحظات سريعة',
    badgeBg: 'bg-slate-100',
    badgeText: 'text-slate-700',
    badgeBorder: 'border-slate-200',
    iconName: 'FolderGit2',
    examples: 'ملاحظة، مسودة، عام',
  },
};

export class AICategorizeService {
  // Load cached classifications from LocalStorage
  static getCachedClassifications(): Record<string, AICategoryClassification> {
    try {
      const data = localStorage.getItem(STORAGE_CATEGORIES_CACHE);
      return data ? JSON.parse(data) : {};
    } catch {
      return {};
    }
  }

  // Get cached classification for a single file or compute heuristic
  static getCachedOrHeuristicCategory(file: DriveFile): AICategoryClassification {
    const cached = AICategorizeService.getCachedClassifications();
    if (cached[file.id] && cached[file.id].category) {
      return cached[file.id];
    }
    return AICategorizeService.classifyHeuristic(file);
  }

  // Save cached classifications
  static saveCachedClassifications(items: Record<string, AICategoryClassification>) {
    try {
      localStorage.setItem(STORAGE_CATEGORIES_CACHE, JSON.stringify(items));
    } catch (e) {
      console.warn('Failed to cache AI categories to localStorage', e);
    }
  }

  // Fast heuristic classification fallback
  static classifyHeuristic(file: DriveFile): AICategoryClassification {
    const name = (file.name || '').toLowerCase();
    const desc = (file.description || '').toLowerCase();
    const mime = (file.mimeType || '').toLowerCase();
    const combined = `${name} ${desc}`;

    if (
      combined.includes('فاتور') ||
      combined.includes('invoice') ||
      combined.includes('bill') ||
      combined.includes('receipt') ||
      combined.includes('سند') ||
      combined.includes('قبض') ||
      combined.includes('دفع') ||
      combined.includes('تسعير')
    ) {
      return {
        fileId: file.id,
        category: 'invoices',
        categoryLabel: AI_CATEGORIES.invoices.label,
        confidence: 0.92,
        tags: ['فواتير', 'مالية', 'سندات'],
        reason: 'يحتوي اسم الملف ومحتواه على مصطلحات فواتير ومطالبات مالية.',
        analyzedAt: new Date().toISOString(),
      };
    }

    if (
      combined.includes('تقرير') ||
      combined.includes('report') ||
      combined.includes('kpi') ||
      combined.includes('تحليل') ||
      combined.includes('إحصائ') ||
      combined.includes('ميزانية') ||
      combined.includes('أداء') ||
      mime.includes('spreadsheet') ||
      name.endsWith('.xlsx') ||
      name.endsWith('.csv') ||
      name.endsWith('.gsheet')
    ) {
      return {
        fileId: file.id,
        category: 'reports',
        categoryLabel: AI_CATEGORIES.reports.label,
        confidence: 0.9,
        tags: ['تقارير', 'تحليلات', 'بيانات'],
        reason: 'مستند مخصص لمتابعة الأداء أو تحليل البيانات والجداول المالية.',
        analyzedAt: new Date().toISOString(),
      };
    }

    if (
      combined.includes('خطة') ||
      combined.includes('مشروع') ||
      combined.includes('project') ||
      combined.includes('plan') ||
      combined.includes('roadmap') ||
      combined.includes('استراتيج') ||
      combined.includes('عرض') ||
      mime.includes('presentation') ||
      name.endsWith('.gslides') ||
      name.endsWith('.pptx')
    ) {
      return {
        fileId: file.id,
        category: 'projects',
        categoryLabel: AI_CATEGORIES.projects.label,
        confidence: 0.88,
        tags: ['مشاريع', 'تخطيط', 'خارطة طريق'],
        reason: 'وثيقة تختص بإدارة وتنفيذ المشاريع أو الخطط الاستراتيجية.',
        analyzedAt: new Date().toISOString(),
      };
    }

    if (
      combined.includes('عقد') ||
      combined.includes('اتفاق') ||
      combined.includes('contract') ||
      combined.includes('agreement') ||
      combined.includes('nda') ||
      combined.includes('سياسات') ||
      combined.includes('شروط') ||
      combined.includes('توكيل')
    ) {
      return {
        fileId: file.id,
        category: 'contracts',
        categoryLabel: AI_CATEGORIES.contracts.label,
        confidence: 0.94,
        tags: ['عقود', 'قانوني', 'اتفاقيات'],
        reason: 'وثيقة تعاقدية أو شروط رسمية موثقة.',
        analyzedAt: new Date().toISOString(),
      };
    }

    if (
      mime.startsWith('image/') ||
      mime.startsWith('video/') ||
      combined.includes('شعار') ||
      combined.includes('logo') ||
      combined.includes('تصميم') ||
      combined.includes('design') ||
      combined.includes('هوية') ||
      name.endsWith('.png') ||
      name.endsWith('.jpg') ||
      name.endsWith('.svg') ||
      name.endsWith('.mp4')
    ) {
      return {
        fileId: file.id,
        category: 'media',
        categoryLabel: AI_CATEGORIES.media.label,
        confidence: 0.95,
        tags: ['تصاميم', 'وسائط', 'صور'],
        reason: 'ملف وسائط متعددة أو تصميم رسومي.',
        analyzedAt: new Date().toISOString(),
      };
    }

    if (
      combined.includes('دورة') ||
      combined.includes('كتاب') ||
      combined.includes('تدريب') ||
      combined.includes('تعليم') ||
      combined.includes('دليل') ||
      combined.includes('course') ||
      combined.includes('guide') ||
      combined.includes('notes')
    ) {
      return {
        fileId: file.id,
        category: 'education',
        categoryLabel: AI_CATEGORIES.education.label,
        confidence: 0.85,
        tags: ['تعليم', 'إرشادات', 'مذكرات'],
        reason: 'محتوى موجه للتعلم أو التدريب أو التوثيق الإرشادي.',
        analyzedAt: new Date().toISOString(),
      };
    }

    return {
      fileId: file.id,
      category: 'general',
      categoryLabel: AI_CATEGORIES.general.label,
      confidence: 0.7,
      tags: ['عام', 'مستندات'],
      reason: 'مستند عام متنوع.',
      analyzedAt: new Date().toISOString(),
    };
  }

  // Categorize a batch of files via Gemini API with Heuristic Fallback
  static async categorizeFiles(
    files: DriveFile[],
    forceRefresh: boolean = false
  ): Promise<Record<string, AICategoryClassification>> {
    const existing = AICategorizeService.getCachedClassifications();
    const updated = { ...existing };

    // Find files needing classification
    const filesToClassify = files.filter(
      (f) => forceRefresh || !existing[f.id] || !existing[f.id].category
    );

    if (filesToClassify.length === 0) {
      return existing;
    }

    // Try calling server Gemini AI categorization
    try {
      const response = await fetch('/api/ai/categorize-batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          files: filesToClassify.map((f) => ({
            id: f.id,
            name: f.name,
            mimeType: f.mimeType,
            size: f.size,
            description: f.description,
          })),
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (Array.isArray(data.classifications)) {
          for (const item of data.classifications) {
            const validKey = (item.category && AI_CATEGORIES[item.category as AICategoryKey])
              ? (item.category as AICategoryKey)
              : 'general';

            updated[item.fileId] = {
              fileId: item.fileId,
              category: validKey,
              categoryLabel: AI_CATEGORIES[validKey].label,
              confidence: item.confidence || 0.9,
              tags: Array.isArray(item.tags) ? item.tags : ['مستند'],
              reason: item.reason || 'تم التحليل بواسطة Gemini AI',
              analyzedAt: new Date().toISOString(),
            };
          }
        }
      } else {
        throw new Error(`Server returned ${response.status}`);
      }
    } catch (err) {
      console.warn('AI Server categorization error, using local smart heuristics:', err);
      // Fallback heuristics for any missing
      for (const file of filesToClassify) {
        if (!updated[file.id]) {
          updated[file.id] = AICategorizeService.classifyHeuristic(file);
        }
      }
    }

    // Fill any missing files with heuristics
    for (const file of files) {
      if (!updated[file.id]) {
        updated[file.id] = AICategorizeService.classifyHeuristic(file);
      }
    }

    AICategorizeService.saveCachedClassifications(updated);
    return updated;
  }
}
