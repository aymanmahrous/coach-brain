import { FileReminder } from '../types';
import { ReminderService } from './reminderService';
import { SoundEffects } from '../utils/audioChime';

export type WebNotificationPermission = NotificationPermission | 'unsupported';

interface NotificationLog {
  [reminderId: string]: {
    approachingNotified?: boolean;
    dueNotified?: boolean;
    timestamp: number;
  };
}

const NOTIFICATION_LOG_KEY = 'web_notifications_sent_log_v1';
const NOTIFICATION_ENABLED_KEY = 'web_notifications_user_enabled_v1';

export class NotificationService {
  /**
   * Check if Web Notifications API is supported in current browser environment
   */
  static isSupported(): boolean {
    return typeof window !== 'undefined' && 'Notification' in window;
  }

  /**
   * Get current notification permission status
   */
  static getPermission(): WebNotificationPermission {
    if (!this.isSupported()) return 'unsupported';
    try {
      return Notification.permission;
    } catch {
      return 'unsupported';
    }
  }

  /**
   * Request permission from user to show desktop notifications
   */
  static async requestPermission(): Promise<WebNotificationPermission> {
    if (!this.isSupported()) return 'unsupported';
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        localStorage.setItem(NOTIFICATION_ENABLED_KEY, 'true');
      }
      return permission;
    } catch (e) {
      console.warn('Failed to request notification permission:', e);
      return this.getPermission();
    }
  }

  /**
   * Check if desktop notifications are user-enabled in preferences
   */
  static isNotificationsEnabled(): boolean {
    if (this.getPermission() !== 'granted') return false;
    const pref = localStorage.getItem(NOTIFICATION_ENABLED_KEY);
    return pref !== 'false';
  }

  /**
   * Set user preference for desktop notifications
   */
  static setNotificationsEnabled(enabled: boolean): void {
    localStorage.setItem(NOTIFICATION_ENABLED_KEY, enabled ? 'true' : 'false');
  }

  /**
   * Load sent notifications log
   */
  private static getLog(): NotificationLog {
    try {
      const raw = localStorage.getItem(NOTIFICATION_LOG_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  }

  /**
   * Save sent notifications log
   */
  private static saveLog(log: NotificationLog): void {
    try {
      // Purge old entries older than 7 days
      const now = Date.now();
      const pruned: NotificationLog = {};
      for (const [key, val] of Object.entries(log)) {
        if (now - val.timestamp < 7 * 24 * 60 * 60 * 1000) {
          pruned[key] = val;
        }
      }
      localStorage.setItem(NOTIFICATION_LOG_KEY, JSON.stringify(pruned));
    } catch (e) {
      console.warn('Failed to save notification log:', e);
    }
  }

  /**
   * Send a raw desktop notification with sound and click listener
   */
  static sendNotification(options: {
    title: string;
    body: string;
    tag?: string;
    requireInteraction?: boolean;
    data?: {
      fileId?: string;
      reminderId?: string;
      type?: string;
    };
  }): Notification | null {
    if (!this.isSupported() || this.getPermission() !== 'granted') {
      return null;
    }

    try {
      // Play sound chime for desktop alert
      try {
        SoundEffects.playReminderChime();
      } catch {}

      const notification = new Notification(options.title, {
        body: options.body,
        tag: options.tag || `remind_${Date.now()}`,
        requireInteraction: options.requireInteraction ?? false,
        icon: '/favicon.ico', // browser fallback icon
        badge: '/favicon.ico',
        dir: 'rtl',
        lang: 'ar',
      });

      notification.onclick = (event) => {
        event.preventDefault();
        window.focus();

        if (options.data?.fileId) {
          window.dispatchEvent(
            new CustomEvent('app:open-reminder-file', {
              detail: {
                fileId: options.data.fileId,
                reminderId: options.data.reminderId,
              },
            })
          );
        }
      };

      return notification;
    } catch (e) {
      console.warn('Error showing Web Notification:', e);
      return null;
    }
  }

  /**
   * Send a test notification to verify Web Notifications API is working
   */
  static async sendTestNotification(): Promise<boolean> {
    const permission = await this.requestPermission();
    if (permission !== 'granted') {
      return false;
    }

    const n = this.sendNotification({
      title: '🔔 إشعارات سطح المكتب تعمل بنجاح!',
      body: 'تم تفعيل التنبيهات المباشرة. سيصلك إشعار على سطح المكتب عند اقتراب موعد أي تذكير أو مهمة هامة حتى خارج المتصفح.',
      tag: 'test-notification',
      requireInteraction: false,
    });

    return n !== null;
  }

  /**
   * Send notification for an approaching reminder (e.g. 15 minutes before)
   */
  static sendApproachingNotification(reminder: FileReminder, minutesRemaining: number): boolean {
    const title = `⏰ اقترب موعد التذكير (خلال ${minutesRemaining} دقيقة): ${reminder.fileName}`;
    const body = reminder.note
      ? `الملاحظة: ${reminder.note}\nالموعد: ${ReminderService.formatReminderDate(reminder.remindAt)}`
      : `الموعد المحدد: ${ReminderService.formatReminderDate(reminder.remindAt)}`;

    const notif = this.sendNotification({
      title,
      body,
      tag: `approaching_${reminder.id}`,
      requireInteraction: reminder.priority === 'high',
      data: {
        fileId: reminder.fileId,
        reminderId: reminder.id,
        type: 'approaching',
      },
    });

    return notif !== null;
  }

  /**
   * Send notification for a due/overdue reminder
   */
  static sendDueNotification(reminder: FileReminder): boolean {
    const priorityLabel = reminder.priority === 'high' ? '⚠️ أولوية قصوى' : 'تذكير مستحق';
    const title = `🔔 حان موعد التذكير الآن [${priorityLabel}]: ${reminder.fileName}`;
    const body = reminder.note
      ? `${reminder.note}\nانقر لفتح الملف ومراجعة التفاصيل.`
      : `حان موعد تنفيذ هذه المهمة. انقر لفتح الملف ومراجعة التفاصيل.`;

    const notif = this.sendNotification({
      title,
      body,
      tag: `due_${reminder.id}`,
      requireInteraction: true,
      data: {
        fileId: reminder.fileId,
        reminderId: reminder.id,
        type: 'due',
      },
    });

    return notif !== null;
  }

  /**
   * Check all reminders and send desktop notifications for approaching and due reminders.
   * Prevents spam by logging sent notifications.
   * 
   * @param reminders All file reminders
   * @param approachingThresholdMinutes Minutes before due time to notify (default: 15)
   */
  static checkAndNotifyReminders(
    reminders: FileReminder[],
    approachingThresholdMinutes = 15
  ): { approachingSent: number; dueSent: number } {
    if (!this.isSupported() || this.getPermission() !== 'granted') {
      return { approachingSent: 0, dueSent: 0 };
    }

    const log = this.getLog();
    const now = Date.now();
    let approachingSent = 0;
    let dueSent = 0;
    let modified = false;

    for (const reminder of reminders) {
      if (reminder.completed) continue;

      const remindTime = new Date(reminder.remindAt).getTime();
      if (isNaN(remindTime)) continue;

      const diffMs = remindTime - now;
      const diffMinutes = Math.ceil(diffMs / 60000);

      const entry = log[reminder.id] || { timestamp: now };

      // Case 1: Reminder is approaching within threshold (e.g., 1 to 15 minutes before)
      if (diffMinutes > 0 && diffMinutes <= approachingThresholdMinutes) {
        if (!entry.approachingNotified) {
          const sent = this.sendApproachingNotification(reminder, diffMinutes);
          if (sent) {
            entry.approachingNotified = true;
            entry.timestamp = now;
            log[reminder.id] = entry;
            approachingSent++;
            modified = true;
          }
        }
      }

      // Case 2: Reminder is due right now or past due (up to 24 hours overdue)
      if (diffMinutes <= 0 && diffMs > -24 * 60 * 60 * 1000) {
        if (!entry.dueNotified) {
          const sent = this.sendDueNotification(reminder);
          if (sent) {
            entry.dueNotified = true;
            entry.timestamp = now;
            log[reminder.id] = entry;
            dueSent++;
            modified = true;
          }
        }
      }
    }

    if (modified) {
      this.saveLog(log);
    }

    return { approachingSent, dueSent };
  }

  /**
   * Reset notification log for a specific reminder (e.g. when rescheduled)
   */
  static resetReminderNotificationLog(reminderId: string): void {
    const log = this.getLog();
    if (log[reminderId]) {
      delete log[reminderId];
      this.saveLog(log);
    }
  }
}
