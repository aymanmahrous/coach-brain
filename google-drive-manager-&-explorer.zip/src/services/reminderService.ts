import { FileReminder } from '../types';

const STORAGE_KEY = 'google_drive_file_reminders_v1';

export class ReminderService {
  /**
   * Get all stored reminders from localStorage
   */
  static getReminders(): FileReminder[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (!data) return [];
      const parsed = JSON.parse(data);
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      console.warn('Failed to load reminders from localStorage:', e);
      return [];
    }
  }

  /**
   * Save all reminders to localStorage
   */
  static saveAllReminders(reminders: FileReminder[]): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(reminders));
    } catch (e) {
      console.warn('Failed to save reminders to localStorage:', e);
    }
  }

  /**
   * Add or update a reminder
   */
  static setReminder(reminderData: {
    fileId: string;
    fileName: string;
    fileMimeType: string;
    remindAt: string;
    note?: string;
    priority?: 'high' | 'medium' | 'low';
    id?: string;
  }): FileReminder {
    const reminders = this.getReminders();
    const existingIndex = reminderData.id 
      ? reminders.findIndex(r => r.id === reminderData.id)
      : reminders.findIndex(r => r.fileId === reminderData.fileId);

    const newReminder: FileReminder = {
      id: reminderData.id || `rem_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      fileId: reminderData.fileId,
      fileName: reminderData.fileName,
      fileMimeType: reminderData.fileMimeType,
      remindAt: reminderData.remindAt,
      note: reminderData.note || '',
      priority: reminderData.priority || 'medium',
      completed: false,
      dismissed: false,
      createdAt: new Date().toISOString(),
    };

    if (existingIndex >= 0) {
      reminders[existingIndex] = {
        ...reminders[existingIndex],
        ...newReminder,
        id: reminders[existingIndex].id, // keep original ID
      };
    } else {
      reminders.push(newReminder);
    }

    this.saveAllReminders(reminders);
    try {
      // Dynamic or lazy reset notification log
      const logKey = 'web_notifications_sent_log_v1';
      const raw = localStorage.getItem(logKey);
      if (raw) {
        const log = JSON.parse(raw);
        if (log[newReminder.id]) {
          delete log[newReminder.id];
          localStorage.setItem(logKey, JSON.stringify(log));
        }
      }
    } catch {}
    return newReminder;
  }

  /**
   * Remove a reminder by ID or file ID
   */
  static deleteReminder(idOrFileId: string): void {
    const reminders = this.getReminders();
    const toDelete = reminders.filter(r => r.id === idOrFileId || r.fileId === idOrFileId);
    const filtered = reminders.filter(r => r.id !== idOrFileId && r.fileId !== idOrFileId);
    this.saveAllReminders(filtered);
    try {
      const logKey = 'web_notifications_sent_log_v1';
      const raw = localStorage.getItem(logKey);
      if (raw) {
        const log = JSON.parse(raw);
        toDelete.forEach(d => delete log[d.id]);
        localStorage.setItem(logKey, JSON.stringify(log));
      }
    } catch {}
  }

  /**
   * Toggle completed status of a reminder
   */
  static toggleCompleted(reminderId: string): FileReminder | null {
    const reminders = this.getReminders();
    const item = reminders.find(r => r.id === reminderId);
    if (item) {
      item.completed = !item.completed;
      this.saveAllReminders(reminders);
      return item;
    }
    return null;
  }

  static toggleComplete(reminderId: string): FileReminder | null {
    return this.toggleCompleted(reminderId);
  }

  /**
   * Get all reminders that are due now
   */
  static getDueReminders(): FileReminder[] {
    return this.getReminders().filter(r => !r.completed && this.isDue(r));
  }

  /**
   * Dismiss notification for a reminder
   */
  static dismissReminder(reminderId: string): void {
    const reminders = this.getReminders();
    const item = reminders.find(r => r.id === reminderId);
    if (item) {
      item.dismissed = true;
      this.saveAllReminders(reminders);
    }
  }

  /**
   * Get reminder for a specific file ID
   */
  static getReminderByFileId(fileId: string): FileReminder | undefined {
    const reminders = this.getReminders();
    return reminders.find(r => r.fileId === fileId);
  }

  /**
   * Check if a reminder is currently due (past or present)
   */
  static isDue(reminder: FileReminder): boolean {
    if (reminder.completed) return false;
    const remindTime = new Date(reminder.remindAt).getTime();
    return remindTime <= Date.now();
  }

  /**
   * Check if a reminder is upcoming in the near future (within 24 hours)
   */
  static isUpcomingSoon(reminder: FileReminder): boolean {
    if (reminder.completed) return false;
    const now = Date.now();
    const remindTime = new Date(reminder.remindAt).getTime();
    const diff = remindTime - now;
    return diff > 0 && diff <= 24 * 60 * 60 * 1000;
  }

  /**
   * Format reminder date/time in friendly Arabic string
   */
  static formatReminderDate(dateString: string): string {
    try {
      const date = new Date(dateString);
      const now = new Date();
      
      const isToday = 
        date.getDate() === now.getDate() &&
        date.getMonth() === now.getMonth() &&
        date.getFullYear() === now.getFullYear();

      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const isTomorrow = 
        date.getDate() === tomorrow.getDate() &&
        date.getMonth() === tomorrow.getMonth() &&
        date.getFullYear() === tomorrow.getFullYear();

      const timeStr = date.toLocaleTimeString('ar-EG', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      });

      if (isToday) {
        return `اليوم، ${timeStr}`;
      }
      if (isTomorrow) {
        return `غداً، ${timeStr}`;
      }

      return date.toLocaleDateString('ar-EG', {
        month: 'short',
        day: 'numeric',
        year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
      }) + ` الساعة ${timeStr}`;
    } catch {
      return dateString;
    }
  }

  /**
   * Get quick preset dates (e.g. +1 hour, tomorrow 9 AM, in 2 days, next week)
   */
  static getPresets(): Array<{ label: string; date: Date }> {
    const now = new Date();

    const inOneHour = new Date(now.getTime() + 60 * 60 * 1000);

    const tomorrowMorning = new Date(now);
    tomorrowMorning.setDate(tomorrowMorning.getDate() + 1);
    tomorrowMorning.setHours(9, 0, 0, 0);

    const tomorrowEvening = new Date(now);
    tomorrowEvening.setDate(tomorrowEvening.getDate() + 1);
    tomorrowEvening.setHours(18, 0, 0, 0);

    const inThreeDays = new Date(now);
    inThreeDays.setDate(inThreeDays.getDate() + 3);
    inThreeDays.setHours(9, 0, 0, 0);

    const nextWeek = new Date(now);
    nextWeek.setDate(nextWeek.getDate() + 7);
    nextWeek.setHours(9, 0, 0, 0);

    return [
      { label: 'بعد ساعة واحدة', date: inOneHour },
      { label: 'غداً صباحاً (9:00 ص)', date: tomorrowMorning },
      { label: 'غداً مساءً (6:00 م)', date: tomorrowEvening },
      { label: 'بعد 3 أيام', date: inThreeDays },
      { label: 'الأسبوع القادم', date: nextWeek },
    ];
  }
}
